iTunes Music Library.xmlをパースして、m3uプレイリスト、htmlプレイリストを生成します。
Windows、Mac OS Xで動作します。Linuxやその他のOSでの動作は未検証です。

以下を参考にしました。
https://code.google.com/p/itunestom3u/
