iTunes Music Library.xmlをパースして、m3uプレイリスト、htmlプレイリストを生成します。
Windows、macOSで動作します。Linuxやその他のOSでの動作は未検証です。
詳しくは http://kodiful.com をご覧ください。

以下を参考にしました。
https://code.google.com/p/itunestom3u/
