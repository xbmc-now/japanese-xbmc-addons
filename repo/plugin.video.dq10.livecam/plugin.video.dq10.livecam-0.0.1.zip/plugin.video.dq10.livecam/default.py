#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  DragonQuest10 LiveCamera v0.0.1 (2014/06/30)
##│  Copyright (c) Inpane
##│  plugin.video.dq10.livecam
##│  http://xbmc.inpane.com/
##│  info@inpane.com
##└──────────────────────────────────────
##
## [ 更新履歴 ]
## 2014/06/30 -> v0.0.1
##  テスト版公開
##
##==============================================================================
## 設定値をここに記載する。
import sys, os, string
import re
import httplib, urllib, urllib2, cookielib
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

__json_url__    = 'http://livecamera.dqx.jp/youtube.jsonp'
__youtube_url__ = 'plugin://plugin.video.youtube/?action=play_video&videoid='

def main():

	try: response = urllib2.urlopen(__json_url__)
	except: return 1
	json = response.read()
	response.close

	p = re.compile(r'.+\,\"URL2\"\:\"(.+)\"\}\]\,.+')
	m = p.search(json)
	if m.group(1):
		xbmc.Player().play(__youtube_url__ + m.group(1))

		while True:
			xbmc.sleep(500)
			if xbmc.Player().isPlayingVideo():
				xbmc.executebuiltin("Action(AspectRatio)")
				xbmc.executebuiltin("Action(AspectRatio)")
				xbmc.executebuiltin("Action(AspectRatio)")
				xbmc.executebuiltin("Action(AspectRatio)")
				xbmc.executebuiltin("Action(AspectRatio)")
				break

#-------------------------------------------------------------------------------
if __name__  == '__main__': main()
