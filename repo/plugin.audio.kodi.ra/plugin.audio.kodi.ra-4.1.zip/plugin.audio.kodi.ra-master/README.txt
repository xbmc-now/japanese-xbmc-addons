NHKラジオ/民放ラジオ（radiko.jp）、コミュニティサイマルラジオ（CSRA.fm）、インターネットサイマルラジオ（jcbasimul.com）が提供する200局以上のインターネットラジオ放送局を聴いたり、番組をファイル保存できるKodiアドオンです。
Windows、macOSで動作します。Linuxやその他のOSでの動作は未検証です。
Kodi v16.1 “Jarvis” における動作を確認しています。Kodi v17.4 “Krypton”、Kodi v18 “Leia” における動作は未確認です。

以下を参考にしました。
http://xbmc.inpane.com/main/heavy_user/script_radiko.php
@xbmc_nowさん、ありがとうございます。
