NHKラジオ/民放ラジオ（radiko.jp）、コミュニティサイマルラジオ（CSRA.fm）、インターネットサイマルラジオ（jcbasimul.com）が提供する200局以上のインターネットラジオ放送局を聴いたり、番組をファイル保存できるKodiアドオンです。
Windows、MacOS Xで動作します。Linuxやその他のOSでの動作は未検証です。

以下を参考にしました。
http://xbmc.inpane.com/main/heavy_user/script_radiko.php
@xbmc_nowさん、ありがとうございます。
