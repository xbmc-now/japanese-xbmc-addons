NHKラジオ(らじる★らじる), 民放ラジオ(radiko.jp), コミュニティサイマルラジオ(csra.fm), インターネットサイマルラジオ(jcbasimul.com)を聴くことができます。 
Windows、MacOS Xで動作します。Linuxやその他のOSでの動作は未検証です。

以下を参考にしました。
http://xbmc.inpane.com/main/heavy_user/script_radiko.php
@xbmc_nowさん、ありがとうございます。
