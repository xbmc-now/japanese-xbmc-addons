# -*- coding: utf-8 -*-
import sys
import routes
from constants import PLUGIN

if __name__ == '__main__':
    sys.exit(PLUGIN.run())
