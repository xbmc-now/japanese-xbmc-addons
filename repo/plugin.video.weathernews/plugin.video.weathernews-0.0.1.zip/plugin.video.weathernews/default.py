import xbmc
xbmc.Player().play('rtmp://solive-hq.wni.co.jp/live playpath=livestream3 swfUrl=http://weathernews.jp/framework/current/mws_streaming_video.swf swfVfy=true live=true')

