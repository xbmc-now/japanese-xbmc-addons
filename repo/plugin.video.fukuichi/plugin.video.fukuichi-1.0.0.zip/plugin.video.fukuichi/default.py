#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  XBMC.fukuichi
##│  Copyright (c) Inpane
##│  plugin.video.fukuichi
##│  http://xbmc.inpane.com/
##│  info@inpane.com
##└──────────────────────────────────────
##==============================================================================
## 設定値をここに記載する。

import os, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import httplib, urllib, urllib2, cookielib
#-------------------------------------------------------------------------------
IPUT = {} # 入力パラメーター

#-------------------------------------------------------------------------------
# resources/libのパスを追加

try:
	IPUT['script_path'] = os.path.abspath(os.path.dirname(__file__))
except:
	IPUT['script_path'] = os.getcwd()

IPUT['resources_path'] = os.path.join(IPUT['script_path'   ], 'resources')
IPUT['library_path'  ] = os.path.join(IPUT['resources_path'], 'lib')
sys.path.append(IPUT['library_path']) 

# コンフィグ読込
import config
config.load(IPUT)

#-------------------------------------------------------------------------------
def main():
	global IPUT

	xbmcplugin.setContent(IPUT['handle'], 'movies')

	label = "福島第一ライブカメラ（１号機側）"
	xli = xbmcgui.ListItem(label)
	xli.setInfo(type = 'Video', infoLabels = {'title': label})
	url = "http://fuku_hls_1-lh.akamaihd.net/i/fuku_hls@348101/master.m3u8"
	xbmcplugin.addDirectoryItem(IPUT['handle'], url, listitem = xli, isFolder = False, totalItems = 1)

	label = "福島第一ライブカメラ（４号機側）"
	xli = xbmcgui.ListItem(label)
	xli.setInfo(type = 'Video', infoLabels = {'title': label})
	url = "http://fuku_hls_4-lh.akamaihd.net/i/fuku_hls@348164/master.m3u8"
	xbmcplugin.addDirectoryItem(IPUT['handle'], url, listitem = xli, isFolder = False, totalItems = 2)

	xbmcplugin.endOfDirectory(IPUT['handle'])

#-------------------------------------------------------------------------------

if __name__  == '__main__': 
	main()
