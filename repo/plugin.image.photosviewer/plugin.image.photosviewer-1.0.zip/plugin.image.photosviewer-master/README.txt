OSXの写真アプリの静止画と動画を表示します。

以下を参考にしました。
https://github.com/PhotoAppPlugin/plugin.image.photoapp
