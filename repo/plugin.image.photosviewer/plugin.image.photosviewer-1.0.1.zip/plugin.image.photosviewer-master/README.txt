macOS写真アプリの写真と動画をブラウズします。
詳しくは http://kodiful.com をご覧ください。

以下を参考にしました。
https://github.com/PhotoAppPlugin/plugin.image.photoapp
