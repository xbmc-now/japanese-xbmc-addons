IP電話への着信を通知します。
macOSでの動作を確認してします。Windows、Linuxやその他のOSでの動作は未検証です。
詳しくは http://kodiful.com をご覧ください。
