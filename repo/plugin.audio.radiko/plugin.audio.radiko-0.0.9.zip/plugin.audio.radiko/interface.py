#!/usr/bin/python
# -*- coding: utf-8 -*-
##==============================================================================
## 設定値をここに記載する。

import sys, os
__script_path__     = os.path.abspath( os.path.dirname(__file__) )
__resources_path__  = __script_path__ + '/resources'
__cache_path__      = __script_path__ + '/cache'
__module_path__     = __resources_path__ + '/module'
__skins_path__      = __resources_path__ + '/skins'
__data_path__       = __cache_path__  + '/data'
__media_path__      = __cache_path__  + '/media'
__twitter_path__    = __cache_path__  + '/twitter'
__fanart_path__     = __cache_path__  + '/fanart'
__resume_file__     = __data_path__   + '/resume'
__tune_file__       = __data_path__   + '/tune'
__program_file__    = __data_path__   + '/program.xml'
__station_file__    = __data_path__   + '/station.xml'
__fanart_file__     = __data_path__   + '/fanart.xml'
__program_qr_file__ = __data_path__   + '/program_qr.png'
__twitter_qr_file__ = __data_path__   + '/twitter_qr.png'
__dummy_qr_file__   = __skins_path__  + '/Default/media/dummy_qr.png'
__read_only_file__  = __skins_path__  + '/Default/media/read_only.png'
__dummy_artist_file__ = __skins_path__  + '/Default/media/dummy_artist.png'
__dummy_header_file__ = __skins_path__  + '/Default/media/dummy_header.png'
__dummy_qr_file__   = __skins_path__    + '/Default/media/dummy_qr.png'
__program_url__     = 'http://radiko.jp/epg/newepg/epgapi.php'
__station_url__     = 'http://radiko.jp/v2/station/list/'
__session_url__     = 'https://lolipop-3834caaa13d2dc37.ssl-lolipop.jp/xbmc.radiko/session.cgi'
__fanart_url__      = 'http://htbackdrops.com/api/6ef61a3ab1917d013f4c40691c21be37'
__twitter_hash_url__   = 'https://lolipop-3834caaa13d2dc37.ssl-lolipop.jp/xbmc.radiko/hash.cgi'
__twitter_write_url__  = 'http://inpane.com/xbmc.radiko/index.cgi'
__twitter_search_url__ = 'http://search.twitter.com/search.atom'

__ctlid_radiko_area_label__       = 200
__ctlid_radiko_station_image__    = 210
__ctlid_radiko_desc_time_label__  = 220
__ctlid_radiko_desc_title_label__ = 221
__ctlid_radiko_desc_textbox__     = 222
__ctlid_radiko_desc_scrollbar__   = 223
__ctlid_radiko_artist_image__     = 224
__ctlid_radiko_qr_image__         = 230
__ctlid_radiko_next_label__       = 240
__ctlid_radiko_next_title_label__ = 241
__ctlid_radiko_next_time_label__  = 242
__ctlid_now_time_label__          = 300
__ctlid_twitter_write_qr_image__  = 310
__ctlid_twitter_write_qr_label__  = 311
__ctlid_twitter_header_image__    = 312
__ctlid_twitter_list__            = 51 # 固定
__ctlid_twitter_list_scrollbar__  = 101

__resume_session_interval__ = 3600
__actid_stop__   = 13
__qr_cell_size__ = 4
__qr_offset__    = 3
__time_zone__    = 9
__twitter_row__  = 500
__interface_file__ = 'interface.xml'
#-------------------------------------------------------------------------------
sys.path.append (__module_path__)
import re, glob, shutil, struct, zlib, xml.dom.minidom
import threading, time
import urllib, urllib2
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import subprocess
import string, random

from math import ceil, sqrt
from base64 import b64encode
from PIL import Image, ImageDraw
from Queue import Queue, Empty
from pyqrcode import Qrcode

#-------------------------------------------------------------------------------
__addon_id__ = 'plugin.audio.radiko'
__settings__ = xbmcaddon.Addon(__addon_id__)
__twitter_gui__         = __settings__.getSetting( "twitter_gui" )
__access_token__        = __settings__.getSetting( "access_token" )
__access_token_secret__ = __settings__.getSetting( "access_token_secret" )
__fanart__              = __settings__.getSetting( "fanart" )

try:    __xbmc_version__ = xbmc.getInfoLabel('System.BuildVersion')
except: __xbmc_version__ = 'Unknown'
class AppURLopener(urllib.FancyURLopener):
	version = 'XBMC/' + __xbmc_version__ + ' - Download and play (' + os.name + ')'
urllib._urlopener = AppURLopener()

IN  = {}
OUT = {}

IN[ 'last_id'        ] = 0
IN[ 'close_sequence' ] = 0
IN[ 'station_id'     ] = ""

WdayArray = ['月', '火', '水', '木', '金', '土', '日']

Resumes = [n for n in range(9)]
# Resumes[0] handle
# Resumes[1] birth
# Resumes[2] key
# Resumes[3] token
# Resumes[4] area
# Resumes[5] reauth
# Resumes[6] reinfo
# Resumes[7] resession
# Resumes[8] sessionid
#-------------------------------------------------------------------------------
def getHash(Area, Station, Program):
	params = urllib.urlencode({'area':Area, 'sta':Station, 'prog':Program})
	f = urllib2.Request(__twitter_hash_url__, params)
	f = urllib2.urlopen(f)
	buf = f.read()

	#print "getHash:"+buf

	ParamDict = {}
	ParamPairs = buf.split( "&" )
	for ParamsPair in ParamPairs : 
		ParamSplits = ParamsPair.split('=')
		if (len(ParamSplits)) == 2 : ParamDict[ParamSplits[0]] = ParamSplits[1]
	return ParamDict
#-------------------------------------------------------------------------------
def setResumes(ResumeFile, ResumeArray):
	stamp = str(int(time.time()))
	#print 'length : %s' % len(ResumeArray)
	f = open(ResumeFile + stamp, 'w')
	
	f.write(
		str(ResumeArray[0]) + '\t' +
		str(ResumeArray[1]) + '\t' +
		str(ResumeArray[2]) + '\t' +
		str(ResumeArray[3]) + '\t' +
		str(ResumeArray[4]) + '\t' +
		str(ResumeArray[5]) + '\t' +
		str(ResumeArray[6]) + '\t' +
		str(ResumeArray[7]) + '\t' +
		str(ResumeArray[8])
	)

	f.close()
	while os.path.isfile(ResumeFile):
		try:
			os.remove(ResumeFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(ResumeFile + stamp, ResumeFile)
#-------------------------------------------------------------------------------
def getResumes(ResumeFile, ResumeArray):
	while True:
		try: 
			r = open(ResumeFile).read()
			tmpResumeArray = r.split('\t')
			ResumeArray[0] = int(tmpResumeArray[0])
			ResumeArray[1] = int(tmpResumeArray[1])
			ResumeArray[2] = str(tmpResumeArray[2])
			ResumeArray[3] = str(tmpResumeArray[3])
			ResumeArray[4] = str(tmpResumeArray[4])
			ResumeArray[5] = int(tmpResumeArray[5])
			ResumeArray[6] = int(tmpResumeArray[6])
			ResumeArray[7] = int(tmpResumeArray[7])
			ResumeArray[8] = str(tmpResumeArray[8])
			break
		except:
			pass
		time.sleep(.05)

#-------------------------------------------------------------------------------
def getTune(TuneFile):
	while True:
		try: 
			Station = open(TuneFile).read()
			break
		except:
			pass
		time.sleep(.05)
	return Station

#-------------------------------------------------------------------------------
def writeQR(d, out):
	a = Qrcode()

	QRData = a.make_qrcode(d)
	QRData = QRData.replace("\n", "") # 改行を抜く
	QRSize = int(sqrt(len(QRData)))  # データの一辺の長さ

	CellSize = __qr_cell_size__
	Offset   = __qr_offset__
	SideLen  = (QRSize + Offset * 2) * CellSize
	Img = Image.new("1",(SideLen, SideLen),1)
	Dr  = ImageDraw.Draw(Img)
	for i, d in enumerate(QRData):
		if d == "1":
			x  = i % QRSize
			y  = i / QRSize
			x0 = (x + Offset) * CellSize
			y0 = (y + Offset) * CellSize
			x1 = x0 + CellSize - 1
			y1 = y0 + CellSize - 1		
			Dr.rectangle((x0, y0, x1, y1), fill = 0)

	Img.save(out,"PNG")
	return

#-------------------------------------------------------------------------------
def getRFC4287(DateString, Diff):
	m = re.match('^(.+T.+)Z$', DateString)
	d = time.strptime(m.group(1),'%Y-%m-%dT%H:%M:%S')
	t = time.localtime( time.mktime(d) + Diff * 60 * 60 )
	return t

#-------------------------------------------------------------------------------
def updateSession(Session, Token, Secret):
	if __twitter_gui__ == 'true' and Token != '' and Secret != '' and Session != '-1': 
		params = urllib.urlencode({'ssn':Session, 'tkn':Token, 'sec':Secret})
		f = urllib2.Request(__session_url__, params)
		f = urllib2.urlopen(f)
		return f.read()
	else:
		return '-1'

#-------------------------------------------------------------------------------
def twitCache(Id, ImageUrl):
	Ext =''
	Extl = ImageUrl.split('.')
	for i in Extl:
		Ext = i
	ImgPath = os.path.join(__twitter_path__ + "/" + str(Id) + "." + Ext)
	#ImgPath = os.path.join("c:/" + str(Id) + "." + Ext)
	if not os.path.isfile(ImgPath):
		#urllib.urlretrieve(ImageUrl, ImgPath)
		d = urllib2.urlopen(ImageUrl)
		f = open(ImgPath, "wb")
		f.write(d.read())
		f.close()
	return ImgPath

#-------------------------------------------------------------------------------
def fanartCache(File):

	Id = File.split('.')
	ImageUrl = __fanart_url__ + '/download/' + Id[0] + '/fullsize';
	ImgPath = os.path.join(__fanart_path__ + "/" + File)
	if not os.path.isfile(ImgPath):
		#urllib.urlretrieve(ImageUrl, ImgPath)
		d = urllib2.urlopen(ImageUrl)
		f = open(ImgPath, "wb")
		f.write(d.read())
		f.close()
	return ImgPath

#-------------------------------------------------------------------------------
def backLower(s):
	Strs = s.split(' ')
	for i in range(len(Strs)):
		Strs[i] = Strs[i][0:1] + Strs[i][1:].lower()
	return ' '.join(Strs)

#-------------------------------------------------------------------------------
def getStationFile(Area, StationFile):
	url = __station_url__ + Area + '.xml'
	while True:
		try:
			response = urllib2.urlopen(url)
			break
		except:
			print 'failed getStationFile'
		time.sleep(1)

	ResultsXml = response.read()
	response.close

	stamp = str(int(time.time()))
	f = open(StationFile + stamp, 'w')
	f.write(ResultsXml)
	f.close()
	while os.path.isfile(StationFile):
		try:
			os.remove(StationFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(StationFile + stamp, StationFile)

#-------------------------------------------------------------------------------
def getProgramFile(Area, ProgramFile):

	url = __program_url__ + '?area_id=' + Area

	while True:
		try:
			response = urllib2.urlopen(url)
			break
		except:
			print 'failed getProgramFile'
		time.sleep(1)

	ResultsXml = response.read()
	response.close
	stamp = str(int(time.time()))
	f = open(ProgramFile + stamp, 'w')
	f.write(ResultsXml)
	f.close()
	while os.path.isfile(ProgramFile):
		try:
			os.remove(ProgramFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(ProgramFile + stamp, ProgramFile)
#-------------------------------------------------------------------------------
def getFanartFile(Key, FanartFile):

	url = __fanart_url__ + '/searchXML?default_operator=and&aid=5,26&' + urllib.urlencode({'keywords':Key + ' radiko'})
	#url = __fanart_url__ + '/searchXML?default_operator=and&aid=5,26&' + urllib.urlencode({'keywords':'radiko'})

	while True:
		try:
			response = urllib2.urlopen(url)
			break
		except:
			print 'failed getFanartFile'
		time.sleep(1)

	ResultsXml = response.read()
	response.close
	stamp = str(int(time.time()))
	f = open(FanartFile + stamp, 'w')
	f.write(ResultsXml)
	f.close()
	while os.path.isfile(FanartFile):
		try:
			os.remove(FanartFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(FanartFile + stamp, FanartFile)

#-------------------------------------------------------------------------------
class GUI( xbmcgui.WindowXML ):
	UpdateProg = int(time.time())

	def __init__( self, *args, **kwargs ):
		pass

	def watchTwitterThread(self):
		global IN
		global WdayArray
		UpdateTime = int(time.time())
		while True:
			if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: break

			if UpdateTime < int(time.time()) and IN.has_key('twitter_search') and IN[ 'twitter_search' ] != '':
				url = __twitter_search_url__ + '?' + urllib.urlencode({'q':IN['twitter_search'], 'since_id':IN['last_id']})

				#print "twitter:" + url
				#url = 'http://search.twitter.com/search.atom?q=%23nhk+OR+%23tbs&since_id=' + str(IN[ 'last_id' ])

				try:

					response   = urllib2.urlopen(url)

					if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: break

					ResultsXml = response.read()
					response.close

					Dom = xml.dom.minidom.parseString(ResultsXml)
					Twits = Dom.getElementsByTagName('entry')
					count = Twits.length
					Twits.reverse()
					r = re.compile('(.*) \((.*)\)$')
					for Twit in Twits:

						if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: break

						FullId = Twit.getElementsByTagName( 'id' )[0].firstChild.data
						#print FullId

						id = FullId.split(':')[2]
						if IN[ 'last_id' ] < id : IN[ 'last_id' ] = id

						m = r.search(Twit.getElementsByTagName( 'name' )[0].firstChild.data)
						if m is None:
							UsrId = "dummy"
							Name  = ""
						else:
							UsrId = m.group(1)
							Name  = m.group(2)

						Title = re.sub("\n", " ", Twit.getElementsByTagName( 'title' )[0].firstChild.data)

						p = getRFC4287(Twit.getElementsByTagName( 'published' )[0].firstChild.data, __time_zone__)
						Published = ("%04d/%02d/%02d(%s) %02d:%02d:%02d" % (p[0],p[1],p[2], WdayArray[p[6]],p[3],p[4],p[5]))

						Links = Twit.getElementsByTagName('link')
						for Link in Links:
							if Link.getAttribute('rel') == 'image':
								ImgUrl = Link.getAttribute('href')
								break
							pass
						ImgPath = twitCache(UsrId, ImgUrl)
						#ImgPath = ""
						listitem = xbmcgui.ListItem(label=Name.encode('utf-8'),label2=Title.encode('utf-8'),thumbnailImage=ImgPath)
						listitem.setProperty( "created_at", Published )
						self.addItem(listitem,0)
						#self.getControl(__ctlid_twitter_list__).addItem(listitem,0)
						self.setFocus( self.getControl(__ctlid_twitter_list__) )
						self.getControl(__ctlid_twitter_list__).selectItem(1)
						time.sleep(0.5)
						self.getControl(__ctlid_twitter_list__).selectItem(0)

						ListSize = self.getListSize()
						if ListSize > __twitter_row__:self.removeItem(ListSize-1)

						#time.sleep(2)
				except:
					pass

				UpdateTime = int(time.time()) + 1

	def watchTimeThread(self):
		global IN
		global WdayArray
		UpdateTime = int(time.time())
		while True:
			if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: break

			if UpdateTime < int(time.time()):
				t = time.localtime()
				self.getControl( __ctlid_now_time_label__ ).setLabel("%04d/%02d/%02d(%s) %02d:%02d:%02d" % (t[0],t[1],t[2], WdayArray[t[6]],t[3],t[4],t[5]))
				UpdateTime = UpdateTime + 1

	def watchProgramThread(self, StationId):
		global IN

		while True:
			if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: break

			if self.UpdateProg < int(time.time()):
				self.updateProgram(StationId)

	def updateProgram(self, StationId):
		global IN
		global Resumes
		global WdayArray

		if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: return
		getProgramFile(Resumes[4], __program_file__)

		if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: return
		ProgramXML = open(__program_file__, 'r').read()
		ProgramDOM = xml.dom.minidom.parseString(ProgramXML)

		Stations = ProgramDOM.getElementsByTagName('station')
		count = Stations.length

		for Station in Stations:

			if Station.getAttribute('id') == StationId:

				Progs = Station.getElementsByTagName('prog')
				for Prog in Progs:
					tmpTime = str(Prog.getAttribute('ft').encode('utf-8'))
					ftTime = int(time.mktime((
						int(tmpTime[0:4]), 
						int(tmpTime[4:6]), 
						int(tmpTime[6:8]), 
						int(tmpTime[8:10]), 
						int(tmpTime[10:12]), 
						int(tmpTime[12:14]), 
						0, 0, 0)))

					ProgDesc = ''
					if ftTime <= int(time.time()):

						# 放送時間
						t = time.localtime(ftTime)
						FtlStr = str(Prog.getAttribute('ftl').encode('utf-8'))
						TolStr = str(Prog.getAttribute('tol').encode('utf-8'))
						self.getControl( __ctlid_radiko_desc_time_label__ ).setLabel("%s曜日 %s:%s～%s:%s" % (WdayArray[t[6]], FtlStr[0:2], FtlStr[2:4], TolStr[0:2], TolStr[2:4]) )


						# 番組名
						if Prog.getElementsByTagName( 'title' ).length > 0 and Prog.getElementsByTagName( 'title' )[0].hasChildNodes():
							IN['title'] = Prog.getElementsByTagName( 'title' )[0].firstChild.data.strip().encode('utf-8')
							self.getControl( __ctlid_radiko_desc_title_label__ ).setLabel(IN['title'])


						# 番組紹介
						if Prog.getElementsByTagName( 'desc' ).length > 0 and Prog.getElementsByTagName( 'desc' )[0].hasChildNodes():
							ProgDesc = re.sub('<br \/>', "\n", Prog.getElementsByTagName( 'desc' )[0].firstChild.data.strip().encode('utf-8'))

						# その他情報
						#if Prog.getElementsByTagName( 'info' ).length > 0 and Prog.getElementsByTagName( 'info' )[0].hasChildNodes():

							#ProgDesc = ProgDesc + "\n" + re.sub('<br \/>', "\n", Prog.getElementsByTagName( 'info' )[0].firstChild.data.strip())

						self.getControl( __ctlid_radiko_desc_textbox__ ).setText(ProgDesc)

						# 番組アドレスＱＲコード
						if Prog.getElementsByTagName( 'url' ).length > 0 and Prog.getElementsByTagName( 'url' )[0].hasChildNodes():
							if os.path.isfile(__program_qr_file__) : os.remove(__program_qr_file__)

							if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: return
							writeQR(Prog.getElementsByTagName( 'url' )[0].firstChild.data.strip().encode('utf-8'), __program_qr_file__)
							if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: return
							self.getControl( __ctlid_radiko_qr_image__ ).setImage(__program_qr_file__)
						else:
							self.getControl( __ctlid_radiko_qr_image__ ).setImage(__dummy_qr_file__)

						IN['twitter_search'] = '#radiko #' + StationId
						IN['twitter_tag'   ] = '#radiko #' + StationId
						tmpHash = {}
						tmpHash = getHash(Resumes[4], StationId, IN['title'])
						if tmpHash.has_key('sta' ) and tmpHash['sta' ] != "": 
							IN['twitter_search'] = IN['twitter_search'] + ' OR #' + tmpHash['sta' ]
							IN['twitter_tag'] = IN['twitter_tag'] + ' #' + tmpHash['sta' ]
						if tmpHash.has_key('prog') and tmpHash['prog' ] != "": 
							ParamPairs = tmpHash['prog'].split( " " )
							for ParamsPair in ParamPairs : 
								IN['twitter_search'] = IN['twitter_search'] + ' OR #' + ParamsPair
								IN['twitter_tag'] = IN['twitter_tag'] + ' #' + ParamsPair
						# ツイッター書込ＱＲコード
						if Resumes[8] != '-1':
							if os.path.isfile(__twitter_qr_file__) : os.remove(__twitter_qr_file__)

							url = __twitter_write_url__ + '?' + urllib.urlencode({'s':Resumes[8], 't':IN['twitter_tag']})
							#print url

							if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: return
							writeQR(url.encode('utf-8'), __twitter_qr_file__)
							if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: return
							self.getControl( __ctlid_twitter_write_qr_image__ ).setImage(__twitter_qr_file__)
							# ツイートメッセージ
							self.getControl( __ctlid_twitter_write_qr_label__ ).setLabel('モバイルからのツイートはこちらから'.decode('utf-8'))

						else:
							self.getControl( __ctlid_twitter_write_qr_image__ ).setImage(__read_only_file__)
							if __access_token__ == '' or __access_token_secret__ == '':
								self.getControl( __ctlid_twitter_write_qr_label__ ).setLabel('ツイートするには認証設定を行ってください。'.decode('utf-8'))
							else:
								self.getControl( __ctlid_twitter_write_qr_label__ ).setLabel('ツイッターの認証に失敗しています。'.decode('utf-8'))


					if ftTime > int(time.time()):

						# 次の番組名
						if Prog.getElementsByTagName( 'title' ).length > 0 and Prog.getElementsByTagName( 'title' )[0].hasChildNodes():
							self.getControl( __ctlid_radiko_next_title_label__ ).setLabel(Prog.getElementsByTagName( 'title' )[0].firstChild.data.strip().encode('utf-8'))

						# 次の放送時間
						FtlStr = str(Prog.getAttribute('ftl').encode('utf-8'))
						TolStr = str(Prog.getAttribute('tol').encode('utf-8'))
						self.getControl( __ctlid_radiko_next_time_label__ ).setLabel("%s:%s～%s:%s" % (FtlStr[0:2], FtlStr[2:4], TolStr[0:2], TolStr[2:4]) )

						self.UpdateProg = ftTime
				break

		if __fanart__ == 'true': 
			if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: return
			getFanartFile(IN['title'], __fanart_file__)

			if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: return
			FanartXML = open(__fanart_file__, 'r').read()
			FanartDOM = xml.dom.minidom.parseString(FanartXML)

			Images = FanartDOM.getElementsByTagName('image')
			count = Images.length

			FanartArtistArray = [];
			FanartHeaderArray = [];

			for Img in Images:
				Aid  = Img.getElementsByTagName( 'aid' )[0].firstChild.data.encode('utf-8')
				Id   = Img.getElementsByTagName( 'id'  )[0].firstChild.data.encode('utf-8')
				File = Img.getElementsByTagName( 'filename' )[0].firstChild.data.strip().encode('utf-8')
				Ext  =''
				Extl = File.split('.')
				for i in Extl : Ext = i

				if Aid == '5'  : FanartArtistArray.append(Id + '.' + Ext)

				if Aid == '26' : FanartHeaderArray.append(Id + '.' + Ext)

			if len(FanartArtistArray) > 0:
				ImgPath = fanartCache(FanartArtistArray[random.randint(0,len(FanartArtistArray)-1)])
				self.getControl( __ctlid_radiko_artist_image__ ).setImage(ImgPath)
				print ImgPath
			else : self.getControl( __ctlid_radiko_artist_image__ ).setImage(__dummy_artist_file__)

			if len(FanartHeaderArray) > 0:
				ImgPath = fanartCache(FanartHeaderArray[random.randint(0,len(FanartHeaderArray)-1)])
				self.getControl( __ctlid_twitter_header_image__ ).setImage(ImgPath)
				print ImgPath
			else : self.getControl( __ctlid_twitter_header_image__ ).setImage(__dummy_header_file__)

	def watchSessionThread(self):
		global IN
		global Resumes

		while True:
			if IN[ 'close_sequence' ] or xbmcgui.getCurrentWindowId() < 13000: break
			if Resumes[7] < int(time.time()) and Resumes[8] != '-1':
				# ツイッター書込セッション更新
				Resumes[8] = updateSession(Resumes[8], __access_token__, __access_token_secret__)
				Resumes[7] = int(time.time()) + __resume_session_interval__
				setResumes(__resume_file__, Resumes)

	def onInit( self ):
		global Resumes
		global WdayArray
		getStationFile(Resumes[4], __station_file__)

		StationXML = open(__station_file__, 'r').read()
		#StationDOM = xml.dom.minidom.parseString(re.sub('^\xEF\xBB\xBF', '', StationXML))
		StationDOM = xml.dom.minidom.parseString(StationXML)

		# エリア
		self.getControl( __ctlid_radiko_area_label__ ).setLabel('エリア:'.decode('utf-8') + backLower(StationDOM.getElementsByTagName('stations')[0].getAttribute('area_name')))

		# 選択局ロゴ
		#Logo344x80Path  = __media_path__ + '/logo_344x80_' + IN[ 'station_id' ] + '.png'
		#Logo344x80 = 'http://radiko.jp/v2/static/station/logo/' + IN[ 'station_id' ] + '/344x80.png'
		#if not os.path.isfile(Logo344x80Path):
		#	#urllib.urlretrieve(Logo344x80, Logo344x80Path )
		#	d = urllib2.urlopen(Logo344x80)
		#	f = open(Logo344x80Path, "wb")
		#	f.write(d.read())
		#	f.close()

		self.getControl( __ctlid_radiko_station_image__ ).setImage(__media_path__ + '/logo_344x80_' + IN[ 'station_id' ] + '.png')
		self.getControl( __ctlid_radiko_next_label__ ).setLabel('次の番組'.decode('utf-8'))

		self.updateProgram(IN[ 'station_id' ])

		# 現時刻
		t = time.localtime()
		self.getControl( __ctlid_now_time_label__ ).setLabel("%04d/%02d/%02d(%s) %02d:%02d:%02d" % (t[0],t[1],t[2], WdayArray[t[6]],t[3],t[4],t[5]))


		# ツイッター更新用スレッド
		LiThread = threading.Thread(target=self.watchTwitterThread,args=(''))
		LiThread.setDaemon(True)
		LiThread.start()
		#print 'LiThread.start'

		# 現時刻更新用スレッド
		TimeThread = threading.Thread(target=self.watchTimeThread,args=(''))
		TimeThread.setDaemon(True)
		TimeThread.start()

		# 番組更新用スレッド
		ProgThread = threading.Thread(target=self.watchProgramThread,args=(IN[ 'station_id' ],))
		ProgThread.setDaemon(True)
		ProgThread.start()

		# セッション更新用スレッド
		if Resumes[8] != '-1': 
			SsnThread = threading.Thread(target=self.watchSessionThread,args=(''))
			SsnThread.setDaemon(True)
			SsnThread.start()

		pass

	def onAction( self, Action ):
		ActionID   = Action.getId()
		if ActionID == __actid_stop__: 
			self.close()
		pass

	def onFocus( self, ControlId ):
		self.ControlId = ControlId
		pass

	def onClick( self, ControlId ):
		self.ControlId = ControlId
		pass

def main():
	global IN
	global Resumes

	getResumes(__resume_file__, Resumes)

	IN[ 'station_id' ] = getTune(__tune_file__)

	ui = GUI(__interface_file__ , os.getcwd(), "Default")
	ui.doModal()
	del ui

	CheckTime = int(time.time())
	while True:
		#print 'CurrentWindow:' + str(xbmcgui.getCurrentWindowId())
		if xbmc.executehttpapi("GetPlaySpeed()") == '' or xbmcgui.getCurrentWindowId() < 13000:
			IN[ 'close_sequence' ] = 1
			#sys.exit()
			break
		if CheckTime < int(time.time()):
			CheckTime = CheckTime + 1
		time.sleep(0.01)

#-------------------------------------------------------------------------------
if __name__  == '__main__': main()
