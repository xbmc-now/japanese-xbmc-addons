# !/usr/bin/env python
# -*- coding: utf-8 -*- 
# based on Y.Swetake(http://www.swetake.com/')'s qr class library
# for ruby 0.50beta

# -- original copyright (written by Y.Swetake) --
# 著作権・配布など
#　　これらのプログラムの著作権は作者であるY.Swetakeにあります。
#　　これらのプログラムはフリーウエアです。もとの著作権表示を変更しなければ
#　自由に再配布・改造してもかまいません。

# This script is translated to python by libpanda@s18.xrea.com.
# You may redistribute and use this script freely 
# as far as you retain the above Y.Swetake's original copyright notice.
# (2010. 4.15) add copyright notice
import sys, os

class myarray(list):
    def __setitem__(self, key, value):
        try:
            list.__setitem__(self,key,value)
        except:
            self += [None for i in range(key - len(self)+1)]
            list.__setitem__(self,key,value)

    def __getitem__(self, key):
        try:
            return list.__getitem__(self,key)
        except:
            return None

#endclass    

class Qrcode:
    def __init__(self):
        self.path = os.path.dirname(__file__)+"/qrcode_data"
        self.qrcode_error_correct="M"
        self.qrcode_version=0

        self.qrcode_structureappend_n=0
        self.qrcode_structureappend_m=0
        self.qrcode_structureappend_parity=""
        self.qrcode_structureappend_originaldata=""

        return
    
    def string_bit_cal(self, s1, s2, ind):
        if len(s1) > len(s2): s1,s2 = s2,s1
        i = 0
        res = ""
        left_length = len(s2) - len(s1)

        if ind == "xor":
            for s in s1:
                b = ord(s)

                res += chr(b ^ ord(s2[i]))
                i += 1

            res += s2[len(s1):len(s1)+left_length]
        elif ind == "or":
            for s in s1:
                b = ord(s)                
                res += chr(b | ord(s2[i]))
                i += 1
            res += s2[len(s1):len(s1)+left_length]

        elif ind == "and":
            for s in s1:
                b = ord(s)
                res += chr(b & ord(s2[i]))
                i += 1
            res += chr(0) * left_length

        return res
    
    def string_bit_not(self, s1):
        res = ""
        for s in s1:
            b = ord(s)
            res += chr(256 + ~b)
        return res

    def set_qrcode_version(self, z):
        if z>= 0 and z<=40:
            self.qrcode_version = z
        return

    def set_qrcode_error_correct(self, z):
        self.qrcode_error_correct = z
        return

    def get_qrcode_version(self, z):
        return self.qrcode_version

    def set_structureappend(self, m, n, p):
        if n>1 and n<=16 and m>0 and m<=16 and p>=0 and p<=255 :
            self.qrcode_structureappend_m = m
            self.qrcode_structureappend_n = n
            self.qrcode_structureappend_parity = p

        return
    
    def cal_structureappend_parity(self, originaldata):
        if len(originaldata) > 1:
            structureappend_parity=0
            for s in originaldata:
                b = ord(s)
                structureappend_parity ^= b
        return
    
    def make_qrcode(self, qrcode_data_string):
        data_length = len(qrcode_data_string)
        data_counter=0
        data_value= myarray()
        data_bits= myarray()

        data_bits[data_counter]=4


        ##### mode #####
        import re
        if( qrcode_data_string.isdigit()):
            mode ="num"
        elif(re.match("^[0-9A-Z\ \$\*\%\+\-\./\:]+$",qrcode_data_string)):
            mode = "alnum"
        else:
            mode = "8bit"

        # ------ 8bit byte mode --------
        if(mode == "8bit"):
            codeword_num_plus=[0,0,0,0,0,0,0,0,0,0,
                               8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,
                               8,8,8,8,8,8,8,8,8,8,8,8,8,8]
            data_value[data_counter]=4
            data_counter+=1
            data_value[data_counter]=data_length
            data_bits[data_counter]=8
            
            codeword_num_counter_value=data_counter
            
            data_counter+=1
            i=0
            while i<data_length:
                data_value[data_counter]=ord(qrcode_data_string[i])
                data_bits[data_counter]=8
                data_counter+=1
                i+=1
            #endwhile

        ##### mode-end #####

        # ---- alphanumeric mode
        if(mode == "alnum"):
            codeword_num_plus=[0,0,0,0,0,0,0,0,0,0,
                               2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
                               4,4,4,4,4,4,4,4,4,4,4,4,4,4]
    
            data_value[data_counter]=2
    
            data_counter+=1
            data_value[data_counter]=data_length
            data_bits[data_counter]=9
    
            codeword_num_counter_value=data_counter
    
            alphanumeric_character_hash={"0":0,"1":1,"2":2,"3":3,
                                         "4":4,"5":5,"6":6,"7":7,
                                         "8":8,"9":9,"A":10,"B":11,
                                         "C":12,"D":13,"E":14,"F":15,
                                         "G":16,"H":17,"I":18,"J":19,
                                         "K":20,"L":21,"M":22,"N":23,
                                         "O":24,"P":25,"Q":26,"R":27,
                                         "S":28,"T":29,"U":30,"V":31,
                                         "W":32,"X":33,"Y":34,"Z":35,
                                         " ":36,"$":37,"%":38,"*":39,
                                         "+":40,"-":41,".":42,"/":43,
                                         ":":44}

            i=0
            data_counter+=1
    
            while i<data_length:
                if (i % 2) == 0 :
                    data_value[data_counter]=alphanumeric_character_hash[qrcode_data_string[i]]
                    data_bits[data_counter]=6
                else:
                    data_value[data_counter]=data_value[data_counter]*45+alphanumeric_character_hash[qrcode_data_string[i]]
                    data_bits[data_counter]=11
                    data_counter+=1
                #end
                i+=1
            #end
            
        # ---- end of alphanumeric mode
    
        # ---- numeric mode
        if(mode=="num"):
            codeword_num_plus=[0,0,0,0,0,0,0,0,0,0,
                               2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
                               4,4,4,4,4,4,4,4,4,4,4,4,4,4]

            data_value[data_counter]=1
            data_counter+=1
            data_value[data_counter]=data_length
            data_bits[data_counter]=10
            codeword_num_counter_value=data_counter        


            i=0
            data_counter+=1
            while i < data_length:
                if ((i % 3)==0):
                    data_value[data_counter]=int(qrcode_data_string[i])
                    data_bits[data_counter]=4
                else:
                    data_value[data_counter]=data_value[data_counter]*10+int(qrcode_data_string[i])
                    if ((i % 3)==1):
                        data_bits[data_counter]=7
                    else:
                        data_bits[data_counter]=10
                        data_counter+=1
                    #end
                #end
                i+=1
            #end
    
            if data_bits[data_counter] is None:
                pass
            elif data_bits[data_counter]>0:
                data_counter+=1
            #end
        # --- end of numeric mode

        i=0
        total_data_bits=0

        while i<data_counter:
            total_data_bits+=data_bits[i]
            i+=1
        #end

        ecc_character_hash = {"L":1,"l":1,
                              "M":0,"m":0,
                              "Q":3,"q":3,
                              "H":2,"h":2}
        ec=ecc_character_hash[self.qrcode_error_correct]
        max_data_bits_array=[0,128,224,352,512,688,864,992,1232,1456,1728,
                             2032,2320,2672,2920,3320,3624,4056,4504,5016,5352,
                             5712,6256,6880,7312,8000,8496,9024,9544,10136,10984,
                             11640,12328,13048,13800,14496,15312,15936,16816,17728,18672,
                             
                             152,272,440,640,864,1088,1248,1552,1856,2192,
                             2592,2960,3424,3688,4184,4712,5176,5768,6360,6888,
                             7456,8048,8752,9392,10208,10960,11744,12248,13048,13880,
                             14744,15640,16568,17528,18448,19472,20528,21616,22496,23648,

                             72,128,208,288,368,480,528,688,800,976,
                             1120,1264,1440,1576,1784,2024,2264,2504,2728,3080,
                             3248,3536,3712,4112,4304,4768,5024,5288,5608,5960,
                             6344,6760,7208,7688,7888,8432,8768,9136,9776,10208,

                             104,176,272,384,496,608,704,880,1056,1232,
                             1440,1648,1952,2088,2360,2600,2936,3176,3560,3880,
                             4096,4544,4912,5312,5744,6032,6464,6968,7288,7880,
                             8264,8920,9368,9848,10288,10832,11408,12016,12656,13328
                             ]
        if self.qrcode_version == 0:
            i=1+40*ec
            j=i+39
            self.qrcode_version=1
            while i<=j:
                if ((max_data_bits_array[i])>=total_data_bits+codeword_num_plus[self.qrcode_version]):
                    max_data_bits=max_data_bits_array[i]
                    break
                #end
                i+=1
                self.qrcode_version+=1
            #end
            else:
                max_data_bits=max_data_bits_array[self.qrcode_version+40*ec]
            #end
            total_data_bits+=codeword_num_plus[self.qrcode_version]
            data_bits[codeword_num_counter_value]+=codeword_num_plus[self.qrcode_version]
            max_codewords_array = [ 0,26,44,70,100,134,172,196,242,
                                    292,346,404,466,532,581,655,733,815,901,991,1085,1156,
                                    1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,
                                    2611,2761,2876,3034,3196,3362,3532,3706]
            max_codewords = max_codewords_array[self.qrcode_version]
            max_modules_1side=17+(self.qrcode_version << 2)
            matrix_remain_bit=[0,0,7,7,7,7,7,0,0,0,0,0,0,0,3,3,3,3,3,3,3,
                               4,4,4,4,4,4,4,3,3,3,3,3,3,3,0,0,0,0,0,0]
    
            #/* ---- read version ECC data file */
            byte_num=matrix_remain_bit[self.qrcode_version]+(max_codewords << 3)

            filename=self.path+"/qrv"+str(self.qrcode_version)+"_"+str(ec)+".dat"
            fp = open(filename ,'rb')
            matx=fp.read(byte_num)
            maty=fp.read(byte_num)
            masks=fp.read(byte_num)
            fi_x=fp.read(15)
            fi_y=fp.read(15)
            rs_ecc_codewords=ord(fp.read(1))
            rso=fp.read(128)
            fp.close()

            unpack = lambda y: map(lambda x:ord(x),y)
            matrix_x_array = unpack(matx)
            matrix_y_array = unpack(maty)
            mask_array = unpack(masks)
            rs_block_order = unpack(rso)
            format_information_x2 = unpack(fi_x)
            format_information_y2 = unpack(fi_y)
            format_information_x1=[0,1,2,3,4,5,7,8,8,8,8,8,8,8,8]
            format_information_y1=[8,8,8,8,8,8,8,8,7,5,4,3,2,1,0]
            
            max_data_codewords=(max_data_bits >>3)
            filename = self.path+"/rsc"+str(rs_ecc_codewords)+".dat"

            fp =open(filename, 'rb')

            i=0
            rs_cal_table_array=myarray()

            while i<256:
                rs_cal_table_array[i]=fp.read(rs_ecc_codewords)
                i+=1

            #end
            fp.close()

            #/* -- read frame data  -- */
            filename = self.path+"/qrvfr"+str(self.qrcode_version)+".dat"
            print "maa:"+filename
            fp = open(filename, 'rb')
            frame_data = fp.read(65535)
            fp.close()

            #/*  --- set terminator */
            if (total_data_bits<=max_data_bits-4):
                data_value[data_counter]=0
                data_bits[data_counter]=4
            elif  (total_data_bits<max_data_bits):
                data_value[data_counter]=0
                data_bits[data_counter]=max_data_bits-total_data_bits
            elif (total_data_bits>max_data_bits) :
                raise OverflowError, "Overflow error"
	        return 0

            #/* ----divide data by 8bit */
            i=0
            codewords_counter=0
            codewords=myarray()
            codewords[0]=0
            remaining_bits=8

            while (i <= data_counter):
                buf =data_value[i]
                buffer_bits=data_bits[i]
                flag=1
                while flag!=0 :

                    if remaining_bits>buffer_bits :
                        if codewords[codewords_counter] ==None : codewords[codewords_counter]=0 

                        codewords[codewords_counter]=((codewords[codewords_counter]<<buffer_bits) | buf)
                        remaining_bits-=buffer_bits
                        flag=0
                    else:
                        buffer_bits-=remaining_bits
                        """
                        print "buf",buf
                        print "buffer_bits",buffer_bits
                        print "remaining_bits",remaining_bits
                        print "codewords",codewords[codewords_counter]
                        """
                        codewords[codewords_counter]=((codewords[codewords_counter] << remaining_bits) | (buf >> buffer_bits))
                        if (buffer_bits==0):
                            flag=0
                        else:
                            buf= (buf & ((1 << buffer_bits)-1) )
                            flag=1

                        #end

                        codewords_counter+=1
                        if (codewords_counter<max_data_codewords-1):
                            codewords[codewords_counter]=0
                        #end
                        remaining_bits=8
                    #end

                #end
                i+=1
            #end

            if (remaining_bits!=8):
                codewords[codewords_counter]=codewords[codewords_counter] << remaining_bits
            else:
                codewords_counter-=1
            #end

            #/* ----  set padding character */            
            if (codewords_counter<max_data_codewords-1):
                flag=1
                while codewords_counter<max_data_codewords-1:
                    codewords_counter+=1
                    if (flag==1):
                        codewords[codewords_counter]=236
                    else:
                        codewords[codewords_counter]=17
                    #end
                    flag=flag*(-1)
                #end
            #end

            #/* ---- RS-ECC prepare */

            i=0
            j=0
            rs_block_number=0
            rs_temp=myarray()
            rs_temp[0]=""

            while i<max_data_codewords:

                rs_temp[rs_block_number] += chr(codewords[i])

                j+=1
                if j>=rs_block_order[rs_block_number]-rs_ecc_codewords:
                    j=0
                    rs_block_number+=1
                    rs_temp[rs_block_number]=""
                #end
                i+=1
            #end

            #/*
            #
            # RS-ECC main
            #
            #*/

            rs_block_number=0
            rs_block_order_num = len(rs_block_order)

            while rs_block_number<rs_block_order_num:
                rs_codewords=rs_block_order[rs_block_number]
                rs_data_codewords=rs_codewords-rs_ecc_codewords

                rstemp=rs_temp[rs_block_number]
                j=rs_data_codewords
                while j>0:
                    first=ord(rstemp[0])
                    if first!=0:
                        left_chr=rstemp[1:]
                        cal=rs_cal_table_array[first]
                        rstemp=self.string_bit_cal(left_chr,cal,"xor")

                    else:
                        rstemp=rstemp[1:]
                        pass
                    #end
                    j-=1

                #end
                pass
                codewords += unpack(rstemp)
                rs_block_number+=1
            #end

            #---- 
            #/* ---- flash matrix */
            matrix_content = [[0 for i in range(max_modules_1side)] for j in range(max_modules_1side )]

            #/* --- attach data */
            i=0
            while i<max_codewords:
                codeword_i=codewords[i]
                j=7
                while j>=0:
                    codeword_bits_number=(i << 3) +  j

                    matrix_content[ matrix_x_array[codeword_bits_number] ][ matrix_y_array[codeword_bits_number] ]=((255*(codeword_i & 1)) ^ mask_array[codeword_bits_number] )
                    codeword_i= codeword_i >> 1
                    j-=1
                #end
                i+=1
            #end
             
            matrix_remain=matrix_remain_bit[self.qrcode_version]
            while matrix_remain>0:
                remain_bit_temp = matrix_remain + ( max_codewords << 3)-1
                matrix_content[ matrix_x_array[remain_bit_temp] ][ matrix_y_array[remain_bit_temp] ]  =  ( 255 ^ mask_array[remain_bit_temp] )

                matrix_remain-=1
            #end

            #--- mask select
            min_demerit_score=0
            hor_master=""
            ver_master=""
            k=0
            while k<max_modules_1side:
                l=0
                while l<max_modules_1side:
                    hor_master += chr(matrix_content[l][k])
                    ver_master += chr(matrix_content[k][l])
                    l+=1
                #end
                k+=1
            #end
            i=0
            all_matrix=max_modules_1side*max_modules_1side

            while i<8:
                demerit_n1=0
                ptn_temp=myarray()
                bit= 1<< i
                bit_r=(~bit) & 255
                bit_mask=chr(bit) * all_matrix
                hor = self.string_bit_cal(hor_master,bit_mask,"and")
                ver = self.string_bit_cal(ver_master,bit_mask,"and")
                ver_and= self.string_bit_cal( ((chr(170) * max_modules_1side) + ver), (ver + (chr(170) * max_modules_1side)),"and")
                ver_or=  self.string_bit_cal( ((chr(170) * max_modules_1side) + ver), (ver + (chr(170) * max_modules_1side)),"or")
                hor= self.string_bit_not(hor)
                ver= self.string_bit_not(ver)


                ver_and = self.string_bit_not(ver_and)
                ver_or  = self.string_bit_not(ver_or)

                strsubst= lambda x,a,c: x[:a]+c+x[a:]
                ver_and = strsubst(ver_and, all_matrix, chr(170))
                ver_or = strsubst(ver_or, all_matrix, chr(170))

                k = max_modules_1side - 1

                while k>=0:
                    hor = strsubst(hor, k*max_modules_1side,chr(170))

                    ver = strsubst(ver, k*max_modules_1side,chr(170))
                    ver_and = strsubst(ver_and, k*max_modules_1side,chr(170))
                    ver_or = strsubst(ver_or, k*max_modules_1side,chr(170))                    
                    k-=1

                #end
                hor=hor + chr(170) + ver
                n1_search=(chr(255) * 5)+"+|"+(chr(bit_r) * 5) + "+"
                n2_search1=chr(bit_r) + chr(bit_r) + "+"
                n2_search2=chr(255) + chr(255) + "+"
                n3_search=chr(bit_r) + chr(255) + chr(bit_r) + chr(bit_r) + chr(bit_r) + chr(255)+ chr(bit_r)
                n4_search=chr(bit_r)
                hor_temp=hor


                import re
                demerit_n3 = len(re.findall(n3_search,hor_temp))*40 
                demerit_n4 = abs(int(( ( ( (ver.count(n4_search)*len(n4_search)*100) / byte_num) -50)/5))) * 10
                
                demerit_n2=0
                ptn_temp=re.findall(n2_search1, ver_and)
                for te in ptn_temp:
                    demerit_n2 += len(te)-1
                    
                ptn_temp=re.findall(n2_search2, ver_or)
                for te in ptn_temp:
                    demerit_n2 += len(te)-1

                demerit_n2*=3
                ptn_temp=re.findall(n1_search, hor)
                for te in ptn_temp:
                    demerit_n1 += len(te)-2
                    
                demerit_score=demerit_n1+demerit_n2+demerit_n3+demerit_n4
                if (demerit_score<=min_demerit_score or i==0):
                    mask_number=i
                    min_demerit_score=demerit_score
                #end

                i+=1
            #end

            mask_content=1 << mask_number
            
            # --- format information

            format_information_value=((ec << 3) | mask_number)
            format_information_array=["101010000010010","101000100100101",
                                      "101111001111100","101101101001011","100010111111001","100000011001110",
                                      "100111110010111","100101010100000","111011111000100","111001011110011",
                                      "111110110101010","111100010011101","110011000101111","110001100011000",
                                      "110110001000001","110100101110110","001011010001001","001001110111110",
                                      "001110011100111","001100111010000","000011101100010","000001001010101",
                                      "000110100001100","000100000111011","011010101011111","011000001101000",
                                      "011111100110001","011101000000110","010010010110100","010000110000011",
                                      "010111011011010","010101111101101"]

            for i in range(15):
                content=int(format_information_array[format_information_value][i])
                matrix_content[format_information_x1[i]][format_information_y1[i]]=content * 255
                matrix_content[format_information_x2[i]][format_information_y2[i]]=content * 255
            #end

            out=""
            mxe=max_modules_1side

            for i in range(mxe):
                for j in range(mxe):
                    if (int(matrix_content[j][i]) & mask_content)!=0:
                        out+="1"
                    else:
                        out+="0"
                    #end
                #end
                out+="\n"
            #end

            out=self.string_bit_cal(out,frame_data ,"or")
            return out


#endclass

