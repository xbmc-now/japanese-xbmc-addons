#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  XBMC.radiko v0.0.3 (2011/06/04)
##│  Copyright (c) Inpane
##│  plugin.audio.radiko
##│  http://xbmc.inpane.com/
##│  info@inpane.com
##└──────────────────────────────────────
##
## [ 更新履歴 ]
## 2011/06/04 -> v0.0.4
##  ロゴファイルの取得方法変更
##
## 2011/06/02 -> v0.0.2
##  番組名を表示
##
## 2011/05/15 -> v0.0.1
##  テスト版公開
##
##==============================================================================
## 設定値をここに記載する。

import sys, os, re, glob, shutil
import struct, zlib, xml.dom.minidom
import threading, time
import urllib, urllib2
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

from math import ceil
from base64 import b64encode
from PIL import Image
from cStringIO import StringIO
#-------------------------------------------------------------------------------
__script_path__  = os.path.abspath( os.path.dirname(__file__) )
__cache_path__   = __script_path__ + '/cache'
__birth_file__   = __cache_path__  + '/birth'
__alive_file__   = __cache_path__  + '/alive'
__resume_file__  = __cache_path__  + '/resume'
__gui_file__     = __script_path__ + '/gui.py'
__player_file__  = __cache_path__  + '/player.swf'
__key_file__     = __cache_path__  + '/authkey.dat'
__program_file__ = __cache_path__  + '/program.xml'
__station_file__ = __cache_path__  + '/station.xml'
__player_url__   = 'http://radiko.jp/player/swf/player_2.0.1.00.swf'
__auth1_url__    = 'https://radiko.jp/v2/api/auth1_fms'
__auth2_url__    = 'https://radiko.jp/v2/api/auth2_fms'

__object_tag__  = 87
__object_id__   = 5

__program_url__ = 'http://radiko.jp/epg/newepg/epgapi.php'
__station_url__ = 'http://radiko.jp/v2/station/list/'
__stream_url__  = 'rtmpe://radiko.smartstream.ne.jp'
__resume_timer_interval__ = 3600

__settings__ = xbmcaddon.Addon('plugin.audio.radiko')

try:    __xbmc_version__ = xbmc.getInfoLabel('System.BuildVersion')
except: __xbmc_version__ = 'Unknown'

class AppURLopener(urllib.FancyURLopener):
	version = 'XBMC/' + __xbmc_version__ + ' - Download and play (' + os.name + ')'

urllib._urlopener = AppURLopener()
PLUGIN_DATA = __settings__.getAddonInfo('profile')
handle = int(sys.argv[1])

Resumes = [n for n in range(8)]
# Resumes[0] handle
# Resumes[1] birth
# Resumes[2] key
# Resumes[3] token
# Resumes[4] area
# Resumes[5] reauth
# Resumes[6] reinfo

#-------------------------------------------------------------------------------
def DeadOrAlive(alive_file):
	stamp = int(time.time())
	if not os.path.isfile(alive_file):return 1
	while True:
		try: 
			check = os.path.getmtime(alive_file)
			if stamp - check > 5:return 1
			else : return 0
			break
		except:
			pass
		time.sleep(.05)

#-------------------------------------------------------------------------------
def ClearCache():
	r = glob.glob(__cache_path__ + '/*')
	for i in r: 
		try:
			if os.path.isfile(i) : os.remove(i)
			if os.path.isdir(i)  : shutil.rmtree(i)
		except:
			pass

#-------------------------------------------------------------------------------
class GetAuthkey(object):
	def __init__(self):
		if not os.path.exists(__player_file__):
			while True:
				try:
					open(__player_file__, 'wb').write(urllib2.urlopen(__player_url__).read())
					break
				except:
					print 'failed get player'
				time.sleep(1)

		if not os.path.exists(__key_file__):
			try:
				self.KeyFileDump()
			except:
				print 'failed get keydata'

	#-----------------------------------
	def KeyFileDump(self):
		tmp_swf = open(__player_file__, 'rb').read()
		self.swf = tmp_swf[:8] + zlib.decompress(tmp_swf[8:]) # 読み込んだswfバッファ
		self.swf_pos = 0 # swf読み込みポインタ

		self.ParseSwfHead()
		self.output_file = __key_file__
		while self.SwfBlock(): # タブブロックがある限り
			if __debug__: print (self.block['tag'], self.block['block_len'], self.block['id'])

			if self.block['tag'] == __object_tag__ and self.block['id'] == __object_id__:
				self.Save(__key_file__)
				break

	#-----------------------------------
	# ヘッダーパース
	def ParseSwfHead(self):
		global CMN
		self.magic   = self.SwfRead(3)
		self.version = ord(self.SwfRead(1))
		self.file_length = self.Le4Byte(self.SwfRead(4))

		rectbits = ord(self.SwfRead(1)) >> 3
		total_bytes = int(ceil((5 + rectbits * 4) / 8.0)) 
		twips_waste = self.SwfRead(total_bytes - 1)
		self.frame_rate_decimal = ord(self.SwfRead(1))
		self.frame_rate_integer = ord(self.SwfRead(1))
		self.frame_count = self.Le2Byte(self.SwfRead(2))

		if __debug__:
			print ("magic: %s\nver: %d\nlen: %d\nframe_rate: %d.%d\ncount: %d\n" % ( \
				self.magic,
				self.version,
				self.file_length,
				self.frame_rate_integer,
				self.frame_rate_decimal,
				self.frame_count))

	#-----------------------------------
	# ブロック判定
	def SwfBlock(self):
		# print "--swf_pos:", self.swf_pos
		swf_block_start = self.swf_pos
		swf_tag = self.Le2Byte(self.SwfRead(2))
		block_len = swf_tag & 0x3f
		if block_len == 0x3f:
			block_len = self.Le4Byte(self.SwfRead(4))
		swf_tag = swf_tag >> 6

		if swf_tag == 0:
			return None

		self.block_pos = 0
		ret = {}
		ret[ 'block_start' ] = swf_block_start
		ret[ 'tag'         ] = swf_tag
		ret[ 'block_len'   ] = block_len
		ret[ 'id'          ] = self.Le2Byte(self.SwfRead(2))
		ret[ 'alpha'       ] = self.SwfRead(4)
		ret[ 'value'       ] = self.SwfBlockMisc(block_len - 6)
		self.block = ret
		return True

	#-----------------------------------
	# ブロックバイナリデータ格納
	def SwfBlockMisc(self, block_len):
		if block_len:
			return self.SwfRead(block_len)
		else:
			return None

	#-----------------------------------
	def Save(self, outfile):
		f = open(outfile, 'wb')
		f.write(self.block['value'])
		f.close()

	def SwfRead(self, num): 
		self.swf_pos += num
		return self.swf[self.swf_pos - num: self.swf_pos]

	def Le2Byte(self, s):
		"LittleEndian to 2 Byte"
		return struct.unpack('<H', s)[0]

	def Le4Byte(self, s):
		"LittleEndian to 4 Byte"
		return struct.unpack('<L', s)[0]

#-------------------------------------------------------------------------------
class Authenticate(threading.Thread):
	_response = {}
	_response['authed'] = 0
	_response['area_id'] = ""

	def __init__(self):
		threading.Thread.__init__(self)
		self.setDaemon(True)

	#-----------------------------------
	def run(self):
		self.startAppIDAuth()

	#-----------------------------------
	def startAppIDAuth(self):
		_loc_1 = AppIDAuth()
		_loc_1.start()

		if _loc_1._response['auth_token'] != "" and _loc_1._response['auth_token'] > 0:
			self._response = _loc_1._response
			self.startChallengeAuth()
		else:
			print 'failed get token'

	#-----------------------------------
	def startChallengeAuth(self):
		_loc_1 = ChallengeAuth()
		_loc_1.start(self._response)

		if _loc_1._response['area_id'] != "" and _loc_1._response['area_id'] > 0:
			self._response['area_id'] = _loc_1._response['area_id']
			self._response['authed' ] = 1
			#t = threading.Timer(__resume_timer_interval__, self.resumeTimer)
			#t.setDaemon(True)
			#t.start()
			#time.sleep(__resume_timer_interval__)
			#self.resumeTimer()
		else:
			print 'failed get area_id'

	#-----------------------------------
	def resetTimer(self):
		self._response = None
		self.startAppIDAuth()

	#-----------------------------------
	def resumeTimer(self):
		self.startChallengeAuth()
		if __debug__:print ("Resume Timer\n")

#-------------------------------------------------------------------------------
class AppIDAuth(object):
	#def __init__(self):
	#	return True

	#-----------------------------------
	def start(self):
		headers = {'pragma': 'no-cache',
			'X-Radiko-App': 'pc_1',
			'X-Radiko-App-Version': '2.0.1',
			'X-Radiko-User': 'test-stream',
			'X-Radiko-Device': 'pc'}

		req = urllib2.Request(__auth1_url__, headers=headers, data='\r\n')

		while True:
			try:
				auth1_fms = urllib2.urlopen(req).info()
				break
			except:
				print 'failed auth1 process'

		self._response = {}
		self._response['auth_token'] = auth1_fms['X-Radiko-AuthToken']
		self._response['key_offset'] = int(auth1_fms['X-Radiko-KeyOffset'])
		self._response['key_length'] = int(auth1_fms['X-Radiko-KeyLength'])
		if __debug__:
			print ("authtoken: %s\noffset: %d length: %d\n" % ( \
				self._response['auth_token'],
				self._response['key_offset'],
				self._response['key_length']))

#-------------------------------------------------------------------------------
class ChallengeAuth(object):
	#def __init__(self):
	#	return True

	#-----------------------------------
	def start(self, _response):
		self._response = _response

		if 'partial_key' not in self._response or self._response['partial_key'] == '':
			self._response['partial_key'] = self.createPartialKey()

		headers = {'pragma': 'no-cache',
			'X-Radiko-App': 'pc_1',
			'X-Radiko-App-Version': '2.0.1',
			'X-Radiko-User': 'test-stream',
			'X-Radiko-Device': 'pc',
			'X-Radiko-Authtoken': self._response['auth_token'],
			'X-Radiko-Partialkey': self._response['partial_key']}

		req = urllib2.Request(__auth2_url__, headers=headers, data='\r\n')
		while True:
			try:
				auth2_fms = urllib2.urlopen(req).read().decode('utf-8')
				break
			except:
				print 'failed auth2 process'
			time.sleep(1)

		self._response['area_id'] = auth2_fms.split(',')[0].strip()
		if __debug__:
			print ("authtoken: %s\noffset: %d length: %d \npartialkey: %s\n" % ( \
				self._response['auth_token'],
				self._response['key_offset'],
				self._response['key_length'],
				self._response['partial_key']))

	#-----------------------------------
	def createPartialKey(self):
		f = open(__key_file__,'rb')
		f.seek(self._response['key_offset'])
		partialkey = b64encode(f.read(self._response['key_length'])).decode('utf-8')
		f.close()
		return partialkey



#-------------------------------------------------------------------------------
def SetResumes(resume_file, resume_array):
	stamp = str(int(time.time()))
	print 'length : %s' % len(resume_array)
	f = open(resume_file + stamp, 'w')
	
	f.write(
		str(resume_array[0]) + '\t' +
		str(resume_array[1]) + '\t' +
		str(resume_array[2]) + '\t' +
		str(resume_array[3]) + '\t' +
		str(resume_array[4]) + '\t' +
		str(resume_array[5]) + '\t' +
		str(resume_array[6])
	)

	f.close()
	while os.path.isfile(resume_file):
		try:
			os.remove(resume_file)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(resume_file + stamp, resume_file)

#-------------------------------------------------------------------------------
def GetResumes(resume_file, resume_array):
	while True:
		try: 
			r = open(resume_file).read()
			tmp_resume_array = r.split('\t')
			resume_array[0] = int(tmp_resume_array[0])
			resume_array[1] = int(tmp_resume_array[1])
			resume_array[2] = str(tmp_resume_array[2])
			resume_array[3] = str(tmp_resume_array[3])
			resume_array[4] = str(tmp_resume_array[4])
			resume_array[5] = int(tmp_resume_array[5])
			resume_array[6] = int(tmp_resume_array[6])
			break
		except:
			pass
		time.sleep(.05)

#-------------------------------------------------------------------------------
def SetHandle(handle_file):
	f = open(handle_file, 'w')
	f.write(sys.argv[1])
	f.close()

#-------------------------------------------------------------------------------
def Birth(birth_file):
	stamp = str(int(time.time()))
	f = open(birth_file + stamp, 'w').close()
	while os.path.isfile(birth_file):
		try:
			os.remove(birth_file)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(birth_file + stamp, birth_file)
	return os.path.getmtime(birth_file)

#-------------------------------------------------------------------------------
def BirthCheck(birth_file, BirthTime):
	try:
		if BirthTime != os.path.getmtime(birth_file):return 1
	except:
		pass
	return 0
#-------------------------------------------------------------------------------
def KeepAlive(alive_file):
	try:
		open(alive_file + '.tmp', 'w').close()
		if os.path.isfile(alive_file) : os.remove(alive_file)
		os.rename(alive_file + '.tmp', alive_file)
	except:
		pass

#-------------------------------------------------------------------------------
def getStationFile(area, station_file):
	url = __station_url__ + area + '.xml'
	while True:
		try:
			response   = urllib.urlopen(url)
			break
		except:
			print 'failed getStationFile'
		time.sleep(1)

	resultsxml = response.read()
	response.close

	stamp = str(int(time.time()))
	f = open(station_file + stamp, 'w')
	f.write(resultsxml)
	f.close()
	while os.path.isfile(station_file):
		try:
			os.remove(station_file)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(station_file + stamp, station_file)

#-------------------------------------------------------------------------------
def getProgramFile(area, program_file):

	url = __program_url__ + '?area_id=' + area

	while True:
		try:
			response   = urllib.urlopen(url)
			break
		except:
			print 'failed getProgramFile'
		time.sleep(1)

	resultsxml = response.read()
	response.close
	stamp = str(int(time.time()))
	f = open(program_file + stamp, 'w')
	f.write(resultsxml)
	f.close()
	while os.path.isfile(program_file):
		try:
			os.remove(program_file)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(program_file + stamp, program_file)

#-------------------------------------------------------------------------------
def getShortestTime(dom):
	stations = dom.getElementsByTagName('station')
	count = stations.length

	for i in range(stations.length):
		tmpTime = int(stations[i].getElementsByTagName( 'prog' )[1].getAttribute('ft'))
		if i == 0 or tmpShortest > tmpTime: tmpShortest = tmpTime
	strShortest = str(tmpShortest)

	ShortestTime = int(time.mktime((
		int(strShortest[0:4]), 
		int(strShortest[4:6]), 
		int(strShortest[6:8]), 
		int(strShortest[8:10]), 
		int(strShortest[10:12]), 
		int(strShortest[12:14]), 
		0, 0, 0)))

	return ShortestTime

#-------------------------------------------------------------------------------
def StationList(station_dom, program_dom, handle, id, token):

	items = {}

	stations = station_dom.getElementsByTagName('station')
	count = stations.length
	if count == 0 : print 'Out of Area'

	for station in stations:
		id = station.getElementsByTagName( 'id'         )[0].firstChild.data
		items[id] = {}
		items[id]['name'      ] = station.getElementsByTagName( 'name'       )[0].firstChild.data
		items[id]['ascii_name'] = station.getElementsByTagName( 'ascii_name' )[0].firstChild.data
		items[id]['logo_large'] = station.getElementsByTagName( 'logo_large' )[0].firstChild.data

		logo_path  = __cache_path__ + '/logo_' + id + '.png'
		if not os.path.isfile(logo_path):
			buffer = urllib.urlopen(items[id]['logo_large'].encode('utf-8')).read() 
			logo_img = Image.open(StringIO(buffer))
			background = Image.new('RGB', ( 216, 216 ), (255, 255, 255))
			background.paste(logo_img, (0, 81), logo_img)
			background.save(logo_path, 'PNG')

		items[id]['logo_path'] = logo_path

	programs = program_dom.getElementsByTagName('station')
	for program in programs:
		id = program.getAttribute('id')

		progs = program.getElementsByTagName('prog')
		for i in range(progs.length):
			if i == 0:
				items[id]['now_prog'  ] = progs[i].getElementsByTagName( 'title' )[0].firstChild.data.strip()
				items[id]['now_start' ] = progs[i].getAttribute('ftl')

				if progs[i].getElementsByTagName( 'pfm' ).length > 0 and progs[i].getElementsByTagName( 'pfm' )[0].hasChildNodes():
					items[id]['now_pfm'   ] = progs[i].getElementsByTagName( 'pfm'   )[0].firstChild.data.strip()

				if progs[i].getElementsByTagName( 'desc' ).length > 0 and progs[i].getElementsByTagName( 'desc' )[0].hasChildNodes():
					items[id]['now_desc'  ] = progs[i].getElementsByTagName( 'desc'  )[0].firstChild.data.strip()

				if progs[i].getElementsByTagName( 'info' ).length > 0 and progs[i].getElementsByTagName( 'info' )[0].hasChildNodes():
					items[id]['now_info'  ] = progs[i].getElementsByTagName( 'info'  )[0].firstChild.data.strip()


				if progs[i].getElementsByTagName( 'url' ).length > 0 and progs[i].getElementsByTagName( 'url' )[0].hasChildNodes():
					items[id]['now_url'   ] = progs[i].getElementsByTagName( 'url'   )[0].firstChild.data.strip()

			elif i == 1:
				items[id]['next_prog'  ] = progs[i].getElementsByTagName( 'title' )[0].firstChild.data.strip()
				items[id]['next_start' ] = progs[i].getAttribute('ftl')

				if progs[i].getElementsByTagName( 'pfm' ).length > 0 and progs[i].getElementsByTagName( 'pfm' )[0].hasChildNodes():
					items[id]['next_pfm'   ] = progs[i].getElementsByTagName( 'pfm'   )[0].firstChild.data.strip()

				if progs[i].getElementsByTagName( 'desc' ).length > 0 and progs[i].getElementsByTagName( 'desc' )[0].hasChildNodes():
					items[id]['next_desc'  ] = progs[i].getElementsByTagName( 'desc'  )[0].firstChild.data.strip()

				if progs[i].getElementsByTagName( 'info'   ).length > 0 and progs[i].getElementsByTagName( 'info' )[0].hasChildNodes():
					items[id]['next_info'  ] = progs[i].getElementsByTagName( 'info'  )[0].firstChild.data.strip()

				if progs[i].getElementsByTagName( 'url'   ).length > 0 and progs[i].getElementsByTagName( 'url' )[0].hasChildNodes():
					items[id]['next_url'   ] = progs[i].getElementsByTagName( 'url'   )[0].firstChild.data.strip()

	for id in items:
		label = '●%s【%s】(%s:%s～)…▽次の番組【%s】(%s:%s～)　'.decode('utf-8') % (
			items[id]['name'      ], 
			items[id]['now_prog'  ], 
			items[id]['now_start' ][0:2], 
			items[id]['now_start' ][2:4], 
			items[id]['next_prog' ], 
			items[id]['next_start'][0:2], 
			items[id]['next_start'][2:4]
		)

		li = xbmcgui.ListItem( label, iconImage=items[id]['logo_path'], thumbnailImage=items[id]['logo_path'] )

		li.setInfo( type = 'music', infoLabels = { 'title': label } )

		url = __stream_url__ + '/%(id)s/_defInst_/simul-stream live=true conn=S: conn=S: conn=S: conn=S:%(token)s' % locals()
		print '%s %s' % (handle,count)
		ok = xbmcplugin.addDirectoryItem(handle, url, listitem = li, isFolder = False, totalItems = count)

	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_TITLE)
	xbmcplugin.endOfDirectory(handle = handle, succeeded = True)


#-------------------------------------------------------------------------------
if __name__ == '__main__':

	if DeadOrAlive(__alive_file__):
		#print 'dead'
		# 初期モード
		ClearCache()
		stamp = str(int(time.time()))

		GetAuthkey()
		_auth = Authenticate()
		_auth.start()
		while 'authed' not in _auth._response or _auth._response['authed'] == 0:time.sleep(0.1)

		if _auth._response['area_id'] != "":

			getStationFile(_auth._response['area_id'], __station_file__)
			getProgramFile(_auth._response['area_id'], __program_file__)
			ProgramXML = open(__program_file__, 'r').read()
			ProgramDOM = xml.dom.minidom.parseString(ProgramXML)

			StationXML = open(__station_file__, 'r').read()
			StationDOM = xml.dom.minidom.parseString(StationXML)

			Resumes[0] = int(sys.argv[1])
			Resumes[1] = Birth(__birth_file__)
			Resumes[2] = _auth._response['partial_key']
			Resumes[3] = _auth._response['auth_token']
			Resumes[4] = _auth._response['area_id']
			Resumes[5] = int(Resumes[1]) + __resume_timer_interval__
			Resumes[6] = getShortestTime(ProgramDOM)

			#StationList(_auth._response['area_id'], _auth._response['auth_token'])
			#time.sleep(__resume_timer_interval__)
		else:
			print 'failed get area'

		SetResumes(__resume_file__, Resumes)

	else:
		# 継続モード
		#print 'alive'
		GetResumes(__resume_file__, Resumes)
		ProgramXML = open(__program_file__, 'r').read()
		ProgramDOM = xml.dom.minidom.parseString(ProgramXML)

		StationXML = open(__station_file__, 'r').read()
		StationDOM = xml.dom.minidom.parseString(StationXML)

	BirthTime = Birth(__birth_file__)

	StationList(StationDOM, ProgramDOM, Resumes[0], Resumes[4], Resumes[3])

	while True:
		stamp = int(time.time())
		#print 'task:%s' % BirthTime
		if BirthCheck(__birth_file__, BirthTime):
			break # プロセスが別に起動した場合

		elif xbmcgui.getCurrentWindowId() != 10501 and xbmcgui.getCurrentWindowId() >= 13000:
			break # WindowIDが変わった場合

		elif Resumes[5] < stamp:
			# 再認証
			_auth = Authenticate()
			_auth._response['auth_token' ] = Resumes[3]
			_auth._response['partial_key'] = Resumes[2]
			_auth.resumeTimer()
			Resumes[5] = int(time.time()) + __resume_timer_interval__
			SetResumes(__resume_file__, Resumes)

		elif Resumes[6] < stamp:
			while True:
				getProgramFile(Resumes[4], __program_file__)
				ProgramXML = open(__program_file__, 'r').read()
				ProgramDOM = xml.dom.minidom.parseString(ProgramXML)
				prgTime = getShortestTime(ProgramDOM)
				if Resumes[6] < prgTime:
					Resumes[6] = prgTime
					break

			SetResumes(__resume_file__, Resumes)
			KeepAlive(__alive_file__)
			xbmc.executebuiltin('Container.Refresh')
			break # リスト更新

		KeepAlive(__alive_file__)
		time.sleep(1)
