#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  XBMC.radiko v0.0.5 (2011/08/29)
##│  Copyright (c) Inpane
##│  plugin.audio.radiko
##│  http://xbmc.inpane.com/
##│  info@inpane.com
##└──────────────────────────────────────
##
## [ 更新履歴 ]
## 2011/08/29 -> v0.0.5
##  ファンアート機能追加
##
## 2011/08/18 -> v0.0.4
##  ツイッター機能追加
##
## 2011/06/04 -> v0.0.3
##  ロゴファイルの取得方法変更
##
## 2011/06/02 -> v0.0.2
##  番組名を表示
##
## 2011/05/15 -> v0.0.1
##  テスト版公開
##
##==============================================================================
## 設定値をここに記載する。
import sys, os, string

__script_path__    = os.path.abspath( os.path.dirname(__file__) )
__resources_path__ = __script_path__ + '/resources'
__cache_path__     = __script_path__ + '/cache'
__interface_file__ = __script_path__ + '/interface.py'
__module_path__    = __resources_path__ + '/module'
__skins_path__     = __resources_path__ + '/skins'
__data_path__      = __cache_path__  + '/data'
__media_path__     = __cache_path__  + '/media'
__twitter_path__   = __cache_path__  + '/twitter'
__birth_file__     = __data_path__   + '/birth'
__alive_file__     = __data_path__   + '/alive'
__resume_file__    = __data_path__   + '/resume'
__tune_file__      = __data_path__   + '/tune'
__program_file__   = __data_path__   + '/program.xml'
__station_file__   = __data_path__   + '/station.xml'
__player_file__    = __media_path__  + '/player.swf'
__key_file__       = __media_path__  + '/authkey.dat'
__player_url__     = 'http://radiko.jp/player/swf/player_2.0.1.00.swf'
__auth1_url__      = 'https://radiko.jp/v2/api/auth1_fms'
__auth2_url__      = 'https://radiko.jp/v2/api/auth2_fms'
__program_url__    = 'http://radiko.jp/epg/newepg/epgapi.php'
__station_url__    = 'http://radiko.jp/v2/station/list/'
__session_url__    = 'https://lolipop-3834caaa13d2dc37.ssl-lolipop.jp/xbmc.radiko/session.cgi'
__stream_url__     = 'rtmpe://radiko.smartstream.ne.jp'

__resume_timer_interval__   = 3600
__resume_session_interval__ = 3600
__object_tag__  = 87
__object_id__   = 5
#-------------------------------------------------------------------------------
sys.path.append (__module_path__)
import re, glob, shutil
import struct, zlib, xml.dom.minidom, struct, zlib, xml.dom.minidom
import threading, time
import httplib, urllib, urllib2, cookielib
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import random

from math import ceil
from base64 import b64encode
from PIL import Image
from cStringIO import StringIO

#-------------------------------------------------------------------------------
__addon_id__ = 'plugin.audio.radiko'
__settings__ = xbmcaddon.Addon(__addon_id__)
__twitter_gui__         = __settings__.getSetting( "twitter_gui" )
__access_token__        = __settings__.getSetting( "access_token" )
__access_token_secret__ = __settings__.getSetting( "access_token_secret" )
__fanart__              = __settings__.getSetting( "fanart" )

try:    __xbmc_version__ = xbmc.getInfoLabel('System.BuildVersion')
except: __xbmc_version__ = 'Unknown'
class AppURLopener(urllib.FancyURLopener):
	version = 'XBMC/' + __xbmc_version__ + ' - Download and play (' + os.name + ')'
urllib._urlopener = AppURLopener()

IN  = {}
OUT = {}

Resumes = [n for n in range(9)]
# Resumes[0] handle
# Resumes[1] birth
# Resumes[2] key
# Resumes[3] token
# Resumes[4] area
# Resumes[5] reauth
# Resumes[6] reinfo
# Resumes[7] resession
# Resumes[8] sessionid
#-------------------------------------------------------------------------------
def getParams():
	ParamDict = {}
	try:
		#print "getParams() argv=", sys.argv
		if sys.argv[2] : ParamPairs = sys.argv[2][1:].split( "&" )
		for ParamsPair in ParamPairs : 
			ParamSplits = ParamsPair.split('=')
			if (len(ParamSplits)) == 2 : ParamDict[ParamSplits[0]] = ParamSplits[1]
	except : pass
	return ParamDict

#-------------------------------------------------------------------------------
def deadOrAlive(AliveFile):
	stamp = int(time.time())
	if not os.path.isfile(AliveFile):return 1
	while True:
		try:
			check = os.path.getmtime(AliveFile)
			if stamp - check > 5:return 1
			else : return 0
			break
		except:
			pass
		time.sleep(.05)

#-------------------------------------------------------------------------------
def clearCache():
	r = glob.glob(__data_path__ + '/*')
	for i in r: 
		try:
			if os.path.isfile(i) : os.remove(i)
			if os.path.isdir(i)  : shutil.rmtree(i)
		except:
			pass

	r = glob.glob(__twitter_path__ + '/*')
	for i in r: 
		try:
			if os.path.isfile(i) : os.remove(i)
			if os.path.isdir(i)  : shutil.rmtree(i)
		except:
			pass

#-------------------------------------------------------------------------------
class getAuthkey(object):
	def __init__(self):

		while True:
			try:
				response = urllib2.urlopen(__player_url__)
				UrlSize = int(response.headers["content-length"])
			except : UrlSize = 0

			if os.path.exists(__player_file__) : PathSize = int(os.path.getsize(__player_file__))
			else : PathSize = 0

			if UrlSize > 0 and UrlSize != PathSize:
				if os.path.exists(__player_file__) : os.remove(__player_file__)
				if os.path.exists(__key_file__) : os.remove(__key_file__)
				open(__player_file__, 'wb').write(response.read())
				self.keyFileDump()

			elif not os.path.exists(__key_file__) and PathSize > 0 :
				self.keyFileDump()

			if os.path.exists(__key_file__) : break
			else : time.sleep(1)

	#-----------------------------------
	def keyFileDump(self):
		tmpSwf = open(__player_file__, 'rb').read()
		self.Swf = tmpSwf[:8] + zlib.decompress(tmpSwf[8:]) # 読み込んだswfバッファ
		self.SwfPos = 0 # swf読み込みポインタ

		self.parseSwfHead()
		self.output_file = __key_file__
		while self.swfBlock(): # タブブロックがある限り
			if __debug__: print (self.Block['tag'], self.Block['block_len'], self.Block['id'])

			if self.Block['tag'] == __object_tag__ and self.Block['id'] == __object_id__:
				self.Save(__key_file__)
				break

	#-----------------------------------
	# ヘッダーパース
	def parseSwfHead(self):
		global CMN
		self.magic   = self.swfRead(3)
		self.version = ord(self.swfRead(1))
		self.file_length = self.le4Byte(self.swfRead(4))

		rectbits = ord(self.swfRead(1)) >> 3
		total_bytes = int(ceil((5 + rectbits * 4) / 8.0)) 
		twips_waste = self.swfRead(total_bytes - 1)
		self.frame_rate_decimal = ord(self.swfRead(1))
		self.frame_rate_integer = ord(self.swfRead(1))
		self.frame_count = self.le2Byte(self.swfRead(2))

		if __debug__:
			print ("magic: %s\nver: %d\nlen: %d\nframe_rate: %d.%d\ncount: %d\n" % ( \
				self.magic,
				self.version,
				self.file_length,
				self.frame_rate_integer,
				self.frame_rate_decimal,
				self.frame_count))

	#-----------------------------------
	# ブロック判定
	def swfBlock(self):
		# print "--SwfPos:", self.SwfPos
		SwfBlockStart = self.SwfPos
		SwfTag = self.le2Byte(self.swfRead(2))
		BlockLen = SwfTag & 0x3f
		if BlockLen == 0x3f:
			BlockLen = self.le4Byte(self.swfRead(4))
		SwfTag = SwfTag >> 6

		if SwfTag == 0:
			return None

		self.BlockPos = 0
		ret = {}
		ret[ 'block_start' ] = SwfBlockStart
		ret[ 'tag'         ] = SwfTag
		ret[ 'block_len'   ] = BlockLen
		ret[ 'id'          ] = self.le2Byte(self.swfRead(2))
		ret[ 'alpha'       ] = self.swfRead(4)
		ret[ 'value'       ] = self.swfBlockMisc(BlockLen - 6)
		self.Block = ret
		return True

	#-----------------------------------
	# ブロックバイナリデータ格納
	def swfBlockMisc(self, BlockLen):
		if BlockLen:
			return self.swfRead(BlockLen)
		else:
			return None

	#-----------------------------------
	def Save(self, OutFile):
		f = open(OutFile, 'wb')
		f.write(self.Block['value'])
		f.close()

	def swfRead(self, Num): 
		self.SwfPos += Num
		return self.Swf[self.SwfPos - Num: self.SwfPos]

	def le2Byte(self, s):
		"LittleEndian to 2 Byte"
		return struct.unpack('<H', s)[0]

	def le4Byte(self, s):
		"LittleEndian to 4 Byte"
		return struct.unpack('<L', s)[0]

#-------------------------------------------------------------------------------
class authenticate(threading.Thread):
	_response = {}
	_response['authed' ] = 0
	_response['area_id'] = ""

	def __init__(self):
		threading.Thread.__init__(self)
		self.setDaemon(True)

	#-----------------------------------
	def run(self):
		self.startAppIDAuth()

	#-----------------------------------
	def startAppIDAuth(self):
		_loc_1 = appIDAuth()
		_loc_1.start()

		if _loc_1._response['auth_token'] != "" and _loc_1._response['auth_token'] > 0:
			self._response = _loc_1._response
			self.startChallengeAuth()
		else:
			print 'failed get token'

	#-----------------------------------
	def startChallengeAuth(self):
		_loc_1 = challengeAuth()
		_loc_1.start(self._response)

		if _loc_1._response['area_id'] != "" and _loc_1._response['area_id'] > 0:
			self._response['area_id'] = _loc_1._response['area_id']
			self._response['authed' ] = 1
			#t = threading.Timer(__resume_timer_interval__, self.resumeTimer)
			#t.setDaemon(True)
			#t.start()
			#time.sleep(__resume_timer_interval__)
			#self.resumeTimer()
		else:
			print 'failed get area_id'

	#-----------------------------------
	def resetTimer(self):
		self._response = None
		self.startAppIDAuth()

	#-----------------------------------
	def resumeTimer(self):
		self.startChallengeAuth()
		if __debug__:print ("Resume Timer\n")

#-------------------------------------------------------------------------------
class appIDAuth(object):
	#def __init__(self):
	#	return True

	#-----------------------------------
	def start(self):
		headers = {'pragma': 'no-cache',
			'X-Radiko-App': 'pc_1',
			'X-Radiko-App-Version': '2.0.1',
			'X-Radiko-User': 'test-stream',
			'X-Radiko-Device': 'pc'}

		req = urllib2.Request(__auth1_url__, headers=headers, data='\r\n')

		while True:
			try:
				Auth1Fms = urllib2.urlopen(req).info()
				break
			except:
				print 'failed auth1 process'

		self._response = {}
		self._response['auth_token'] = Auth1Fms['X-Radiko-AuthToken']
		self._response['key_offset'] = int(Auth1Fms['X-Radiko-KeyOffset'])
		self._response['key_length'] = int(Auth1Fms['X-Radiko-KeyLength'])
		if __debug__:
			print ("authtoken: %s\noffset: %d length: %d\n" % ( \
				self._response['auth_token'],
				self._response['key_offset'],
				self._response['key_length']))

#-------------------------------------------------------------------------------
class challengeAuth(object):
	#def __init__(self):
	#	return True

	#-----------------------------------
	def start(self, _response):
		self._response = _response

		if 'partial_key' not in self._response or self._response['partial_key'] == '':
			self._response['partial_key'] = self.createPartialKey()

		headers = {'pragma': 'no-cache',
			'X-Radiko-App': 'pc_1',
			'X-Radiko-App-Version': '2.0.1',
			'X-Radiko-User': 'test-stream',
			'X-Radiko-Device': 'pc',
			'X-Radiko-Authtoken': self._response['auth_token'],
			'X-Radiko-Partialkey': self._response['partial_key']}

		req = urllib2.Request(__auth2_url__, headers=headers, data='\r\n')
		while True:
			try:
				Auth2Fms = urllib2.urlopen(req).read().decode('utf-8')
				break
			except:
				print 'failed auth2 process'
			time.sleep(1)

		self._response['area_id'] = Auth2Fms.split(',')[0].strip()
		if __debug__:
			print ("authtoken: %s\noffset: %d length: %d \npartialkey: %s\n" % ( \
				self._response['auth_token'],
				self._response['key_offset'],
				self._response['key_length'],
				self._response['partial_key']))

	#-----------------------------------
	def createPartialKey(self):
		f = open(__key_file__,'rb')
		f.seek(self._response['key_offset'])
		partialkey = b64encode(f.read(self._response['key_length'])).decode('utf-8')
		f.close()
		return partialkey



#-------------------------------------------------------------------------------
def setResumes(ResumeFile, ResumeArray):
	stamp = str(int(time.time()))
	#print 'length : %s' % len(ResumeArray)
	f = open(ResumeFile + stamp, 'w')
	
	f.write(
		str(ResumeArray[0]) + '\t' +
		str(ResumeArray[1]) + '\t' +
		str(ResumeArray[2]) + '\t' +
		str(ResumeArray[3]) + '\t' +
		str(ResumeArray[4]) + '\t' +
		str(ResumeArray[5]) + '\t' +
		str(ResumeArray[6]) + '\t' +
		str(ResumeArray[7]) + '\t' +
		str(ResumeArray[8])
	)

	f.close()
	while os.path.isfile(ResumeFile):
		try:
			os.remove(ResumeFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(ResumeFile + stamp, ResumeFile)

#-------------------------------------------------------------------------------
def getResumes(ResumeFile, ResumeArray):
	while True:
		try: 
			r = open(ResumeFile).read()
			tmpResumeArray = r.split('\t')
			ResumeArray[0] = int(tmpResumeArray[0])
			ResumeArray[1] = int(tmpResumeArray[1])
			ResumeArray[2] = str(tmpResumeArray[2])
			ResumeArray[3] = str(tmpResumeArray[3])
			ResumeArray[4] = str(tmpResumeArray[4])
			ResumeArray[5] = int(tmpResumeArray[5])
			ResumeArray[6] = int(tmpResumeArray[6])
			ResumeArray[7] = int(tmpResumeArray[7])
			ResumeArray[8] = str(tmpResumeArray[8])
			break
		except:
			pass
		time.sleep(.05)


#-------------------------------------------------------------------------------
def setTune(TuneFile, Station):
	stamp = str(int(time.time()))
	f = open(TuneFile + stamp, 'w')
	f.write(Station)
	f.close()
	while os.path.isfile(TuneFile):
		try:
			os.remove(TuneFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(TuneFile + stamp, TuneFile)

#-------------------------------------------------------------------------------
def randStr(n):
	alphabets = string.digits + string.letters
	return ''.join(random.choice(alphabets) for i in xrange(n))

#-------------------------------------------------------------------------------
def updateSession(Session, Token, Secret):
	if __twitter_gui__ == 'true' and Token != '' and Secret != '' and Session != '-1': 
		params = urllib.urlencode({'ssn':Session, 'tkn':Token, 'sec':Secret})
		f = urllib2.Request(__session_url__, params)
		f = urllib2.urlopen(f)
		return f.read()
	else:
		return '-1'

#-------------------------------------------------------------------------------
def birth(BirthFile):
	stamp = str(int(time.time()))
	f = open(BirthFile + stamp, 'w').close()
	while os.path.isfile(BirthFile):
		try:
			os.remove(BirthFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(BirthFile + stamp, BirthFile)
	return os.path.getmtime(BirthFile)

#-------------------------------------------------------------------------------
def birthCheck(BirthFile, BirthTime):
	try:
		if BirthTime != os.path.getmtime(BirthFile):return 1
	except:
		pass
	return 0
#-------------------------------------------------------------------------------
def keepAlive(AliveFile):
	try:
		open(AliveFile + '.tmp', 'w').close()
		if os.path.isfile(AliveFile) : os.remove(AliveFile)
		os.rename(AliveFile + '.tmp', AliveFile)
	except:
		pass

#-------------------------------------------------------------------------------
def getStationFile(Area, StationFile):
	url = __station_url__ + Area + '.xml'
	while True:
		try:
			response   = urllib.urlopen(url)
			break
		except:
			print 'failed getStationFile'
		time.sleep(1)

	ResultsXml = response.read()
	response.close

	stamp = str(int(time.time()))
	f = open(StationFile + stamp, 'w')
	f.write(ResultsXml)
	f.close()
	while os.path.isfile(StationFile):
		try:
			os.remove(StationFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(StationFile + stamp, StationFile)

#-------------------------------------------------------------------------------
def getProgramFile(Area, ProgramFile):

	url = __program_url__ + '?area_id=' + Area

	while True:
		try:
			response   = urllib.urlopen(url)
			break
		except:
			print 'failed getProgramFile'
		time.sleep(1)

	ResultsXml = response.read()
	response.close
	stamp = str(int(time.time()))
	f = open(ProgramFile + stamp, 'w')
	f.write(ResultsXml)
	f.close()
	while os.path.isfile(ProgramFile):
		try:
			os.remove(ProgramFile)
			break
		except:
			pass
		time.sleep(.05)
	os.rename(ProgramFile + stamp, ProgramFile)

#-------------------------------------------------------------------------------
def getShortestTime(Dom):
	Stations = Dom.getElementsByTagName('station')
	count = Stations.length

	for i in range(Stations.length):
		tmpTime = int(Stations[i].getElementsByTagName( 'prog' )[1].getAttribute('ft'))
		if i == 0 or tmpShortest > tmpTime: tmpShortest = tmpTime
	strShortest = str(tmpShortest)

	ShortestTime = int(time.mktime((
		int(strShortest[0:4]), 
		int(strShortest[4:6]), 
		int(strShortest[6:8]), 
		int(strShortest[8:10]), 
		int(strShortest[10:12]), 
		int(strShortest[12:14]), 
		0, 0, 0)))

	return ShortestTime

#-------------------------------------------------------------------------------
def stationList(StationDom, ProgramDom, Handle, Token):

	Items = {}

	Stations = StationDom.getElementsByTagName('station')
	count = Stations.length
	if count == 0 : print 'Out of Area'

	for Station in Stations:
		id = Station.getElementsByTagName( 'id'         )[0].firstChild.data
		Items[id] = {}
		Items[id]['name'      ] = Station.getElementsByTagName( 'name'       )[0].firstChild.data
		Items[id]['ascii_name'] = Station.getElementsByTagName( 'ascii_name' )[0].firstChild.data
		Items[id]['logo_large'] = Station.getElementsByTagName( 'logo_large' )[0].firstChild.data

		LogoPath  = os.path.abspath(__media_path__ + '/logo_' + id + '.png')
		Logo344x80Path = os.path.abspath(__media_path__ + '/logo_344x80_' + id + '.png')
		Logos = Station.getElementsByTagName('logo')
		for Logo in Logos:
			if Logo.getAttribute('width') == '344' and Logo.getAttribute('height') == '80':
				Logo344x80Url  = Logo.firstChild.data
				while True:
					try:
						response = urllib2.urlopen(Logo344x80Url)
						UrlSize = int(response.headers["content-length"])
					except : UrlSize = 0

					if os.path.exists(Logo344x80Path) : PathSize = int(os.path.getsize(Logo344x80Path))
					else : PathSize = 0

					if UrlSize > 0 and UrlSize != PathSize:
						if os.path.exists(Logo344x80Path) : os.remove(Logo344x80Path)
						if os.path.exists(LogoPath) : os.remove(LogoPath)
						open(Logo344x80Path, 'wb').write(response.read())

					if os.path.exists(Logo344x80Path) : break
					else : time.sleep(1)

				break
			pass

		if not os.path.isfile(LogoPath):
			buffer = urllib2.urlopen(Items[id]['logo_large'].encode('utf-8')).read() 
			LogoImg = Image.open(StringIO(buffer))
			Background = Image.new('RGB', ( 216, 216 ), (255, 255, 255))
			Background.paste(LogoImg, (0, 81), LogoImg)
			Background.save(LogoPath, 'PNG')

		Items[id]['logo_path'] = LogoPath

	Programs = ProgramDom.getElementsByTagName('station')
	for Program in Programs:
		id = Program.getAttribute('id')

		Progs = Program.getElementsByTagName('prog')
		for i in range(Progs.length):
			if i == 0:
				Items[id]['now_prog'  ] = Progs[i].getElementsByTagName( 'title' )[0].firstChild.data.strip()
				Items[id]['now_start' ] = Progs[i].getAttribute('ftl')

				if Progs[i].getElementsByTagName( 'pfm' ).length > 0 and Progs[i].getElementsByTagName( 'pfm' )[0].hasChildNodes():
					Items[id]['now_pfm'   ] = Progs[i].getElementsByTagName( 'pfm'   )[0].firstChild.data.strip()

				if Progs[i].getElementsByTagName( 'desc' ).length > 0 and Progs[i].getElementsByTagName( 'desc' )[0].hasChildNodes():
					Items[id]['now_desc'  ] = Progs[i].getElementsByTagName( 'desc'  )[0].firstChild.data.strip()

				if Progs[i].getElementsByTagName( 'info' ).length > 0 and Progs[i].getElementsByTagName( 'info' )[0].hasChildNodes():
					Items[id]['now_info'  ] = Progs[i].getElementsByTagName( 'info'  )[0].firstChild.data.strip()


				if Progs[i].getElementsByTagName( 'url' ).length > 0 and Progs[i].getElementsByTagName( 'url' )[0].hasChildNodes():
					Items[id]['now_url'   ] = Progs[i].getElementsByTagName( 'url'   )[0].firstChild.data.strip()

			elif i == 1:
				Items[id]['next_prog'  ] = Progs[i].getElementsByTagName( 'title' )[0].firstChild.data.strip()
				Items[id]['next_start' ] = Progs[i].getAttribute('ftl')

				if Progs[i].getElementsByTagName( 'pfm' ).length > 0 and Progs[i].getElementsByTagName( 'pfm' )[0].hasChildNodes():
					Items[id]['next_pfm'   ] = Progs[i].getElementsByTagName( 'pfm'   )[0].firstChild.data.strip()

				if Progs[i].getElementsByTagName( 'desc' ).length > 0 and Progs[i].getElementsByTagName( 'desc' )[0].hasChildNodes():
					Items[id]['next_desc'  ] = Progs[i].getElementsByTagName( 'desc'  )[0].firstChild.data.strip()

				if Progs[i].getElementsByTagName( 'info'   ).length > 0 and Progs[i].getElementsByTagName( 'info' )[0].hasChildNodes():
					Items[id]['next_info'  ] = Progs[i].getElementsByTagName( 'info'  )[0].firstChild.data.strip()

				if Progs[i].getElementsByTagName( 'url'   ).length > 0 and Progs[i].getElementsByTagName( 'url' )[0].hasChildNodes():
					Items[id]['next_url'   ] = Progs[i].getElementsByTagName( 'url'   )[0].firstChild.data.strip()

	for id in Items:
		Label = '●%s【%s】(%s:%s～)…▽次の番組【%s】(%s:%s～)　'.decode('utf-8') % (
			Items[id]['name'      ], 
			Items[id]['now_prog'  ], 
			Items[id]['now_start' ][0:2], 
			Items[id]['now_start' ][2:4], 
			Items[id]['next_prog' ], 
			Items[id]['next_start'][0:2], 
			Items[id]['next_start'][2:4]
		)

		li = xbmcgui.ListItem( Label, iconImage=Items[id]['logo_path'], thumbnailImage=Items[id]['logo_path'] )

		li.setInfo( type = 'music', infoLabels = { 'title': Label } )

		#url = sys.argv[0] + '?ope=play&id=%(id)s&token=%(Token)s' % locals()


		if __twitter_gui__ == 'false': 
			url = __stream_url__ + '/%(id)s/_defInst_/simul-stream live=true conn=S: conn=S: conn=S: conn=S:%(Token)s' % locals()
			ok = xbmcplugin.addDirectoryItem(Handle, url, listitem = li, isFolder = False, totalItems = count)
		else: 
			url = 'plugin://' + __addon_id__ + '?ope=play&id=%(id)s&token=%(Token)s' % locals()
			ok = xbmcplugin.addDirectoryItem(Handle, url, listitem = li, isFolder = True, totalItems = count)

	xbmcplugin.addSortMethod(Handle, xbmcplugin.SORT_METHOD_TITLE)
	xbmcplugin.endOfDirectory(handle = Handle, succeeded = True)


#-------------------------------------------------------------------------------
def main():

	global IN
	global OUT
	IN = getParams()

	IN[ 'handle' ] = int(sys.argv[1])
	OUT[ 'handle' ] = IN[ 'handle' ]

	if IN.has_key('ope') and IN['ope'] == "play" :

		#li = xbmcgui.ListItem( "" )
		#ok = xbmcplugin.addDirectoryItem(OUT[ 'handle' ], "", listitem = li, isFolder = False)
		xbmcplugin.endOfDirectory(handle = OUT[ 'handle' ], succeeded = False)
		xbmc.executebuiltin('Action(ParentDir)')

		url = __stream_url__ + '/%s/_defInst_/simul-stream live=true conn=S: conn=S: conn=S: conn=S:%s' % (IN['id'], IN['token'])
		Player = xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER)
		Player.play(url)

		setTune(__tune_file__, IN['id'])
		xbmc.executescript(__interface_file__)
		pass

	else : 
		global Resumes
		if deadOrAlive(__alive_file__):
			#print 'dead'
			# 初期モード
			clearCache()
			stamp = str(int(time.time()))

			getAuthkey()
			_auth = authenticate()
			_auth.start()
			while 'authed' not in _auth._response or _auth._response['authed'] == 0:time.sleep(0.1)

			if _auth._response['area_id'] != "":

				getStationFile(_auth._response['area_id'], __station_file__)
				getProgramFile(_auth._response['area_id'], __program_file__)
				ProgramXML = open(__program_file__, 'r').read()
				ProgramDOM = xml.dom.minidom.parseString(ProgramXML)

				StationXML = open(__station_file__, 'r').read()
				StationDOM = xml.dom.minidom.parseString(StationXML)

				BirthTime = birth(__birth_file__)

				tmpSsnId =str(BirthTime) + '-' + str(randStr(10))
				SessionR = updateSession(tmpSsnId, __access_token__, __access_token_secret__)
				#print 'SessionR:'+str(SessionR)
				if SessionR == '-1': tmpSsnId = '-1'

				Resumes[0] = int(sys.argv[1])
				Resumes[1] = BirthTime
				Resumes[2] = _auth._response['partial_key']
				Resumes[3] = _auth._response['auth_token']
				Resumes[4] = _auth._response['area_id']
				Resumes[5] = int(BirthTime) + __resume_timer_interval__
				Resumes[6] = getShortestTime(ProgramDOM)
				Resumes[7] = int(BirthTime) + __resume_session_interval__
				Resumes[8] = tmpSsnId

				setResumes(__resume_file__, Resumes)


				#stationList(_auth._response['area_id'], _auth._response['auth_token'])
				#time.sleep(__resume_timer_interval__)
			else:
				print 'failed get area'

			setResumes(__resume_file__, Resumes)

		else:
			# 継続モード
			#print 'alive'
			getResumes(__resume_file__, Resumes)
			ProgramXML = open(__program_file__, 'r').read()
			ProgramDOM = xml.dom.minidom.parseString(ProgramXML)

			StationXML = open(__station_file__, 'r').read()
			StationDOM = xml.dom.minidom.parseString(StationXML)

		BirthTime = birth(__birth_file__)

		stationList(StationDOM, ProgramDOM, Resumes[0], Resumes[3])

		while True:
			stamp = int(time.time())
			#print 'default.py:task:%s' % BirthTime
			if birthCheck(__birth_file__, BirthTime):
				break # プロセスが別に起動した場合

			elif xbmcgui.getCurrentWindowId() != 10501 and xbmcgui.getCurrentWindowId() >= 13000:
				break # WindowIDが変わった場合

			elif Resumes[5] < stamp:
				# radiko認証
				_auth = authenticate()
				_auth._response['auth_token' ] = Resumes[3]
				_auth._response['partial_key'] = Resumes[2]
				_auth.resumeTimer()
				Resumes[5] = int(time.time()) + __resume_timer_interval__
				setResumes(__resume_file__, Resumes)

			elif Resumes[6] < stamp:
				# 番組データ更新
				while True:
					getProgramFile(Resumes[4], __program_file__)
					ProgramXML = open(__program_file__, 'r').read()
					ProgramDOM = xml.dom.minidom.parseString(ProgramXML)
					prgTime = getShortestTime(ProgramDOM)
					if Resumes[6] < prgTime:
						Resumes[6] = prgTime
						break

				setResumes(__resume_file__, Resumes)
				keepAlive(__alive_file__)
				xbmc.executebuiltin('Container.Refresh')
				break # リスト更新

			elif Resumes[7] < stamp and Resumes[8] != '-1':
				# ツイッター書込セッション更新
				Resumes[8] = updateSession(Resumes[8], __access_token__, __access_token_secret__)
				Resumes[7] = int(time.time()) + __resume_session_interval__
				setResumes(__resume_file__, Resumes)


			keepAlive(__alive_file__)
			time.sleep(1)
#-------------------------------------------------------------------------------
if __name__  == '__main__': main()
