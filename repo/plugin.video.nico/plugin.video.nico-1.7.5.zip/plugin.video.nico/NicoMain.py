#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcaddon, xbmcplugin

import os
import sys
import urllib
import urllib2
#import httplib
import socket
import re ,time
import shutil
import threading
import datetime
#import locale

#import string
#import cgi
#import sgmllib
import gc
import math
import NicoVideo
import NicoAlert
import Chikuwachan
from NiconicoFarm import NiconicoFarm
from NicoSound import NicoSound
from GoogleSuggest import GoogleSuggest
from Twitter import Twitter
from Twitter import TwitterSearch

__settings__ = xbmcaddon.Addon('plugin.video.nico')

__plugin__ = __settings__.getAddonInfo('name')
__author__ = ""
__version__ = __settings__.getAddonInfo('version')

base_cache_path = os.path.join( xbmc.translatePath( "special://masterprofile/" ), "addon_data", os.path.basename( __settings__.getAddonInfo('path') ) )

root_dir = __settings__.getAddonInfo('path')
#root_dir = os.getcwd().replace(";","")
image_dir = os.path.join(root_dir,"Image")
hisDatDir = os.path.join(base_cache_path,'history')
tbn_dir = os.path.join(base_cache_path,'thumb')
lvtbn_dir = os.path.join(base_cache_path,'lvthumb')
usericon_dir = os.path.join(base_cache_path,'usericon')
chicon_dir = os.path.join(base_cache_path,'chicon')
coicon_dir = os.path.join(base_cache_path,'coicon')
stream_dir = os.path.join(base_cache_path,'stream')
cache_dir = os.path.join(base_cache_path,'cache')
comment_dir = os.path.join(base_cache_path,'comment')
twittericon_dir = os.path.join(base_cache_path,'twittericon')

nico_py = os.path.join(root_dir,'NicoCommentView.py')
favorite_txt = os.path.join(base_cache_path,"favorite.txt")

noimage_tbn = os.path.join(image_dir,'noimage.jpg')
dummy_tbn = os.path.join(image_dir,'dummy.png')

#sys.path.append(os.path.join(os.getcwd().replace(";",""),'lib'))
#import My_http
#import BeautifulSoup

lock = threading.RLock()

#get actioncodes from keymap.
ACTION_PREVIOUS_MENU = 10 # ･･････ Backキー/MENUキー
ACTION_PARENT_DIR = 9 # ･･････ Bボタン
ACTION_PARENT_DIR_Remote = 39 # ･･････ Back
ACTION_Right_ThumbStick = 265 # 右アナログスティック
ACTION_SHOW_GUI = 18  #X Button
ACTION_MOVE_LEFT = 1 # ･･････ 左移動キー
ACTION_MOVE_RIGHT = 2 # ･･････ 右移動キー
ACTION_MOVE_UP = 3 # ･･････ 上移動キー
ACTION_MOVE_DOWN = 4 # ･･････ 下移動キー
ACTION_SELECT_ITEM = 7 # ･･････ Aボタン
ACTION_HIGHLIGHT_ITEM = 8
ACTION_SHOW_INFO = 11

RANKING_WORK_ID = 0
MYLIST_WORK_ID = 1
WATCHLIST_WORK_ID = 2
CHANNEL_WORK_ID = 3
LIVE_WORK_ID = 4
OTHER_WORK_ID = 5

RANK_TYPE_NAME_LIST = ["総合","再生","コメント","マイリスト"]
RANK_TYPE_DATA_LIST = ["fav","view","res","mylist"]

RANKING_LIST1_NAME_ARRAY = (
"登録ワード",

"お気に入りタグ",
"注目のタグ",

"毎時 ランキング",
"日間 ランキング",
"週間 ランキング",
"月間 ランキング",
"合計 ランキング",

"新着投稿動画",

"★エンタ・音楽","エンターテイメント","音楽","歌ってみた","演奏してみた","踊ってみた","VOCALOID","ニコニコインディーズ",
"★生活・一般・スポ","動物","料理","自然","旅行","スポーツ","ニコニコ動画講座","車載動画","歴史",
"★政治",
"★科学・技術","科学","ニコニコ技術部","ニコニコ手芸部","作ってみた",
"★アニメ・ゲーム・絵","アニメ","ゲーム","東方","アイドルマスター","ラジオ","描いてみた",
"★その他","例のアレ","日記","その他",
"★R-18",
#"よしよし動画(仮)",
#"avex公式",
#"アイドル★グラビア動画"
)


RANKING_LIST1_CATEGORY_ARRAY = [
"myTAG",
None,
"major_tag",

None,
None,
None,
None,
None,

"newarrival",

"top/g_ent2","top/ent","top/music","top/sing","top/play","top/dance","top/vocaloid","top/nicoindies",
"top/g_life2","top/animal","top/cooking","top/nature","top/travel","top/sport","top/lecture","top/drive","top/history",
"top/g_politics",
"top/g_tech","top/science","top/tech","top/handcraft","top/make",
"top/g_culture","top/anime","top/game","top/toho","top/imas","top/radio","top/draw",
"top/g_other","top/are","top/diary","top/other",
"top/g_r18",

#"tag/%E3%82%88%E3%81%97%E3%82%88%E3%81%97%E5%8B%95%E7%94%BB%28%E4%BB%AE%29",
#"tag/avex公式",
#"tag/%E3%82%A2%E3%82%A4%E3%83%89%E3%83%AB%E2%98%85%E3%82%B0%E3%83%A9%E3%83%93%E3%82%A2%E5%8B%95%E7%94%BB"
]


RANKING_LIST2_NAME_ARRAY = [
"★カテゴリ合算",
"・エンタ・音楽","エンターテイメント","音楽","歌ってみた","演奏してみた","踊ってみた","VOCALOID","ニコニコインディーズ",
"・生活・一般・スポ","動物","料理","自然","旅行","スポーツ","ニコニコ動画講座","車載動画","歴史",
"・政治",
"・科学・技術","科学","ニコニコ技術部","ニコニコ手芸部","作ってみた",
"・アニメ・ゲーム・絵","アニメ","ゲーム","東方","アイドルマスター","ラジオ","描いてみた",
"・その他","例のアレ","日記","その他",
"・R-18"
#"投稿者コメント",
#"アンケート",
#"チャット",
#"テスト",
#"ニコニ・コモンズ",
#"ひとこと動画",
#"・エンタ・音楽・スポ",
#"・教養・生活",
#"・殿堂入りカテゴリ",
#"・やってみた",
]

RANKING_LIST2_CATEGORY_ARRAY = [
"all",
"g_ent2","ent","music","sing","play","dance","vocaloid","nicoindies",
"g_life2","animal","cooking","nature","travel","sport","lecture","drive","history",
"g_politics",
"g_tech","science","tech","handcraft","make",
"g_culture","anime","game","toho","imas","radio","draw",
"g_other","are","diary","other",
"g_r18"
#"owner",
#"que",
#"chat",
#"test",
#"commons",
#"hitokoto",
#"g_ent",
#"g_life",
#"g_popular",
#"g_try",
]

#
#RANKING_LIST2_NAME_ARRAY = [
#"★カテゴリ合算",
#"・エンタ・音楽・スポ ","エンターテイメント","音楽","スポーツ",
#"・教養・生活","動物","料理","日記","自然","科学","歴史","ラジオ","ニコニコ動画講座",
#"・政治",
#"・やってみた","歌ってみた","演奏してみた","踊ってみた","描いてみた","ニコニコ技術部",
#"・アニメ・ゲーム","アニメ","ゲーム",
#"・殿堂入りカテゴリ","アイドルマスター","東方","VOCALOID","例のアレ","その他",
#"・R-18"
##"投稿者コメント",
##"アンケート",
##"チャット",
##"テスト",
##"ニコニ・コモンズ",
##"ひとこと動画"
#]
#
#RANKING_LIST2_CATEGORY_ARRAY = [
#"all",
#"g_ent","ent","music","sport",
#"g_life","animal","cooking","diary","nature","science","history","radio","lecture",
#"g_politics",
#"g_try","sing","play","dance","draw","tech",
#"g_culture","anime","game",
#"g_popular","imas","toho","vocaloid","are","other",
#"g_r18"
##"owner",
##"que",
##"chat",
##"test",
##"commons",
##"hitokoto",
#]

#ソート一覧項目名
NICO_SORT_NAME_ARRAY =(
"コメントが新しい順",
"コメントが古い順",
"再生が多い順",
"再生が少ない順",
"コメントが多い順",
"コメントが少ない順",
"マイリストが多い順",
"マイリストが少ない順",
"投稿が新しい順",
"投稿が古い順",
"時間が長い順",
"時間が短い順"
)

#検索動画のソート条件
NICO_SEARCH_VIDEO_SORT_DATA_ARRAY =(
	["n","d"],#コメントが新しい順
	["n","a"],#コメントが古い順
	["v","d"],#再生が多い順
	["v","a"],#再生が少ない順
	["r","d"],#コメントが多い順
	["r","a"],#コメントが少ない順
	["m","d"],#マイリスト登録が多い順
	["m","a"],#マイリスト登録が少ない順	# chg 6-128秋+
	["f","d"],#投稿日時が新しい順
	["f","a"],#投稿日時が古い順
	["l","d"],#再生時間が長い順		# add 6-128秋+
	["l","a"]#再生時間が短い順	# add 6-128秋+
	)

#マイリスト動画のソート条件
NICO_MYLIST_VIDEO_SORT_DATA_ARRAY =(
	7,#コメントが新しい順
	7,#コメントが古い順
	2,#再生が多い順
	2,#再生が少ない順
	3,#コメントが多い順
	3,#コメントが少ない順
	4,#マイリスト登録が多い順
	4,#マイリスト登録が少ない順
	6,#投稿日時が新しい順
	6,#投稿日時が古い順
	5,#再生時間が長い順
	5 #再生時間が短い順
	)

#その他関連
OTHER_LIST_NAME_ARRAY = (
"保存フォルダ",
"視聴履歴",
"動画IDの入力",
"にこ★さうんど＃",
"ニコニコファーム",
"ツイッター",
"Twitter検索"
)


NICO_MLR_CHOOSE_ARRAY = [
"総合",
"実況プレイ",
"ゲーム",
"VOCALOID",
"MAD",
"演奏してみた",
"歌ってみた",
"踊ってみた",
"その他",
"ゴミ箱",
"未カテゴリ"
]

NICO_MLR_CHOOSE_CATE_ARRAY = [
"0",
"1",
"2",
"3",
"4",
"5",
"6",
"7",
"10",
"11",
"12"
]

NICO_SOUND_CHOOSE_ARRAY = [
"ランキング",
"新着",
"最近の再生"
]

NICO_SOUND_CHOOSE_CATE_ARRAY = [
"ranking.aspx",
"new.aspx",
"last_play.aspx",
]

#ニコ生

LIVE_TAB_ARRAY = ['common','try','live','req','face','totu','r18']
LIVE_TAB_NAME_ARRAY = ['一般','やってみた','ゲーム','動画紹介','顔出し','凸待ち','R-18']

#ニコニコ生放送:Q

#カテゴリー用
LIVE_SORT_ARRAY_RSS = ['start_time','start_time','view_counter','view_counter','comment_num','comment_num','community_level','community_level','community_create_time','community_create_time']
LIVE_ORDER_ARRAY_RSS = ['desc','asc','desc','asc','desc','asc','desc','asc','desc','asc']
LIVE_SORT_NAME_ARRAY_RSS = ['放送日時が近い順','放送日時が遠い順','来場者数が多い順','来場者数が少ない順','コメント数が多い順','コメント数が少ない順','コミュレベルが高い順','コミュレベルが低い順','コミュニティが新しい順','コミュニティが古い順','アクティブ人数順','184人数順','アクティブ率順','184率順','184外し率順','アクティブ人数順(ルーキー)','184人数順(ルーキー)','アクティブ率順(ルーキー)','184率順(ルーキー)','184外し率順(ルーキー)']

#検索用
LIVE_SORT_ARRAY = ['recent','recent_r','user','user_r','comment','comment_r','comlevel','comlevel_r','comcreated','comcreated_r','point','ts','ts_r']
LIVE_SORT_NAME_ARRAY = ['放送日時が近い順','放送日時が遠い順','来場者数が多い順','来場者数が少ない順','コメント数が多い順','コメント数が少ない順','コミュレベルが高い順','コミュレベルが低い順','コミュニティが新しい順','コミュニティが古い順','適合率の高い順','タイムシフト予約数が多い順','タイムシフト予約数が少ない順','アクティブ人数順','184人数順','アクティブ率順','184率順','184外し率順','アクティブ人数順(ルーキー)','184人数順(ルーキー)','アクティブ率順(ルーキー)','184率順(ルーキー)','184外し率順(ルーキー)']

LIVE_QRANKING_NAME_ARRAY = ["生放送中ランキング","番組予約数ランキング","過去の番組ランキング"]
LIVE_QRANKING_TYPE_ARRAY = ["onair","comingsoon","closed"]

LIVE_TAGS_SORT_ARRAY = ['start','view','tnum','level','grow','actv']
LIVE_TAGS_SORT_NAME_ARRAY = ['新しい番組順','視聴者数が多い順','コメントが多い順','コミュレベルが高い順','話題のコミュニティ順','活発なコミュニティ順','アクティブ人数順','184人数順','アクティブ率順','184率順','184外し率順','アクティブ人数順(ルーキー)','184人数順(ルーキー)','アクティブ率順(ルーキー)','184率順(ルーキー)','184外し率順(ルーキー)']
LIVE_RANKING_NAME_ARRAY = ["放送中番組","放送予定番組","過去番組"]
LIVE_RANKING_TYPE_ARRAY = ["onair","comingsoon","closed"]


#import urllib, xml.dom.minidom
#from default import getExistsFolder, regulate_filename

#prefix = [
#["ax","エイベックス公式"],
#["ca","超アニメロ"],
#["ch","ニコニコチャンネル"],
#["co","ニコニコミュニティ"],
#["cw","キャラウッド公式"],
#["fx","MTV公式"],
#["lv","ニコニコ生放送"],
#["my","ニコニコ動画マイリスト"],
#["mv","ニコニコ動画投稿動画"],
#["na","Livedoorネットアニメ"],
#["nc","ニコニ・コモンズ"],
#["nl","ニコニコ生放送アーカイヴ"],
#["nm","ニコニコムービメーカー"],
#["nv","ニコニコ動画広域"],
#["nu","ニコニコユーザープロフ"],
#["nu","ニコニコユーザープロフ"],
#["sk","Spike公式"],
#["sm","SMILEVIDEO"],
#["so","ニコニコ動画公式"],
#["yo","よしよし動画"],
#["za","ニコニコアニメ公式"],
#["zb","ニコアニラジオ・TV"],
#["zc","ニコアニニュース"],
#["zd","ai sp@ce"],
#["ze","虹視聴覚室"]
#]

#DAILY_SOUGOU_RANKING_CATEGORY = ["エンタ・音楽・スポ","教養・生活","政治","やってみた","アニメ・ゲーム","殿堂入りカテゴリ"]
#DAILY_SOUGOU_RANKING_CATEGORY_URL = [
#"http://www.nicovideo.jp/ranking/fav/daily/g_ent",
#"http://www.nicovideo.jp/ranking/fav/daily/g_life",
#"http://www.nicovideo.jp/ranking/fav/daily/g_politics",
#"http://www.nicovideo.jp/ranking/fav/daily/g_try",
#"http://www.nicovideo.jp/ranking/fav/daily/g_culture",
#"http://www.nicovideo.jp/ranking/fav/daily/g_culture",
#"http://www.nicovideo.jp/ranking/fav/daily/g_popular"
#]


NO_TITLE = "x-x-x-x-x-x-x-x-x-x-x-x-x-x"

screen_width = None
screen_height = None

try: Emulating = xbmcgui.Emulating
except: Emulating = False

class END(Exception): pass

def list2set(list):
	set = []
	for i in list:
		if not i in set:
			set.append(i)
	return set

def tr_all(str, remove_list, replace):
	for rem in remove_list:
		str = str.replace(rem, replace)
	return str

def regulate_filename(str):
	code = 'utf-8'
	str = str.encode(code, 'ignore')
	return tr_all(str, '\\/:?*', '_').replace('..', '_')

def getTitlePrefix(video_id):
	prefix = video_id[0:2]
	if prefix == "sm" or prefix == "so" or video_id.isdigit():
		return ""
	elif  prefix == "nm":
		return "(T^T)->"
	elif  prefix == "lv":
		return "(T^T)->"
	return "?->"

def convertTime(second):
	return '%(m)d:%(s)02d' % {'m':second/60,'s':second%60}

skin_font_path = xbmc.translatePath("special://skin/fonts/")
script_font_path = os.path.join(root_dir , "resources" , "fonts")
#script_font_path = os.path.join(os.getcwd() , "resources" , "fonts")
skin_dir = xbmc.translatePath("special://skin/")
list_dir = os.listdir( skin_dir )

def getFontsXMLPath():
	for item in list_dir:
		item = os.path.join( skin_dir, item )
		if os.path.isdir( item ):
			font_xml = os.path.join( item, "Font.xml" )
			if os.path.exists( font_xml ):
				return font_xml
	return ""

def sortArrayTop(x,y):
	return x[1]-y[1]

class MyClass(xbmcgui.Window):
	running = True

	font_path = getFontsXMLPath();
	backup_font_path = font_path + "~"

	time_shift = False

	searchKindArray = ["content","tag"]
	live_search_kind = searchKindArray[int(__settings__.getSetting("live_search_kind"))]

	# 作業ID
	Work_Group_ID = None;
	List1_Index = 0
	List2_Index = 0
	List3_Index = 0

	# [(表示名,データ),...]
	List1_Data_Tuple_List = []
	List2_Data_Tuple_List = []
	List3_Data_Tuple_List = []

	# 全てのリストを戻すための履歴
	list_data_history_back_list = []
	history_stock = None

	# チャンネル情報
	CHANNEL_LIST_NAME_ARRAY = None
	CHANNEL_ARRAY = None

	choose_cont = 0
	isOnControl = False
	TAG_FLAG = False

	file_num_re = re.compile("[a-z]*([0-9]*)")
	MAX_HISTORY = 9

	MAX_TBN_RETRY_COUNT = 1
	TBN_DOWN_THREAD_MAX = 5
	tbn_down_allcount = 0
	tbn_down_count = 0
	tbn_down_error_count = 0
	tbn_down_thread_count = 0

	NICO_MLR_CATE = 0

	alertLiveList = []
	nicoliveAntennaGetThread = None
	nicoliveAntennaAlertThread = None
	alertLiveID = None
	alertLiveTitle = None
	community_id_list = None
	isStartVideoPlayer = False
	isStartVideoPlayerSuccess = False

	input_video_id = ""

	def __init__(self):
		global screen_width,screen_height

		self.__dbg__ = __settings__.getSetting( "debug" ) == "true"

		self.MailAddress = __settings__.getSetting("mailaddress")
		self.PassWord = __settings__.getSetting("password")
		self.ranking_type = int(__settings__.getSetting("ranking_type"))
		self.ranking_type_select = __settings__.getSetting("ranking_type_select") == "true"
		self.live_sort_type = int(__settings__.getSetting("live_sort_type"))
		self.live_sort_type_select = __settings__.getSetting("live_sort_type_select") == "true"
		self.isStreaming = __settings__.getSetting("streaming") == "true"
		self.comment_view = __settings__.getSetting("comment_view") == "true"
		self.Cache_directory = __settings__.getSetting("download_path")
		self.economyMode = __settings__.getSetting("economy")  == "true"
		self.comment_update = __settings__.getSetting("comment_update")  == "true"
		self.commentArray = [0,250,500,1000]
		self.MAX_COMMENT_NUM = self.commentArray[int(__settings__.getSetting("comment_num"))]
		self.searchTorkArray = ["tag","search","mylist_search"]
		self.serch_TorK = self.searchTorkArray[int(__settings__.getSetting("search_type"))]
		self.search_keyword = __settings__.getSetting("search_keyword").split(',')
		self.economyConfirm = __settings__.getSetting("economy_confirm") == "true"
		self.save_comment = __settings__.getSetting("save_comment") == "true"
		self.save_history = __settings__.getSetting("save_history") == "true"
		self.view_watched = __settings__.getSetting("watch_video_prefix") == "true"
		self.view_watched_prefix = [__settings__.getSetting("not_watch_video_prefix_str"),__settings__.getSetting("watch_video_prefix_str")]

		self.detail_mylist_comment = __settings__.getSetting("detail_mylist_comment") == "true"
		self.detail_recommend_video = __settings__.getSetting("detail_recommend_video") == "true"
		self.detail_public_mylist = __settings__.getSetting("detail_public_mylist") == "true"
		self.detail_nicosound = __settings__.getSetting("detail_nicosound") == "true"
		self.detail_twitter_comment = __settings__.getSetting("detail_twitter_comment") == "true"

		self.niconama_alert = __settings__.getSetting( "niconama_alert" ) == "true"
		self.niconama_alert_official = __settings__.getSetting("niconama_alert_official") == "true"
		self.niconama_alert_view_time = float(__settings__.getSetting("niconama_alert_view_time"))/1000
		self.niconama_alert_time_of_start = __settings__.getSetting("niconama_alert_time_of_start") == "true"
		self.playerstatus_update_interval = float(__settings__.getSetting("playerstatus_update_interval"))/1000

		self.screen_autoset = __settings__.getSetting("screen_autoset") == "true"

		self.liveErrorFullRetryCount = int(float(__settings__.getSetting("live_error_full_retry_count")))

		self.max_temporary_file_num = int(float(__settings__.getSetting("max_temporary_file_num")))

#		self.setCoordinateResolution(5) #RES_HDTV_720p
		screen_width = 1280
		screen_height = 720

#		screen_width = self.getWidth()
#		screen_height = self.getHeight()

		self.scaleX = (float(screen_width)  / float(640))
		self.scaleY = (float(screen_height) / float(480))

		if self.__dbg__: print "getResolution = %s" % (self.getResolution())

		print "Width,Height: %s,%s" % (self.getWidth(),self.getHeight())
		print "scaleX,scaleY: %s,%s" % (self.scaleX,self.scaleY)

		self.tweet_user_id_list = []
		for i in range(20):
			user_id = __settings__.getSetting("tweet_user_id_%s" % (i+1))
			if user_id:
				self.tweet_user_id_list.append(user_id)

		self.nicoVideo = NicoVideo.NicoVideo()
		self.nicoVideo.mailAddress = self.MailAddress
		self.nicoVideo.passWord = self.PassWord
		self.nicoVideo.force_overwrite = True
		self.nicoVideo.save_message_xml = True
		self.nicoVideo.process_list = False
		self.nicoVideo.list_url = ''

		self.nicoVideo.maxCommentNum = self.MAX_COMMENT_NUM
		self.nicoVideo.root_dir = base_cache_path
		self.nicoVideo.loadCookie()
#		self.nicoVideo.loginNicoVideo()
		self.nicoVideo.establishConnection()

		self.setView()

#		self.ranking_button.controlUp(self.Other_button)
		self.ranking_button.controlDown(self.MyList_button)
		self.ranking_button.controlLeft(self.Setting_button)
		self.ranking_button.controlRight(self.list3)

		self.MyList_button.controlUp(self.ranking_button)
		self.MyList_button.controlDown(self.WatchList_button)
		self.MyList_button.controlLeft(self.Setting_button)
		self.MyList_button.controlRight(self.list3)

		self.WatchList_button.controlUp(self.MyList_button)
		self.WatchList_button.controlDown(self.Channel_button)
		self.WatchList_button.controlLeft(self.Setting_button)
		self.WatchList_button.controlRight(self.list3)

		self.Channel_button.controlUp(self.WatchList_button)
		self.Channel_button.controlDown(self.Niconama_button)
		self.Channel_button.controlLeft(self.Setting_button)
		self.Channel_button.controlRight(self.list3)


		self.Niconama_button.controlUp(self.Channel_button)
		self.Niconama_button.controlDown(self.Other_button)
		self.Niconama_button.controlLeft(self.Setting_button)
		self.Niconama_button.controlRight(self.list3)

		self.Other_button.controlUp(self.Niconama_button)
		self.Other_button.controlDown(self.ranking_button)
		self.Other_button.controlLeft(self.Setting_button)
		self.Other_button.controlRight(self.list3)

		self.Setting_button.controlUp(self.Other_button)
		self.Setting_button.controlDown(self.JIMAKU_CMark)
		self.Setting_button.controlRight(self.list1)

		self.test1.controlRight(self.JIMAKU_CMark)
		self.test1.controlLeft(self.test2)
		self.test2.controlRight(self.test1)

#		self.Search_CMark.controlUp(self.Setting_button)
#		self.Search_CMark.controlDown(self.Ranking_Type)
#		self.Search_CMark.controlRight(self.list1)
#		self.Search_CMark.setSelected(True)

		self.JIMAKU_CMark.controlUp(self.Setting_button)
		self.JIMAKU_CMark.controlLeft(self.test1)
		self.JIMAKU_CMark.controlRight(self.list1)
		self.JIMAKU_CMark.controlDown(self.Ranking_Type)
		self.JIMAKU_CMark.setSelected(self.comment_view)

		self.Ranking_Type.controlUp(self.JIMAKU_CMark)
		self.Ranking_Type.controlDown(self.XMLUpdate_CMark)
		self.Ranking_Type.controlRight(self.list1)
		self.Ranking_Type.setSelected(True)

		self.XMLUpdate_CMark.controlUp(self.Ranking_Type)
		self.XMLUpdate_CMark.controlDown(self.EconomyMode_CMark)
		self.XMLUpdate_CMark.controlRight(self.list1)
		self.XMLUpdate_CMark.setSelected(self.comment_update)

		self.EconomyMode_CMark.controlUp(self.XMLUpdate_CMark)
		self.EconomyMode_CMark.controlDown(self.Streaming_CMark)
		self.EconomyMode_CMark.controlRight(self.list1)
		self.EconomyMode_CMark.setSelected(self.economyMode)


		self.Streaming_CMark.controlUp(self.EconomyMode_CMark)
		self.Streaming_CMark.controlDown(self.TimeShift_CMark)
		self.Streaming_CMark.controlRight(self.list1)
		self.Streaming_CMark.setSelected(self.isStreaming)

		self.TimeShift_CMark.controlUp(self.Streaming_CMark)
		self.TimeShift_CMark.controlDown(self.Alert_CMark)
		self.TimeShift_CMark.controlRight(self.list1)
#		self.TimeShift_CMark.setSelected(self.time_shift)


		self.Alert_CMark.controlUp(self.TimeShift_CMark)
		self.Alert_CMark.controlDown(self.font_CMark)
		self.Alert_CMark.controlRight(self.list1)
		self.Alert_CMark.setSelected(self.niconama_alert)

		self.font_CMark.controlUp(self.Alert_CMark)
		self.font_CMark.controlDown(self.END_CMark)
		self.font_CMark.controlRight(self.list1)
		self.font_CMark.setSelected(os.path.exists(self.backup_font_path))

		self.END_CMark.controlUp(self.font_CMark)
		self.END_CMark.controlRight(self.list1)

		self.list1.controlLeft(self.Setting_button)
		self.list1.controlRight(self.list2)
		self.list2.controlLeft(self.list1)
		self.list2.controlRight(self.list3)
#		self.list3.controlUp(self.nico_Update_button)
		self.list3.controlLeft(self.list2)
		self.list3.controlRight(self.Update_List)

		self.Update_List.controlLeft(self.list3)
		self.Update_List.controlRight(self.Page_Num_List)
#		self.Update_List.controlDown(self.list3)

		self.Page_Num_List.controlLeft(self.Update_List)
		self.Page_Num_List.controlRight(self.nico_Update_button)
#		self.Page_Num_List.controlDown(self.list3)

		self.nico_Update_button.controlLeft(self.Page_Num_List)
		self.nico_Update_button.controlRight(self.back_button)
		self.nico_Update_button.controlDown(self.list3)

		self.back_button.controlDown(self.list3)
		self.back_button.controlLeft(self.nico_Update_button)
#		self.back_button.controlRight(self.list3)

# =↑ここまで====↑アイテム間のFoucus移動に関する設定==========================

		if self.niconama_alert:
			self.nicoliveAntennaGetThread = threading.Thread(target=self.nicoliveAntennaGet,args=())
			self.nicoliveAntennaGetThread.setDaemon(True)
			self.nicoliveAntennaGetThread.start()

			self.nicoliveAntennaAlertThread = threading.Thread(target=self.nicoliveAntennaAlert,args=())
			self.nicoliveAntennaAlertThread.setDaemon(True)
			self.nicoliveAntennaAlertThread.start()

		if self.__dbg__: self.initWatchMemory()
		xbmc.enableNavSounds(True)
		self.Mes_BOX("%s Version %s" % (__plugin__,__version__))

	def setView(self):

		# ===========背景画像設定=========== #
		background = None
		files = os.listdir(os.path.join(image_dir,'background'))
		if len(files) != 0:
			background = os.path.join(os.path.join(image_dir,'background'),files[0])


		if os.path.isfile(os.path.join(image_dir,'bg001.png')):
			bg1 =  os.path.join(image_dir,'bg001.png')

		bg0 = bg1

		if os.path.isfile(os.path.join(image_dir,'bg002.png')):
			bg2 = os.path.join(image_dir,'bg002.png')

		if os.path.isfile(os.path.join(image_dir,"Right_top.png")):
			Right_top =  os.path.join(image_dir,'Right_top.png')
		else:
			Right_top = os.path.join(os.path.join(root_dir,"Image"),'Right_top.png')
		# ========ここまで背景画像設定======= #

		List1_3_kaigyou = 15 + 8
#		Size_of_char = 1
#		if screen_width>=1280:
#			Size_of_char = 1.35
		Size_of_char = 1.35

		if background != None:
			self.Image_background = xbmcgui.ControlImage(0,0,screen_width,screen_height, background)
			self.addControl(self.Image_background)

		self.Image_BG = xbmcgui.ControlImage(int(54 * self.scaleX),int(168 * self.scaleY),int(116 * self.scaleX),int(287 * self.scaleY), bg0)
		self.addControl(self.Image_BG)

		try:
			xbmcgui.ControlList(0, 0, 0, 0, itemTextXOffset = 0, itemTextYOffset = 0, itemHeight = 0)
			self.isOldVer = True
		except :
			self.isOldVer = False

		if self.isOldVer:
			self.list1 = xbmcgui.ControlList(int(57 * self.scaleX), int(178 * self.scaleY), int(107 * self.scaleX),int(279 * self.scaleY), 'font13', itemTextXOffset = -5,itemTextYOffset= -2,itemHeight = int(List1_3_kaigyou * Size_of_char)
											,buttonFocusTexture='button-focus.png'
											 )
			self.list2 = xbmcgui.ControlList(int(180 * self.scaleX), int(185 * self.scaleY), int(108 * self.scaleX), int(279 * self.scaleY), 'font13', itemTextXOffset = -5, itemTextYOffset= -2, itemHeight = int(List1_3_kaigyou * Size_of_char)
											 ,buttonFocusTexture='button-focus.png'
											 )
			self.list3 = xbmcgui.ControlList(int(304 * self.scaleX), int(195 * self.scaleY), int( 316 * self.scaleX), int(278 * self.scaleY), 'font13', itemTextXOffset = -5, itemTextYOffset= -2, itemHeight =int(List1_3_kaigyou * Size_of_char)
											 ,buttonFocusTexture='button-focus.png'
											 )

			self.Update_List = xbmcgui.ControlList(int(306 * self.scaleX), int(158 * self.scaleY), int( 150 * self.scaleX), int(52 * self.scaleY), 'font13', textColor = "0xFFEEEEEE", itemTextXOffset = int(5*self.scaleX), itemTextYOffset= 0, itemHeight = int(22 * self.scaleY)
												,buttonFocusTexture=os.path.join(image_dir,'button_focus.png'), buttonTexture =os.path.join(image_dir,'button_focus_off.png')
												)
			self.Page_Num_List = xbmcgui.ControlList(int(460 * self.scaleX), int(158 * self.scaleY), int(65 * self.scaleX), int(52 * self.scaleY), 'font13', textColor = "0xFFEEEEEE", itemTextXOffset = int(5*self.scaleX), itemTextYOffset= 0, itemHeight = int(22 * self.scaleY)
													,buttonFocusTexture=os.path.join(image_dir,'button_focus2.png'), buttonTexture =os.path.join(image_dir, 'button_focus_off2.png')
													)
		else:
			self.list1 = xbmcgui.ControlList(int(57 * self.scaleX), int(178 * self.scaleY), int(107 * self.scaleX),int(279 * self.scaleY), 'font13', _itemTextXOffset =-5, _itemTextYOffset= -2, _itemHeight = int(List1_3_kaigyou * Size_of_char)
											#,buttonFocusTexture=os.path.join(image_dir,'button-focus.png')
											,buttonFocusTexture='button-focus.png'
											 )
			self.list2 = xbmcgui.ControlList(int(180 * self.scaleX), int(185 * self.scaleY), int(108 * self.scaleX), int(279 * self.scaleY), 'font13', _itemTextXOffset = -5, _itemTextYOffset= -2, _itemHeight = int(List1_3_kaigyou * Size_of_char)
											 ,buttonFocusTexture='button-focus.png'
											 )
			self.list3 = xbmcgui.ControlList(int(304 * self.scaleX), int(195 * self.scaleY), int( 316 * self.scaleX), int(278 * self.scaleY), 'font13', _itemTextXOffset = -5, _itemTextYOffset= -2, _itemHeight = int(List1_3_kaigyou * Size_of_char)
											 ,buttonFocusTexture='button-focus.png'
											 )

			self.Update_List = xbmcgui.ControlList(int(306 * self.scaleX), int(158 * self.scaleY), int( 150 * self.scaleX), int(52 * self.scaleY), 'font13', textColor = "0xFFEEEEEE", _itemTextXOffset = int(5*self.scaleX), _itemTextYOffset= 0, _itemHeight = int(22 * self.scaleY)
												,buttonFocusTexture=os.path.join(image_dir,'button_focus.png'), buttonTexture =os.path.join(image_dir, 'button_focus_off.png')
												)
			self.Page_Num_List = xbmcgui.ControlList(int(460 * self.scaleX), int(158 * self.scaleY), int(65 * self.scaleX), int(52 * self.scaleY), 'font13', textColor = "0xFFEEEEEE", _itemTextXOffset = int(5*self.scaleX), _itemTextYOffset= 0, _itemHeight = int(22 * self.scaleY)
													,buttonFocusTexture=os.path.join(image_dir,'button_focus2.png'), buttonTexture =os.path.join(image_dir, 'button_focus_off2.png')
													)

		self.addControl(self.list1)

		self.Image_BG2 = xbmcgui.ControlImage(int(177 * self.scaleX),int(175 * self.scaleY),int(117 * self.scaleX),int(287 * self.scaleY),bg1)
		self.addControl(self.Image_BG2)

		self.addControl(self.list2)

		self.Image_BG3 = xbmcgui.ControlImage(int(301 * self.scaleX),int(185 * self.scaleY),int(325 * self.scaleX),int(280 * self.scaleY),bg2)
		self.addControl(self.Image_BG3)

#		self.list3.setPageControlVisible(True)
		self.addControl(self.list3)

		self.Image_Right_TOP = xbmcgui.ControlImage(int(295 * self.scaleX),int(10 * self.scaleY),int( 331 * self.scaleX),int(140 * self.scaleY), Right_top)
		self.addControl(self.Image_Right_TOP)

		self.Textbox_Right_TOP = xbmcgui.ControlTextBox(int(325 * self.scaleX),int(18 * self.scaleY),int(283 * self.scaleX),int(118* self.scaleY),font = 'font13', textColor = "0xFFEEEEEE")
		self.addControl(self.Textbox_Right_TOP)

		self.addControl(self.Update_List)
		for name in NICO_SORT_NAME_ARRAY:
			self.Update_List.addItem(name)

		self.addControl(self.Page_Num_List)
		for i in range(10):
			self.Page_Num_List.addItem(str(i+1))

		self.nico_Update_button = xbmcgui.ControlButton(int(528 * self.scaleX),int(158 * self.scaleY),int(62 * self.scaleX),int(22 * self.scaleY), r"更新",font = 'font13',textOffsetX=int(18*self.scaleX)
													,focusTexture=os.path.join(image_dir,'button_focus2.png'),noFocusTexture =os.path.join(image_dir,'button_focus_off2.png')
													)
		self.addControl(self.nico_Update_button)


		self.back_button = xbmcgui.ControlButton(int(590 * self.scaleX),int(154 * self.scaleY),int(24 * self.scaleX),int(24 * self.scaleY), r"",font = 'font13',textOffsetX=int(25*self.scaleX)
													,focusTexture=os.path.join(image_dir,'back-noforcus.png'),noFocusTexture =os.path.join(image_dir,'back-forcus.png')
													)
		self.addControl(self.back_button)

		self.back_num_image = xbmcgui.ControlImage(int(613 * self.scaleX),int(166 * self.scaleY),int(15 * self.scaleX),int(15 * self.scaleY),os.path.join(os.path.join(image_dir,'num'),'0.gif'))
		self.addControl(self.back_num_image)
		self.back_num_image.setVisible(True)



		self.ranking_button = xbmcgui.ControlButton(int(15 * self.scaleX),int(9 * self.scaleY),int(125 * self.scaleX),int(22 * self.scaleY), r"ランキング",font = 'font13'
												,focusTexture=os.path.join(image_dir,'button_focus.png'),noFocusTexture =os.path.join(image_dir,'button_focus_off.png'),textOffsetX=int(18*self.scaleX)
												)
		self.addControl(self.ranking_button)
		self.setFocus(self.ranking_button)

		self.MyList_button = xbmcgui.ControlButton(int(15 * self.scaleX),int(34 * self.scaleY),int(125 * self.scaleX),int(22 * self.scaleY), r"マイリスト",font = 'font13'
												,focusTexture=os.path.join(image_dir,'button_focus.png'),noFocusTexture =os.path.join(image_dir,'button_focus_off.png'),textOffsetX=int(18*self.scaleX)
												)
		self.addControl(self.MyList_button)

		self.WatchList_button = xbmcgui.ControlButton(int(15 * self.scaleX),int(58 * self.scaleY),int(125 * self.scaleX),int(22 * self.scaleY), r"お気に入りユーザー",font = 'font13'
												,focusTexture=os.path.join(image_dir,'button_focus.png'),noFocusTexture =os.path.join(image_dir,'button_focus_off.png'),textOffsetX=int(18*self.scaleX)
												)
		self.addControl(self.WatchList_button)

		self.Channel_button = xbmcgui.ControlButton(int(15 * self.scaleX),int(82 * self.scaleY),int(125 * self.scaleX),int(22 * self.scaleY), r"チャンネル",font = 'font13'
												,focusTexture=os.path.join(image_dir,'button_focus.png'),noFocusTexture =os.path.join(image_dir,'button_focus_off.png'),textOffsetX=int(18*self.scaleX)
												)
		self.addControl(self.Channel_button)

		self.Niconama_button = xbmcgui.ControlButton(int(15 * self.scaleX),int(106 * self.scaleY),int(125 * self.scaleX),int(22 * self.scaleY), r"生放送",font = 'font13'
												,focusTexture=os.path.join(image_dir,'button_focus.png'),noFocusTexture =os.path.join(image_dir,'button_focus_off.png'),textOffsetX=int(18*self.scaleX)
												)
		self.addControl(self.Niconama_button)

		self.Other_button = xbmcgui.ControlButton(int(15 * self.scaleX),int(130 * self.scaleY),int(125 * self.scaleX),int(22 * self.scaleY), r"その他",font = 'font13'
												,focusTexture=os.path.join(image_dir,'button_focus.png'),noFocusTexture =os.path.join(image_dir,'button_focus_off.png'),textOffsetX=int(18*self.scaleX)
												)
		self.addControl(self.Other_button)


		self.test1 = xbmcgui.ControlCheckMark(int(-50 * self.scaleX),int(137 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"ガ",font = 'font12',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX))
		self.addControl(self.test1)

		self.test2 = xbmcgui.ControlCheckMark(int(-50 * self.scaleX),int(137 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"ガ",font = 'font12',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX))
		self.addControl(self.test2)

		#
		self.Setting_button = xbmcgui.ControlButton(int(11 * self.scaleX),int(158 * self.scaleY),int(22 * self.scaleX),int(22 * self.scaleY), r"",font = 'font13'
												 ,focusTexture=os.path.join(image_dir,'setting_focus.png'),noFocusTexture =os.path.join(image_dir,'setting_nofocus.png')
												)
		self.addControl(self.Setting_button)

#		self.Search_CMark = xbmcgui.ControlCheckMark(int(15 * self.scaleX),int(180 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"タ",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
#													,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
#													)
#		self.addControl(self.Search_CMark)
#		self.Search_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])

		self.JIMAKU_CMark = xbmcgui.ControlCheckMark(int(13 * self.scaleX),int(185 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"字",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
													,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
													)
		self.addControl(self.JIMAKU_CMark)
		self.JIMAKU_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])

		#
		self.nico_icon = xbmcgui.ControlImage(int(20 * self.scaleX),int(205 * self.scaleY),int(16 * self.scaleX),int(16 * self.scaleY), os.path.join(os.path.join(root_dir,"Image"),'nico.png'))
		self.addControl(self.nico_icon)

		self.Ranking_Type = xbmcgui.ControlCheckMark(int(13 * self.scaleX),int(225 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"ラ",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
													,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
													)
		self.addControl(self.Ranking_Type)
		self.Ranking_Type.setAnimations([('focus', "effect=slide end=-5,0 time=100")])


		self.XMLUpdate_CMark = xbmcgui.ControlCheckMark(int(13 * self.scaleX),int(250 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"更",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
													,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
													)
		self.addControl(self.XMLUpdate_CMark)
		self.XMLUpdate_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])


		self.EconomyMode_CMark = xbmcgui.ControlCheckMark(int(13 * self.scaleX),int(275 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"エ",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
														,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
														)
		self.addControl(self.EconomyMode_CMark)
		self.EconomyMode_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])


		self.Streaming_CMark = xbmcgui.ControlCheckMark(int(13 * self.scaleX),int(300 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"ス",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
														,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
														)
		self.addControl(self.Streaming_CMark)
		self.Streaming_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])

		#
		self.live_icon = xbmcgui.ControlImage(int(20 * self.scaleX),int(320* self.scaleY),int(16 * self.scaleX),int(16 * self.scaleY), os.path.join(os.path.join(root_dir,"Image"),'live.png'))
		self.addControl(self.live_icon)

		self.TimeShift_CMark = xbmcgui.ControlCheckMark(int(13 * self.scaleX),int(340 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"過",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
														,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
														)
		self.addControl(self.TimeShift_CMark)
		self.TimeShift_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])

		#
		self.alert_icon = xbmcgui.ControlImage(int(20 * self.scaleX),int(360*self.scaleY),int(16 * self.scaleX),int(16 * self.scaleY), os.path.join(os.path.join(root_dir,"Image"),'antenna.png'))
		self.addControl(self.alert_icon)

		self.Alert_CMark = xbmcgui.ControlCheckMark(int(13 * self.scaleX),int(380 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"ア",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
														,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
														)
		self.addControl(self.Alert_CMark)
		self.Alert_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])


		self.font_CMark = xbmcgui.ControlCheckMark(int(13 * self.scaleX),int(410 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"F",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
														,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
														)
		self.addControl(self.font_CMark)
		self.font_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])


#		self.sleep_CMark = xbmcgui.ControlCheckMark(int(15 * self.scaleX),int(380 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"S",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
#														,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
#														)
#		self.addControl(self.sleep_CMark)
#		self.sleep_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])

#		self.END_CMark = xbmcgui.ControlCheckMark(int(15 * self.scaleX),int(410 * self.scaleY),int(40 * self.scaleX),int(29 * self.scaleY),"E",font = 'nico_font_18',checkWidth=int(16 * self.scaleX),checkHeight=int(16 * self.scaleX)
#														,focusTexture=os.path.join(image_dir,'cmark-focus.png'),noFocusTexture =os.path.join(image_dir,'cmark-nofocus.png')
#														)
#		self.addControl(self.END_CMark)
#		self.END_CMark.setAnimations([('focus', "effect=slide end=-5,0 time=100")])

		self.END_CMark = xbmcgui.ControlButton(int(12 * self.scaleX),int(440 * self.scaleY),int(25 * self.scaleX),int(25 * self.scaleY),"",font = 'font12'
												,focusTexture=os.path.join(image_dir,'power_focus.png'),noFocusTexture =os.path.join(image_dir,'power_nofocus.png')
												)
		self.addControl(self.END_CMark)

		self.Textbox_tbn = xbmcgui.ControlTextBox(int(57 * self.scaleX),int(452 * self.scaleY),int(250 * self.scaleX),int(20 * self.scaleY),font = 'font12', textColor = "0xFFEEEEEE")
		self.Textbox_tbn.setText("")
		self.addControl(self.Textbox_tbn)

		self.tv_image = xbmcgui.ControlImage(int(282 * self.scaleX - 169 * self.scaleY),int(-26 * self.scaleY),int(177 * self.scaleY),int(192 * self.scaleY),os.path.join(image_dir,'tv.png'))
		self.addControl(self.tv_image)

		self.nico_tbn_image = xbmcgui.ControlImage(int(282 * self.scaleX - 148 * self.scaleY),int(33 * self.scaleY),int(137 * self.scaleY),int(94 * self.scaleY),"")
		self.addControl(self.nico_tbn_image)
		self.nico_tbn_image.setVisible(True)

#		self.nico_rc2_logo = xbmcgui.ControlImage(int(108 * self.scaleY),int(420 * self.scaleY),int(200 * self.scaleY),int(48 * self.scaleY),nico_rc2_logo)
#		self.addControl(self.nico_rc2_logo)
#		self.nico_ani_back = xbmcgui.ControlImage(int(60 * self.scaleY),int(420 * self.scaleY),int(48 * self.scaleY),int(48 * self.scaleY),nico_ani_B)
#		self.addControl(self.nico_ani_back)
#		self.nico_ani_icon = xbmcgui.ControlImage(int(60 * self.scaleY),int(420 * self.scaleY),int(48 * self.scaleY),int(48 * self.scaleY),noimage_tbn)
#		self.addControl(self.nico_ani_icon)

		self.alertButton = None

# =↑ここまで====↑アイテム配置に関する設定=====================================


	def getVideoExistsFolderPath(self,video_id):
		'''動画が存在するフォルダのパスを返します'''

		if self.Cache_directory:
			try:
				files = os.listdir(self.Cache_directory)
				for f in files:
					if os.path.exists(os.path.join(os.path.join(self.Cache_directory,f),video_id + ".xml")):
						return True, f
			except Exception, e:
				print "getVideoExistsFolderPath Error: %s" % e
			return False, str(datetime.datetime.today().strftime("%Y.%m"))
		else:
			return False, str(datetime.datetime.today().strftime("%Y.%m"))

	def initWatchMemory(self):
		'''空きメモリの表示'''

		def watchMemoryThread(self,s):
			try:
				while self.running:
					if self.tbn_down_thread_count == 0:
						self.Textbox_tbn.setText(str(xbmc.getFreeMem()) + "MB")
						time.sleep(1.0)
			except Exception, e:
				print "initWatchMemory Error: %s" % e

		wm_thread = threading.Thread(target=watchMemoryThread,args=(self,''))
		wm_thread.setDaemon(True)
		wm_thread.start()


	def loginCheck(self):
		self.nicoVideo.loadCookie()
		if not self.nicoVideo.isLogin():
			if not self.nicoVideo.loginNicoVideo():
				xbmcgui.Dialog().ok("エラー","ニコニコ動画へのログインに失敗しました。")
				return False
		return True


	def startVideoPlayer(self,video_id,title, streaming = False, isTemp = False, isAlert = False, isPlay = True, videoFile = None):
		self.isStartVideoPlayer = True
		self.isStartVideoPlayerSuccess = False
		try:
			self.Mes_BOX(title)
	#		self.Mes_BOX("%s\nプレーヤーの開始中..." % title)
			xbmcgui.unlock()
			msg = self.getMessage()
			if video_id.startswith("lv") or video_id.startswith("ch") or  video_id.startswith("co"):

				self.Mes_BOX("%s\nプレーヤーの準備中..." % msg)
				self.nicoVideo.video_id = video_id
				if(not self.loginCheck()):
					xbmcgui.Dialog().ok("エラー","ニコニコ動画へのログインに失敗しました")
					return False
				retryCount = 3
				count = self.liveErrorFullRetryCount

				while True:
					while 0 < retryCount:
						body = self.nicoVideo.apiGetPlayerStatus()
						if self.__dbg__: print body
						if re.compile('<getplayerstatus ').search(body):
							break
						time.sleep(3.0)
						retryCount -= 1
						body = None
					if body == None:
						self.Mes_BOX("%s\nプレーヤーの準備に失敗しました" % msg)
						return False
					result = self.nicoVideo.setGetplayerstatus(getplayerstatus=body)
		#			if video_id == self.nicoVideo.live_id:
		#				self.Mes_BOX("%s\n%s Streaming Connected beginning !!" % (self.getMessage(),video_id))
		#			else:
		#				self.Mes_BOX("%s\n%s(%s) Streaming Connected beginning !!" % (self.getMessage(),video_id,self.nicoVideo.live_id))

					if result and result == 'require_accept_print_timeshift_ticket':
						if not xbmcgui.Dialog().yesno("確認","タイムシフトの視聴権を使用する\r\n必要があります。使用しますか？"):
							return False
						self.nicoVideo.setWatchingReservation('confirm_watch_my',self.nicoVideo.live_id)
						body = self.nicoVideo.apiGetPlayerStatus()
						if self.__dbg__:
							print body
						result = self.nicoVideo.setGetplayerstatus(getplayerstatus=body)

					if 0 < count and result == "full":
						count = count - 1
						self.Mes_BOX("'%s\n満員(放送中) リトライ回数 = %d" % (msg, self.liveErrorFullRetryCount - count))
						time.sleep(5)
					else:
						break

				if result:
					if NicoVideo.GETPLAYERSTATUS_ERROR_MESSAGE.get(result):
						xbmcgui.Dialog().ok("エラー",NicoVideo.GETPLAYERSTATUS_ERROR_MESSAGE.get(result))
					else:
						xbmcgui.Dialog().ok("エラー","エラーコード:%s が発生しました" % result)
					self.Mes_BOX("%s\nプレーヤーの準備に失敗しました" % msg)
					return False

				playurl = self.nicoVideo.getLiveVideoUrl()
				isCruise = self.nicoVideo.title == 'ニコ生クルーズ'
				isSekatyaku = self.nicoVideo.title[0:9] == '【世界の新着動画】'

				if not isCruise and not isSekatyaku and playurl == None:
					xbmcgui.Dialog().ok("失敗","情報を解析できませんでした")
					return None
				self.Mes_BOX("%s\nプレーヤーの準備が完了しました" % msg)

				if isCruise or isSekatyaku:
					if isSekatyaku:
						if re.compile("/perm この動画で放送終了になります。").search(body):
							xbmcgui.Dialog().ok("エラー","この放送は終了しています")
					if playurl != None:
						xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(playurl)
					xbmc.executebuiltin("XBMC.RunScript(%s,%s,%s,%s,%s,%s,%s,%s)" % (nico_py, self.nicoVideo.ms_addr, self.nicoVideo.ms_port, self.nicoVideo.ms_thread, self.nicoVideo.live_id, self.nicoVideo.rtmp_url, self.nicoVideo.rtmp_ticket, self.nicoVideo.title))
				elif 0 <= re.compile(' live=true').search(playurl):
					xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(playurl)
					if xbmc.Player().isPlaying():
						if isAlert:
							self.setFocus(self.ranking_button)
							self.alertLiveID = None
							self.alertLiveTitle = None
						if self.comment_view:
							xbmc.executebuiltin("XBMC.RunScript(%s,%s,%s,%s,%s)" % (nico_py, self.nicoVideo.ms_addr, self.nicoVideo.ms_port, self.nicoVideo.ms_thread, self.nicoVideo.live_id))
				else:
					fo = open(os.path.join(stream_dir,'getplayerstatus.xml'), 'wb')
					fo.write(body)
					fo.close()

					if self.comment_view:
						msg = self.getMessage()
						self.Mes_BOX("%s\nコメントの準備中..." % msg)
						self.nicoVideo.downloadMessageAll(os.path.join(stream_dir,'Comment.xml'))
						self.Mes_BOX("%s\nコメントの準備が完了しました" % msg)

					xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(playurl)
					if self.comment_view and xbmc.Player().isPlaying():
	#					xbmc.Player().pause()
	#					xbmc.executebuiltin("XBMC.RunScript(%s,%s)" % (nico_py,'pause'))
						xbmc.executebuiltin("XBMC.RunScript(%s)" % (nico_py))
			else:
				downloadTemp = isTemp
				if not streaming and not self.Cache_directory:
					downloadTemp = True

				if video_id[0:2] == "nm":
					xbmcgui.Dialog().ok("","Flashには対応していません... (T^T)")
					return False

				m = self.file_num_re.match(video_id)
				originVideoNum = int(m.group(1))

				tbn_path = os.path.join(os.path.join(tbn_dir,str(originVideoNum%1000)),video_id + '.jpg')

				self.nicoVideo.video_id = video_id
				if video_id[0:2] == "so":
					self.nicoVideo.video_id = self.nicoVideo.getWatchVideoID()
				cacheVideo = os.path.join(cache_dir,self.nicoVideo.video_id+'.mp4')
#				print "cacheVideo= %s" %(cacheVideo)
				playPath = None
				if videoFile != None:
					playPath = videoFile
				elif os.path.exists(cacheVideo):
	#				self.Mes_BOX("%s\n%s Cache File Connected beginning !!" % (self.getMessage(),video_id))
					playPath = cacheVideo
				else:
					exist,folderName = self.getVideoExistsFolderPath(self.nicoVideo.video_id)
					self.nicoVideo.economyMode = self.economyMode;
					updateList3 = False

					if not exist and (streaming or downloadTemp):
						if isTemp:
							cacheList = os.listdir(cache_dir)
							if self.max_temporary_file_num <= len(cacheList)/4.0:
								if xbmcgui.Dialog().yesno("確認","一時ファイルが上限に達しています。\n古いファイルを削除してもよろしいですか？"):
									self.removeCache()
								else:
									if not xbmcgui.Dialog().yesno("確認","このままダウンロード再生を続けてもよろしいですか？"):
										self.Mes_BOX("%s\nダウンロード再生を中止しました" % msg)
										return False
						#ストリーミング再生、一時ファイ再生の場合
						if(not self.loginCheck()):
							return False
						commentDownload = True
						historyCommentFilePath = os.path.join(os.path.join(comment_dir,str(originVideoNum%1000)),video_id + '.xml')
						isCacheXML = os.path.exists(historyCommentFilePath)
						updateList3 = not isCacheXML
						# コメント非更新の場合は過去のコメントをコピー
						if not self.comment_update:
							if isCacheXML:
								if isTemp:
									shutil.copy(historyCommentFilePath,os.path.join(cache_dir,self.nicoVideo.video_id+'.xml'))
								else:
									shutil.copy(historyCommentFilePath,os.path.join(stream_dir,'Comment.xml'))
								print "Comment File Copy"
								commentDownload = False

						if commentDownload:
							self.Mes_BOX("%s\nコメントと動画情報の準備中..." % msg)
							if isTemp:
								if self.nicoVideo.downloadXml(cache_dir,self.nicoVideo.video_id+'.xml',self.nicoVideo.video_id+'[ThumbInfo].xml'):
									if self.save_comment:
										shutil.copy(os.path.join(cache_dir,self.nicoVideo.video_id+'.xml'),historyCommentFilePath)
								else:
									self.Mes_BOX("%s\nコメントと動画情報の取得に失敗しました" % msg)
									return False
							else:
								if self.nicoVideo.downloadXml(stream_dir,'Comment.xml','ThumbInfo.xml'):
									if self.save_comment:
										shutil.copy(os.path.join(stream_dir,'Comment.xml'),historyCommentFilePath)
								else:
									self.Mes_BOX("%s\nコメントと動画情報の取得に失敗しました" % msg)
									return False
							self.Mes_BOX("%s\nコメントと動画情報の準備が完了しました" % msg)
						else:
							msg = self.getMessage()
							self.Mes_BOX("%s\n動画情報の準備中..." % msg)
							if isTemp:
								self.nicoVideo.downloadThumbInfo(os.path.join(cache_dir, self.nicoVideo.video_id+'[ThumbInfo].xml'))
							else:
								self.nicoVideo.downloadThumbInfo(os.path.join(stream_dir,'ThumbInfo.xml'))
							if not self.nicoVideo.retrieveVideoID():
								self.Mes_BOX("%s\n動画情報の取得に失敗しました" % msg)
								return False
							if not self.nicoVideo.getFLVPath():
								self.Mes_BOX("%s\n動画情報の取得に失敗しました" % msg)
								return False
							self.Mes_BOX("%s\n動画情報の準備が完了しました" % msg)

						if isTemp:
							save_tbn = os.path.join(cache_dir,self.nicoVideo.video_id+'.tbn')
							if not os.path.exists(save_tbn):
								if os.path.exists(tbn_path):
									shutil.copy(tbn_path,save_tbn)

						if downloadTemp:
							msg = self.getMessage()
							self.Mes_BOX("%s\n動画ファイルのダウンロード中..." % msg)
							playPath = os.path.join(cache_dir,self.nicoVideo.video_id+'.mp4')
							progress = xbmcgui.DialogProgress()
							try:
								if not self.nicoVideo.download(playPath, progress):
									self.Mes_BOX("%s\n動画ファイルのダウンロードに失敗しました" % msg)
									return False
								if progress.iscanceled():
									self.Mes_BOX("%s\n動画ファイルのダウンロードを中止しました" % msg)
									return False
							finally :
								progress.close()
							self.Mes_BOX("%s\n動画ファイルのダウンロードが完了しました" % msg)
						else:
							msg = self.getMessage()
							playPath = self.nicoVideo.video_url + "|Cookie=%s" % (urllib.quote_plus(';'.join([self.nicoVideo.user_session, self.nicoVideo.nicohistory])))

						if self.save_history and not isTemp:
							try:
								self.writeHistory(self.nicoVideo.video_id,self.nicoVideo.View_JPtitle)
							except Exception, e:
								xbmcgui.Dialog().ok("エラー","再生履歴の書き込みに失敗しました")

					else:
						savedirectory = None
						downloadEconomyMode = self.economyMode
						if exist:
							if self.economyMode:
								if os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].flv')):
									playPath =os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].flv')
								elif os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].mp4')):
									playPath =os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].mp4')
								elif os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].swf')):
									playPath =os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].swf')

								if playPath == None:
									if os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.flv')):
										savedirectory = os.path.join(self.Cache_directory,folderName)
									elif os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.mp4')):
										savedirectory = os.path.join(self.Cache_directory,folderName)
									elif os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.swf')):
										savedirectory = os.path.join(self.Cache_directory,folderName)
							else:
								if os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.flv')):
									playPath =os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.flv')
								elif os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.mp4')):
									playPath =os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.mp4')
								elif os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.swf')):
									playPath = os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '.swf')

								if playPath == None:
									if os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].flv')):
										savedirectory = os.path.join(self.Cache_directory,folderName)
									elif os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].mp4')):
										savedirectory = os.path.join(self.Cache_directory,folderName)
									elif os.path.exists(os.path.join(os.path.join(self.Cache_directory,folderName),self.nicoVideo.video_id + '[low].swf')):
										savedirectory = os.path.join(self.Cache_directory,folderName)
					##				self.Mes_BOX( playPath + "\n(swf)の再生には対応していません。" )
					##				return False

						if savedirectory == None:
							savedirectory = os.path.join(self.Cache_directory,folderName)
							if not os.path.exists( savedirectory ):
								os.makedirs( savedirectory )

						if playPath != None:
							fsize=os.path.getsize(playPath)
							if fsize == 0:
								os.remove(playPath)
								playPath = None
								print "remove 0 size file"
						if playPath == None:
							updateList3 = True
							# 保存ファイルが存在しない場合
							msg = self.getMessage()
							self.Mes_BOX("%s\n動画ファイルのダウンロード中..." % msg)
							if(not self.loginCheck()):
								return False

							if not self.nicoVideo.retrieveVideoID():
								self.Mes_BOX("%s\n動画ファイルのダウンロードに失敗しました" % msg)
								return False
							if not self.nicoVideo.getFLVPath():
								self.Mes_BOX("%s\n動画ファイルのダウンロードに失敗しました" % msg)
								return False


							if not self.nicoVideo.economyMode and self.nicoVideo.low_check:
								if self.economyConfirm:
									if not xbmcgui.Dialog().yesno("確認","エコノミーモード（低画質）でダウンロードを開始してもよろしいですか？"):
										return False

							xml_save_file_path = os.path.join(savedirectory,regulate_filename(self.nicoVideo.video_id+'.xml'))
							if self.comment_update or not os.path.exists( xml_save_file_path ):
								self.nicoVideo.download_message(xml_save_file_path)
							else:
								print '%s already exists.' % xml_save_file_path

							if self.save_comment:
								#視聴履歴としてコメントを保存

								historyCommentFilePath = os.path.join(os.path.join(comment_dir,str(originVideoNum%1000)),video_id + '.xml')
								if not os.path.exists(historyCommentFilePath) or self.comment_update:
									shutil.copy(xml_save_file_path,historyCommentFilePath)

							# ThumbInfoの保存
							thumbInfo_file_path = os.path.join(savedirectory,regulate_filename(self.nicoVideo.video_id+'[ThumbInfo].xml'))
							self.nicoVideo.downloadThumbInfo(thumbInfo_file_path)

							if self.nicoVideo.low_check:
								self.nicoVideo.save_file_path = os.path.join(savedirectory, regulate_filename(self.nicoVideo.video_id+'[low].'+self.nicoVideo.video_ext))
							else:
								self.nicoVideo.save_file_path = os.path.join(savedirectory, regulate_filename(self.nicoVideo.video_id+'.'+self.nicoVideo.video_ext))

			#					if not self.nicoVideo.force_overwrite and os.access(self.nicoVideo.save_file_path, os.F_OK):
			#						print 'File %s already exists.' % self.nicoVideo.nicoVideo.save_file_path
							progress = xbmcgui.DialogProgress()
							try:
								if not self.nicoVideo.download(self.nicoVideo.save_file_path, progress):
									self.Mes_BOX("%s\n動画ファイルのダウンロードに失敗しました" % msg)
									return False
								if progress.iscanceled():
									self.Mes_BOX("%s\n動画ファイルのダウンロードを中止しました" % msg)
									return False
							finally :
								progress.close()
							self.Mes_BOX("%s\n動画ファイルのダウンロードが完了しました" % msg)
							playPath = self.nicoVideo.save_file_path
							downloadEconomyMode = self.nicoVideo.low_check
						else:
							#保存ファイルが存在する場合
	#						self.Mes_BOX("%s\n%s Connected beginning !!" % (self.getMessage(),video_id))

							xml_save_file_path =os.path.join(savedirectory, regulate_filename(self.nicoVideo.video_id+'.xml'))
							existComment = os.path.exists(xml_save_file_path)
							if self.comment_update or not existComment:
								msg = self.getMessage()
								self.Mes_BOX("%s\nコメントの準備中..." % msg)
								# 過去のコメントをリネーム
								if existComment:
									rename_xml_path = xml_save_file_path[:-4] + datetime.datetime.today().strftime("[%Y%m%d%H%M].xml");
									os.rename(xml_save_file_path,rename_xml_path)
								if(not self.loginCheck()):
									xbmcgui.Dialog().ok("エラー","ニコニコ動画へのログインに失敗しました")
									return False
								# コメント取得
								if self.nicoVideo.downloadXml(savedirectory):
									historyCommentFilePath = os.path.join(os.path.join(comment_dir,str(originVideoNum%1000)),video_id + '.xml')
									shutil.copy(xml_save_file_path,historyCommentFilePath)
								else:
									self.Mes_BOX("%s\nコメントの取得に失敗しました" % msg)
									return False
								self.Mes_BOX("%s\nコメントの準備が完了しました" % msg)

						if self.save_history:
							self.writeHistory(self.nicoVideo.video_id,self.nicoVideo.View_JPtitle)

						if downloadEconomyMode:
							videoFileName = self.nicoVideo.video_id + '[low]'
						else:
							videoFileName = self.nicoVideo.video_id

						if not os.path.exists(os.path.join(savedirectory,videoFileName + '.tbn')):
							if os.path.exists(tbn_path):
								shutil.copy(tbn_path,os.path.join(savedirectory,videoFileName + '.tbn'))
							else:
								print 'Download tbn_path = http://tn-skr.smilevideo.jp/smile?i=' + video_id[2:]
								tbnUrl = 'http://tn-skr.smilevideo.jp/smile?i=%s' % (str(originVideoNum))
								try:
									urllib.urlretrieve(tbnUrl, os.path.join(savedirectory,self.nicoVideo.video_id + '.tbn'))
								except Exception, e:
									print str(e)
									print '%s, url=%s' % (self.nicoVideo.video_id,tbnUrl)
								urllib.urlcleanup()  # キャッシュの削除

					if self.view_watched and updateList3:
						list3Index = int(self.list3.getSelectedPosition())
			#			self.list3.selectItem(0)
						self.list3.reset()
						for data in self.List3_Data_Tuple_List:
							if  data[1]:
								self.list3.addItem(self.view_watched_prefix[self.isSaveComment(data[1])] + data[0])
							else:
								self.list3.addItem(data[0])
						self.list3.selectItem(list3Index)
						time.sleep(0.1)
				if not isPlay:
					return True

				item = xbmcgui.ListItem(video_id, iconImage=tbn_path, thumbnailImage=tbn_path)
				item.setInfo( type="Video", infoLabels={ "Title": video_id, "Director": 'ニコニコ動画', "Studio": 'ニコニコ動画' } )
				xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(playPath, item)

#				if not xbmc.Player().isPlaying():
#					xbmc.sleep(300)

#				if xbmc.Player().isPlaying():
				if self.comment_view:# and xbmc.Player().isPlaying():
					xbmc.Player().pause()
#					xbmc.sleep(300)
					xbmc.executebuiltin("XBMC.RunScript(%s,%s)" % (nico_py,'pause'))
#				else:
#					xbmcgui.Dialog().ok("エラー","再生に失敗しました")

			self.isStartVideoPlayerSuccess = True
			return True
		finally:
			self.isStartVideoPlayer = False

	def addHistoryStock(self):
		'''作業情報を履歴に追加します'''

		if self.history_stock:
			self.list_data_history_back_list.append(self.history_stock)

		self.history_stock = [self.Work_Group_ID, self.List1_Index, self.List2_Index, self.List3_Index, self.List1_Data_Tuple_List, self.List2_Data_Tuple_List, self.List3_Data_Tuple_List, self.TAG_FLAG]
		if self.MAX_HISTORY < len(self.list_data_history_back_list):
			del self.list_data_history_back_list[0]
		else:
			num_img = os.path.join(os.path.join(image_dir,'num'),str(len(self.list_data_history_back_list))+'.gif')
			self.back_num_image.setImage(num_img)

	def historyBack(self):
		'''表示しているリストをもどします'''

		self.List3_Data_Tuple_List = []
		if 0 < len(self.list_data_history_back_list):
			self.history_stock = self.list_data_history_back_list.pop()
			returns_ahead = self.history_stock

			self.Work_Group_ID = returns_ahead[0]
			self.List1_Index = returns_ahead[1]
			self.List2_Index = returns_ahead[2]
			self.List3_Index = returns_ahead[3]
			self.list1.reset()
			self.list2.reset()
			self.list3.reset()
			self.list1.selectItem(0)
			self.list2.selectItem(0)
			self.list3.selectItem(0)

			self.List1_Data_Tuple_List = returns_ahead[4]
			self.List2_Data_Tuple_List = returns_ahead[5]
			self.List3_Data_Tuple_List = returns_ahead[6]
			for i in range(len(self.List1_Data_Tuple_List)):
				self.list1.addItem(self.List1_Data_Tuple_List[i][0])
			for i in range(len(self.List2_Data_Tuple_List)):
				self.list2.addItem(self.List2_Data_Tuple_List[i][0])

			if self.view_watched:
				for data in self.List3_Data_Tuple_List:
					if self.Work_Group_ID == LIVE_WORK_ID:
						self.list3.addItem(data[0])
					else:
						self.list3.addItem(self.view_watched_prefix[self.isSaveComment(data[1])] + data[0])
			else:
				for data in self.List3_Data_Tuple_List:
					self.list3.addItem(data[0])
			self.TAG_FLAG = returns_ahead[7]

			num_img = os.path.join(os.path.join(image_dir,'num'),str(len(self.list_data_history_back_list))+'.gif')
			self.back_num_image.setImage(num_img)

			self.updateButtonSetting()

#			if self.Work_Group_ID  == LIVE_WORK_ID:
#				self.Update_List.reset()
#				self.Update_List.selectItem(0)
#				for name in LIVE_SORT_NAME_ARRAY:
#					self.Update_List.addItem(name)
#			else:
#				self.Update_List.reset()
#				self.Update_List.selectItem(0)
#				for name in NICO_SORT_NAME_ARRAY:
#					self.Update_List.addItem(name)

			self.Mes_BOX("一つ前の状態にもどりました")
		else:
			xbmcgui.Dialog().ok("","もどる状態がありませんでした")

	def writeHistory(self,video_id,title):
		'''視聴履歴を書き込みます'''

		play_day_dat = time.strftime("%y_%m_%d.txt",time.localtime(time.time()) )
		path = os.path.join(hisDatDir,play_day_dat)
		if self.__dbg__: print "writeHistory path: %s" %(path)
		try:
			if os.path.exists(path):
				file = open(path, 'a')
			else:
				file = open(path, 'w')
			try:
				if self.__dbg__: print "writeHistory: '%s','%s'" %(video_id,title)
				file.write("'%s','%s'\n" %(video_id,title) )
			finally:
				file.close()
		except Exception, e:
			print "write History Error:" + str(e)
#			xbmcgui.Dialog().ok("エラー","視聴履歴の書き込みに失敗しました")

	def setThumbnailImage(self,video_id):
		if video_id:
			m = self.file_num_re.match(video_id)
			if m == None:
				self.nico_tbn_image.setImage(noimage_tbn)
			else:
				if video_id.startswith("lv"):
					self.setLiveImage(video_id)
				elif video_id.startswith("ch"):
					self.setChannelImage(video_id)
				elif video_id.startswith("co"):
					num = int(m.group(1))
#					tbn_path = os.path.join(os.path.join(coicon_dir,str(num%1000)),video_id + '.jpg')
					tbn_path = os.path.join(coicon_dir,video_id + '.jpg')
					if os.path.exists(tbn_path):
						self.nico_tbn_image.setImage(tbn_path)
					else:
						self.nico_tbn_image.setImage(noimage_tbn)
				else:
#					if self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 0:
#						root = self.List2_Data_Tuple_List[self.List2_Index][1]
#						tbn_path = os.path.join(os.path.join(root,video_id + '.tbn'))
#					else:
					num = int(m.group(1))
					tbn_path = os.path.join(os.path.join(tbn_dir,str(num%1000)),video_id + '.jpg')
					if os.path.exists(tbn_path):
						self.nico_tbn_image.setImage(tbn_path)
					else:
						self.nico_tbn_image.setImage(noimage_tbn)
		else:
			if self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 5:
				self.setTwitterIconImage(self.List2_Data_Tuple_List[self.List2_Index][0])
			else:
				self.nico_tbn_image.setImage(noimage_tbn)

	def setLiveImage(self,id):
		path = os.path.join(lvtbn_dir,id + '.jpg')
		if os.path.exists(path):
			self.nico_tbn_image.setImage(path)
		else:
			self.nico_tbn_image.setImage(noimage_tbn)

	def setChannelImage(self,chanel_id):
		path = os.path.join(chicon_dir,chanel_id + '.jpg')
		if os.path.exists(path):
			self.nico_tbn_image.setImage(path)
		else:
			self.nico_tbn_image.setImage(noimage_tbn)

	def setUserImage(self,user_id):
		num = int(user_id)
		path = os.path.join(os.path.join(usericon_dir,str(num%1000)),user_id + '.jpg')
		if os.path.exists(path):
			self.nico_tbn_image.setImage(path)
		else:
			self.nico_tbn_image.setImage(noimage_tbn)

	def setTwitterIconImage(self,id):
		path = os.path.join(twittericon_dir,id + '.png')
		if os.path.exists(path):
			self.nico_tbn_image.setImage(path)
		else:
			self.nico_tbn_image.setImage(noimage_tbn)

	def endScript(self):
		if xbmcgui.Dialog().yesno("確認","スクリプトを終了してもよろしいですか？"):
			self.Mes_BOX('スクリプトを終了しています')
			self.running = False
			time.sleep(1.0)
			self.close()

	def endXBMC(self):
		if xbmcgui.Dialog().yesno("確認","XBMCを終了してよろしいですか？"):
			self.Mes_BOX('XBMCを終了しています。\nお疲れ様でした。')
			self.running = False
			time.sleep(10.0)
			self.close()
			xbmc.shutdown()

	def onAction(self, action = None):
		'''PAD等のキーによる処理'''

		if self.isOnControl:
			self.isOnControl = False
			return None

#		if action.getButtonCode() != 0:
#			print "ButtonCode " + action.getButtonCode()
#			print "action " + action
		control = None
		try:
			control = self.getFocus()
			if action == ACTION_PREVIOUS_MENU or action == ACTION_PARENT_DIR:
				if self.alertLiveID != None and control != self.alertButton:
					self.setFocus(self.alertButton)
				elif control == self.alertButton or control == self.ranking_button or control == self.MyList_button or control == self.WatchList_button or control == self.Channel_button or control == self.Niconama_button or control == self.Other_button:
					self.endScript()
				else:
					self.setFocus(self.ranking_button)
					self.nico_tbn_image.setImage(dummy_tbn)
				return None
			if control == self.list1:
				if self.list1.size() == 0:
					return None
				self.choose_cont = 1
			elif control == self.list2:
				if self.list2.size() == 0:
					return None
				self.choose_cont = 2
			elif control == self.list3:
				if self.list3.size() == 0:
					return None
				self.choose_cont = 3
			else:
				self.choose_cont = 0
		except Exception, e:
			print e
			return None

		if control == self.ranking_button or control == self.MyList_button or control == self.WatchList_button or control == self.Channel_button or control == self.Other_button:
			self.nico_tbn_image.setImage(dummy_tbn)

		# リスト１
		if self.choose_cont == 1:
			if self.Work_Group_ID == WATCHLIST_WORK_ID:
				listIndex = int(self.list1.getSelectedPosition())
				if self.List1_Data_Tuple_List[listIndex][1] == "":
					self.nico_tbn_image.setImage(dummy_tbn)
				else:
					s_time = time.time()
					time.sleep(0.1)
					if s_time + 0.1 <= time.time():
						if listIndex == int(self.list1.getSelectedPosition()):
							data = self.List1_Data_Tuple_List[listIndex][1]
							userid = data[0]
							if data[3] == None:
								discript = ""
							else:
								discript = re.compile(r'<.*?>').sub('', data[3])
							self.Mes_BOX(discript)
							self.setUserImage(userid)
			else:
				self.nico_tbn_image.setImage(dummy_tbn)

		# リスト２
		if self.choose_cont == 2:
			if self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 3:
				listIndex = int(self.list2.getSelectedPosition())
				s_time = time.time()
				time.sleep(0.1)
				if s_time + 0.1 <= time.time():
					if listIndex == int(self.list2.getSelectedPosition()):
						self.Mes_BOX(self.List2_Data_Tuple_List[listIndex][0])

			elif self.Work_Group_ID == CHANNEL_WORK_ID:
				listIndex = int(self.list2.getSelectedPosition())
				s_time = time.time()
				time.sleep(0.1)
				if s_time + 0.1 <= time.time():
					if listIndex == int(self.list2.getSelectedPosition()):
						data = self.List2_Data_Tuple_List[listIndex][1]
						cid = data[0]
						if len(data) == 4:
							title = "%s\n%s (%s)\nお気に入り登録数 %s" % (data[2],data[1],cid,data[3])
						else:
							title = "%s (%s)" % (data[1],cid)
						self.Mes_BOX(title)
						self.setChannelImage(cid)
			elif self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 5:
				listIndex = int(self.list2.getSelectedPosition())
				s_time = time.time()
				time.sleep(0.1)
				if s_time + 0.1 <= time.time():
					if listIndex == int(self.list2.getSelectedPosition()):
						self.setTwitterIconImage(self.List2_Data_Tuple_List[listIndex][0])

			else:
				self.nico_tbn_image.setImage(dummy_tbn)

		# リスト３
		if self.choose_cont == 3 :
			list3Index = int(self.list3.getSelectedPosition())
			if list3Index < len(self.List3_Data_Tuple_List) :
				s_time = time.time()
				time.sleep(0.1)
				if time.time() >= s_time + 0.1:
					if list3Index == int(self.list3.getSelectedPosition()):
						if self.List3_Data_Tuple_List[list3Index][1] or self.Work_Group_ID == OTHER_WORK_ID:
							self.Mes_BOX(self.List3_Data_Tuple_List[list3Index][0])
							if self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 0:
								self.nico_tbn_image.setImage(self.List3_Data_Tuple_List[list3Index][3])
#								self.setThumbnailImage(self.List3_Data_Tuple_List[list3Index][1])
							else:
								if self.List3_Data_Tuple_List[list3Index][1].startswith('lv'):
									self.setThumbnailImage(self.List3_Data_Tuple_List[list3Index][2])
								else:
									self.setThumbnailImage(self.List3_Data_Tuple_List[list3Index][1])
						else:
							self.nico_tbn_image.setImage(noimage_tbn)

		if action == ACTION_PARENT_DIR or ACTION_PARENT_DIR_Remote == action: # ･･････Bボタン押下時の動作
			self.historyBack()

		if action == ACTION_SHOW_INFO: #Yボタン押下時の動作 詳細表示
			if self.Work_Group_ID == LIVE_WORK_ID:
				pass
			else:
				if self.choose_cont == 3:
					index3 = self.list3.getSelectedPosition()
					video_id = self.List3_Data_Tuple_List[index3][1]
					if video_id:
						self.show_Detail(video_id)

		if action == ACTION_SHOW_GUI: # ･･････Xボタン押下時の動作
			if self.choose_cont == 3:
				self.pushX_nico_List3()
			elif self.choose_cont == 2:
				self.pushX_nico_List2()
			elif self.choose_cont == 1:
				self.pushX_nico_List1()

#		if control == self.Search_CMark:
#			self.Mes_BOX('検索方法をの変更（タグ,キーワード,マイリスト）')
		if control == self.Setting_button:
			self.Mes_BOX('設定情報を変更します')
		elif control == self.JIMAKU_CMark:
			self.Mes_BOX('コメント自動表示を設定します')
		elif control == self.XMLUpdate_CMark:
			self.Mes_BOX('コメント更新を設定します')
		elif control == self.Ranking_Type:
			self.Mes_BOX('ランキング項目（総合,再生,コメント,マイリスト）を設定します')
		elif control == self.EconomyMode_CMark:
			self.Mes_BOX('エコノミーモード（低画質）を設定します')
		elif control == self.Streaming_CMark:
			self.Mes_BOX('ストリーミング再生を設定します')
		elif control == self.TimeShift_CMark:
			self.Mes_BOX('検索対象を現在、または過去に設定します')
		elif control == self.Alert_CMark:
			self.Mes_BOX('ニコ生の開始通知を設定します')
		elif control == self.font_CMark:
			self.Mes_BOX('コメント表示用のフォント更新、復元をおこないます')
#		elif control == self.END_CMark:
#			self.Mes_BOX('XBMCの終了')
		elif control == self.test1:
			self.Mes_BOX("チャンネル、コミュニティの画像ファイルを削除します")
		elif control == self.test2:
			self.Mes_BOX("ガベージコレクションを実行します (Free Memory = " + str(xbmc.getFreeMem()) + "MB)")

	def updateButtonSetting(self):
		#ニコ生ボタン処理
		if self.Work_Group_ID == LIVE_WORK_ID:
			self.Update_List.reset()
			self.Update_List.selectItem(0)
			for name in LIVE_SORT_NAME_ARRAY:
				self.Update_List.addItem(name)
		else:
			self.Update_List.reset()
			self.Update_List.selectItem(0)
			for name in NICO_SORT_NAME_ARRAY:
				self.Update_List.addItem(name)

	def onControl(self, control):
		'''決定キーを押した時の処理'''

		try:
			try:
				self.isOnControl = True

#				# 終了
				if control == self.END_CMark:
					self.Mes_BOX('スクリプトを終了しています')
					self.running = False
					time.sleep(1.0)
					self.close()

#					self.endScript()
#					self.endXBMC()

#						# The url in which to use
#						Base_URL = "http://:@192.168.1.17:8080/cgi-bin/misc/misc.cgi?count=1233044386&SHUTDOWN="
#						# Open a 'Socket' to the URL
#						WebSock = urllib.urlopen(Base_URL)
#						# Read contents of URL
#						WebHTML = WebSock.read()
#						# Close the connection to the URL
#						WebSock.close()

				if control == self.ranking_button or control == self.MyList_button or control == self.WatchList_button or control == self.Channel_button or control == self.Other_button or control == self.list1 :
					if self.history_stock:
						self.list_data_history_back_list.append(self.history_stock)
						self.history_stock = None
						if self.MAX_HISTORY < len(self.list_data_history_back_list):
							del self.list_data_history_back_list[0]
						else:
							num_img = os.path.join(os.path.join(image_dir,'num'),str(len(self.list_data_history_back_list))+'.gif')
							self.back_num_image.setImage(num_img)

				#ランキングボタン処理
				if control == self.ranking_button:
					self.loginCheck()
					self.on_Ranking()
					self.updateButtonSetting()

				#マイリストボタン処理
				elif control == self.MyList_button:
					self.loginCheck()
					self.on_MyList()
					self.updateButtonSetting()

				#お気に入りユーザーボタン処理
				elif control == self.WatchList_button:
					self.loginCheck()
					self.on_WatchList()
					self.updateButtonSetting()

				#チャンネルボタン処理
				elif control == self.Channel_button:
					self.loginCheck()
					self.on_Channel()
					self.updateButtonSetting()

				#ニコ生ボタン処理
				elif control == self.Niconama_button:
					self.loginCheck()
					self.on_Live()
					self.updateButtonSetting()

				#その他ボタン処理
				elif control == self.Other_button:
					self.on_Other()
					self.updateButtonSetting()

				#更新ボタン処理
				elif control == self.nico_Update_button:
					self.on_Update()

				#履歴ボタン処理
				elif control == self.back_button:
					self.historyBack()

				elif control == self.Setting_button:
					__settings__.openSettings()

					self.MailAddress = __settings__.getSetting("mailaddress")
					self.PassWord =__settings__.getSetting("password")
					self.ranking_type = int(__settings__.getSetting("ranking_type"))
					self.ranking_type_select = __settings__.getSetting("ranking_type_select") == "true"
					self.live_sort_type = int(__settings__.getSetting("live_sort_type"))
					self.live_sort_type_select = __settings__.getSetting("live_sort_type_select") == "true"
					self.isStreaming = __settings__.getSetting("streaming") == "true"
					self.comment_view = __settings__.getSetting("comment_view") == "true"
					self.Cache_directory = __settings__.getSetting("download_path")
					self.economyMode = __settings__.getSetting("economy")  == "true"
					self.comment_update = __settings__.getSetting("comment_update")  == "true"
					commentArray = [0,250,500,1000]
					self.MAX_COMMENT_NUM = commentArray[int(__settings__.getSetting("comment_num"))]
					self.serch_TorK = self.searchTorkArray[int(__settings__.getSetting("search_type"))]
					self.search_keyword = __settings__.getSetting("search_keyword").split(',')
					self.economyConfirm = __settings__.getSetting("economy_confirm") == "true"
					self.save_comment = __settings__.getSetting("save_comment") == "true"
					self.save_history = __settings__.getSetting("save_history") == "true"
					self.view_watched = __settings__.getSetting("watch_video_prefix") == "true"
					self.detail_mylist_comment = __settings__.getSetting("detail_mylist_comment") == "true"
					self.detail_recommend_video = __settings__.getSetting("detail_recommend_video") == "true"
					self.detail_public_mylist = __settings__.getSetting("detail_public_mylist") == "true"
					self.detail_nicosound = __settings__.getSetting("detail_nicosound") == "true"
					self.detail_twitter_comment = __settings__.getSetting("detail_twitter_comment") == "true"

					self.niconama_alert_official = __settings__.getSetting("niconama_alert_official") == "true"
					self.niconama_alert_view_time = float(__settings__.getSetting("niconama_alert_view_time"))/1000
					self.niconama_alert = __settings__.getSetting( "niconama_alert" ) == "true"
					self.playerstatus_update_interval = float(__settings__.getSetting("playerstatus_update_interval"))/1000

					self.screen_autoset = __settings__.getSetting("screen_autoset") == "true"

					self.liveErrorFullRetryCount = int(float(__settings__.getSetting("live_error_full_retry_count")))

					self.max_temporary_file_num = int(float(__settings__.getSetting("max_temporary_file_num")))

					self.__dbg__ = __settings__.getSetting( "debug" ) == "true"

					self.tweet_user_id_list = []
					for i in range(20):
						user_id = __settings__.getSetting("tweet_user_id_%s" % (i+1))
						if user_id:
							self.tweet_user_id_list.append(user_id)

					if self.nicoVideo.mailAddress != self.MailAddress or self.nicoVideo.passWord != self.PassWord:
						self.nicoVideo.mailAddress = self.MailAddress
						self.nicoVideo.passWord = self.PassWord
						self.nicoVideo.loginNicoVideo()


					self.Ranking_Type.setSelected(True)
					self.JIMAKU_CMark.setSelected(self.comment_view)
					self.XMLUpdate_CMark.setSelected(self.comment_update)
					self.EconomyMode_CMark.setSelected(self.economyMode)
					self.Streaming_CMark.setSelected(self.isStreaming)
					self.TimeShift_CMark.setSelected(self.time_shift)
					self.Alert_CMark.setSelected(self.niconama_alert)

					self.font_CMark.setSelected(os.path.exists(self.backup_font_path))
					if self.niconama_alert:
						if self.nicoliveAntennaGetThread == None:
							self.nicoliveAntennaGetThread = threading.Thread(target=self.nicoliveAntennaGet,args=())
							self.nicoliveAntennaGetThread.setDaemon(True)
							self.nicoliveAntennaGetThread.start()

						if self.nicoliveAntennaAlertThread == None:
							self.nicoliveAntennaAlertThread = threading.Thread(target=self.nicoliveAntennaAlert,args=())
							self.nicoliveAntennaAlertThread.setDaemon(True)
							self.nicoliveAntennaAlertThread.start()

				elif control == self.list1:
					if self.list1.size() == 0:
						return None
					self.List1_Index = self.list1.getSelectedPosition()
					if self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 0 and not self.Cache_directory:
						self.Mes_BOX("保存先が設定されていません")
						return None

					self.TAG_FLAG = False
					self.Mes_BOX("")

					#その他
					if self.Work_Group_ID == OTHER_WORK_ID:
						self.on_Other_list1()
					#生放送
					elif self.Work_Group_ID == LIVE_WORK_ID:
						# ver1.7.1停止
#						if self.List1_Index == 9:
#							if self.live_sort_type_select:
#								select = xbmcgui.Dialog().select("ソートタイプの選択",LIVE_SORT_NAME_ARRAY)
#								if 0<=select:
#									self.live_sort_type = select
#									self.Update_List.selectItem(select)
#								else:
#									return None
						self.on_Live_list1()
					#マイリスト
					elif self.Work_Group_ID == MYLIST_WORK_ID:
						self.on_Mylist_list1()
					#お気に入りユーザー
					elif self.Work_Group_ID == WATCHLIST_WORK_ID:
						self.on_WatchList_list1()
					#ニコニコチャンネル
					elif self.Work_Group_ID == CHANNEL_WORK_ID:
						self.on_Channel_list1()
					else:
						self.on_Ranking_list1()
					#xbmcgui.unlock()

				elif control == self.list2:
					if self.list2.size() == 0: return None
					p = self.list2.getSelectedPosition()
					if self.List2_Data_Tuple_List[p][1] == None: return None

					self.List2_Index = p
					if self.TAG_FLAG:
						self.on_Ranking_list2()
					elif self.Work_Group_ID == OTHER_WORK_ID:
						self.on_Other_list2()
					elif self.Work_Group_ID == LIVE_WORK_ID:
						if self.List1_Index == 2 and self.List2_Index == 0:
							self.inputKeyword()
						elif self.List1_Index == 7:
							self.liveRankingSearch(self.List2_Data_Tuple_List[self.List2_Index][1])
						else:
							self.on_Live_list2(None,None,1,self.time_shift)
					elif self.Work_Group_ID == MYLIST_WORK_ID:
						self.on_Mylist_list2()
					elif self.Work_Group_ID == WATCHLIST_WORK_ID:
						self.on_WatchList_list2()
					elif self.Work_Group_ID == CHANNEL_WORK_ID:
						self.on_Channel_list2()
					else:
						self.on_Ranking_list2()

				elif control == self.list3:
					if self.list3.size() == 0: return None
					p = self.list3.getSelectedPosition()
					if self.List3_Data_Tuple_List[p][1] == None: return None

					self.List3_Index = p
					if self.Work_Group_ID == LIVE_WORK_ID:
						self.on_Live_list3()

					elif self.List1_Index == 0 and self.Work_Group_ID == OTHER_WORK_ID:
						title = self.List3_Data_Tuple_List[self.List3_Index][0]
						video_id = self.List3_Data_Tuple_List[self.List3_Index][1]
						video_file = self.List3_Data_Tuple_List[self.List3_Index][2]
						self.startVideoPlayer(video_id,title,videoFile = video_file)
					else:
						self.on_Ranking_list3()

				if control == self.test1:
					shutil.rmtree(chicon_dir)
					os.makedirs(chicon_dir)
					shutil.rmtree(coicon_dir)
					for i in range(1000):
						os.makedirs(os.path.join(coicon_dir,str(i)))

					xbmcgui.Dialog().ok("","チャンネル、コミュニティの画像ファイルを削除しました")
				elif control == self.test2:
					collect_len = gc.collect()
					#print "gc collect=%d, obj=%d, garbage=%d" %(collect_len,len(gc.get_objects()),len(gc.garbage))
					self.Mes_BOX("gc collect=%d, obj=%d, garbage=%d" %(collect_len,len(gc.get_objects()),len(gc.garbage)))

	#			if control == self.Search_CMark:
	#				if self.serch_TorK == "tag":
	#					self.serch_TorK = "search"
	#					self.Search_CMark.setLabel("キ")
	#					self.Mes_BOX('検索方法を「キーワード検索」に変更しました')
	#				elif self.serch_TorK == "search":
	#					self.serch_TorK = "mylist_search"
	#					self.Search_CMark.setLabel("マ")
	#					self.Mes_BOX('検索方法を「マイリスト検索」に変更しました')
	#				else:
	#					self.serch_TorK = "tag"
	#					self.Search_CMark.setLabel("タ")
	#					self.Mes_BOX('検索方法を「タグ検索」に変更しました')
	#				self.Search_CMark.setSelected(self.serch_TorK == self.searchTorkArray[int(__settings__.getSetting("search_type"))])
	#
	#				self.Ranking_Type.setSelected(self.ranking_type == int(__settings__.getSetting("ranking_type")))

				elif control == self.JIMAKU_CMark:
					if self.JIMAKU_CMark.getSelected():
						self.comment_view = True
						self.Mes_BOX('コメントの自動表示を設定しました')
					else:
						self.comment_view = False
						self.Mes_BOX('コメントの自動表示を解除しました')

				elif control == self.XMLUpdate_CMark:
					if self.XMLUpdate_CMark.getSelected():
						self.comment_update = True
						self.Mes_BOX('コメントの自動更新を設定しました')
					else:
						self.comment_update = False
						self.Mes_BOX('コメントの自動更新を解除しました')

				elif control == self.Ranking_Type:
					#ランキングタイプの変更
					self.Ranking_Type_Change()
					self.Ranking_Type.setSelected(self.ranking_type == int(__settings__.getSetting("ranking_type")))

				elif control == self.EconomyMode_CMark:
					if self.EconomyMode_CMark.getSelected():
						self.Mes_BOX('エコノミーモードに設定しました')
						self.economyMode = True
					else:
						self.Mes_BOX('エコノミーモードを解除しました')
						self.economyMode = False

				elif control == self.Streaming_CMark:
					if self.EconomyMode_CMark.getSelected():
						self.Mes_BOX('ストリーミング再生に設定しました')
						self.isStreaming = True
					else:
						self.Mes_BOX('ストリーミング再生を解除しました')
						self.isStreaming = False

				elif control == self.TimeShift_CMark:
					if self.TimeShift_CMark.getSelected():
						self.Mes_BOX('検索対象を過去の放送に設定しました')
						self.TimeShift_CMark.setLabel("過")
						self.time_shift = True
					else:
						self.Mes_BOX('検索対象を現在の放送に設定しました')
						self.TimeShift_CMark.setLabel("現")
						self.time_shift = False

				elif control == self.Alert_CMark:
					if self.Alert_CMark.getSelected():
						self.Mes_BOX('ニコ生の開始通知を設定しました')
						self.niconama_alert = True
						if self.nicoliveAntennaGetThread == None:
							self.nicoliveAntennaGetThread = threading.Thread(target=self.nicoliveAntennaGet,args=())
							self.nicoliveAntennaGetThread.setDaemon(True)
							self.nicoliveAntennaGetThread.start()

						if self.nicoliveAntennaAlertThread == None:
							self.nicoliveAntennaAlertThread = threading.Thread(target=self.nicoliveAntennaAlert,args=())
							self.nicoliveAntennaAlertThread.setDaemon(True)
							self.nicoliveAntennaAlertThread.start()
					else:
						self.Mes_BOX('ニコ生の開始通知を解除しました')
						self.niconama_alert = False

				elif control == self.font_CMark:
					self.fontChange()

		#		if control == self.Restart_CMark:
		#			#XBOXの再起動
		#			if self.Restart_CMark.getSelected():
		#				if xbmcgui.Dialog().yesno("確認","XBOXを再起動してもよろしいですか？"):
		#					self.Mes_BOX('3秒後にXBOXを再起動いたします')
		#					time.sleep(3)
		#					xbmc.restart()
		#				else:
		#					self.Restart_CMark.setSelected(False)

				elif control == self.alertButton:
					if self.alertLiveID != None:
						live_id = self.alertLiveID
						title = self.alertLiveTitle
						self.startVideoPlayer(live_id,title,streaming=self.isStreaming,isAlert=True)

			except Exception, e:
				print e
				xbmcgui.Dialog().ok("Error",str(e))
		finally:
			xbmcgui.unlock()

	def on_Update(self):
		'''更新処理'''

		self.Mes_BOX("更新中...")

		if (self.Work_Group_ID == MYLIST_WORK_ID or self.Work_Group_ID == WATCHLIST_WORK_ID) and not self.TAG_FLAG:
			self.list3.reset()
			self.list3.selectItem(0)

			update_index = self.Update_List.getSelectedPosition()
			sort_index = NICO_MYLIST_VIDEO_SORT_DATA_ARRAY[update_index]
			if update_index % 2 == 0:
				self.List3_Data_Tuple_List.sort(cmp=lambda x, y: cmp(int(x[2][sort_index]), int(y[2][sort_index])), reverse=True)
			else:
				self.List3_Data_Tuple_List.sort(cmp=lambda x, y: cmp(int(x[2][sort_index]), int(y[2][sort_index])))
			for result in self.List3_Data_Tuple_List:
				self.list3.addItem(result[0])
#		elif self.Work_Group_ID == WATCHLIST_WORK_ID:
#			self.on_WatchList_list2()
		elif self.Work_Group_ID == LIVE_WORK_ID and not self.TAG_FLAG:
			if self.List1_Index == 0 or self.List1_Index == 1:
				self.on_Live_list1()
			elif self.List1_Index == 4 or self.List1_Index == 5 or self.List1_Index == 6:
				self.on_Live_list1()
			elif self.List1_Index == 7:
				self.liveRankingSearch(self.List2_Data_Tuple_List[self.List2_Index][1])
			elif self.List1_Index == 8:
#				page = self.Page_Num_List.getSelectedPosition() + 1
#				start = math.floor(time.time()) + 60*60*6 * (page-1)
#				self.timelineLiveSearch(start)

				self.timelineLiveSearch(math.floor(time.time()))
			else:
				update_index = self.Update_List.getSelectedPosition()
				page = self.Page_Num_List.getSelectedPosition() + 1
				if self.List2_Index == 0 and self.time_shift:
					keyword = self.List1_Data_Tuple_List[self.List1_Index][0]
				else:
					if self.live_sort_type < len(LIVE_SORT_ARRAY) or self.List2_Index == 0:
						keyword = self.List2_Data_Tuple_List[self.List2_Index][1]
					else:
						keyword = self.List2_Data_Tuple_List[self.List2_Index][0]
						m = re.compile('(.*)\(.*\)').search(keyword)
						if m: keyword = m.group(1)
				self.on_Live_list2(keyword,update_index,page,self.time_shift)

		elif self.Work_Group_ID == OTHER_WORK_ID and not self.TAG_FLAG:
			if self.List1_Index == 2:
				self.on_Other_list2()
			elif self.List1_Index == 3:
				self.on_Other_list2()
			elif self.List1_Index == 4:
				self.on_Other_list2()
			elif self.List1_Index == 5:
				user_id = self.List2_Data_Tuple_List[self.List2_Index][1]
				page = self.Page_Num_List.getSelectedPosition() + 1
				self.on_Twitter_list2(user_id,page)
			elif self.List1_Index == 6:
				page = self.Page_Num_List.getSelectedPosition() + 1
				self.on_TwitterSearch_list2(None, None, page)
		elif self.Work_Group_ID == CHANNEL_WORK_ID and not self.TAG_FLAG:
			sort_index = self.Update_List.getSelectedPosition()
			page = self.Page_Num_List.getSelectedPosition() + 1
			self.on_Channel_list2(page, NICO_SEARCH_VIDEO_SORT_DATA_ARRAY[sort_index][0], NICO_SEARCH_VIDEO_SORT_DATA_ARRAY[sort_index][1])
		else:
			sortIndex = self.Update_List.getSelectedPosition()
			page = self.Page_Num_List.getSelectedPosition()

#				sort_req = Sort_Element[sortIndex]
			if page == 0:
				page_req = ""
			else:
				page_req = "page=" + str(page + 1)

			if page == 0 and sortIndex == 0:
				qes_PLUS = ""
				qes_sort_PLUS = "?"
			elif page == 0 and sortIndex >= 1:
				qes_PLUS = ""
				qes_sort_PLUS = "?"
			elif page >= 1 and sortIndex == 0:
				qes_PLUS = "?"
				qes_sort_PLUS = "&"
			else:
				qes_PLUS = "?"
				qes_sort_PLUS = "&"

			if self.Work_Group_ID == CHANNEL_WORK_ID :
				self.list3.reset()
				self.list3.selectItem(0)
				self.List3_Data_Tuple_List = []
				selectChannel = 'video/' + self.List2_Data_Tuple_List[self.List2_Index][1][0]
				sopt = qes_PLUS + page_req + qes_sort_PLUS + "sort=%s&order=%s" % (NICO_SEARCH_VIDEO_SORT_DATA_ARRAY[sortIndex][0],NICO_SEARCH_VIDEO_SORT_DATA_ARRAY[sortIndex][1])	 # 6-128秋 debug

				self.on_Ranking_list1(href_href = "%s" % (selectChannel + sopt))
			else:
				video_id_list = []

				#ランキングの処理
				if (3 == self.List1_Index) :
					self.on_Ranking_list1()
					return None
				if (4 <= self.List1_Index and self.List1_Index <= 7) :
					self.on_Ranking_list1()
					return None
				else:
					self.Mes_BOX("取得中...")

					self.list3.reset()
					self.list3.selectItem(0)
					self.List3_Data_Tuple_List = []
					if self.serch_TorK == "mylist_search":
						Tag_Name = self.List2_Data_Tuple_List[self.List2_Index][1]
						total,resultArray = self.nicoVideo.getSearchMylist(Tag_Name,page + 1,"","")
						for result in resultArray:
							video_id = result[0]
							title_name = '(' + result[2] + ') ' +  result[1]
							self.list3.addItem(title_name)
							self.List3_Data_Tuple_List.append((title_name,result[0]))
						self.Mes_BOX(str(total) + " HIT !!")
					else:
						if self.List2_Index == None:
							self.on_Ranking_list1()
							return None

						sort = NICO_SEARCH_VIDEO_SORT_DATA_ARRAY[sortIndex]
						Tag_Name = self.List2_Data_Tuple_List[self.List2_Index][1]
						if self.serch_TorK == "tag":
#							xbmcgui.Dialog().ok("getSearchTag","%s,%s,%s,%s" % (Tag_Name,page + 1,sort[0],sort[1]))
							total,dataArray = self.nicoVideo.getSearchTag(Tag_Name,page + 1,sort[0],sort[1])
						else:
#							xbmcgui.Dialog().ok("getSearchKeyword","%s,%s,%s,%s" % (Tag_Name,page + 1,sort[0],sort[1]))
							total,dataArray = self.nicoVideo.getSearchKeyword(Tag_Name,page + 1,sort[0],sort[1])
						self.Mes_BOX(str(total) + " HIT !!")
						for data in dataArray:
							video_id = data[0]
							title_name =  '%s%s (再生：%s | コメ：%s | マイ：%s | 宣伝：%s | 時間：%s)' % ( getTitlePrefix(data[0]) ,data[1], data[3], data[4], data[5], data[6], data[2])
							self.List3_Data_Tuple_List.append((title_name,video_id))
							if self.view_watched:
								title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
							self.list3.addItem(title_name)
							video_id_list.append(video_id)
				self.tbn_Down(video_id_list)
			self.addHistoryStock()


	def on_Channel(self):
		'''チャンネル選択処理'''

		self.Mes_BOX("取得中...")
		self.Work_Group_ID = CHANNEL_WORK_ID
		self.List1_Data_Tuple_List = []
		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list1.reset()
		self.list2.reset()
		self.list3.reset()
		self.list1.selectItem(0)
		self.list2.selectItem(0)
		self.list3.selectItem(0)

		self.List1_Data_Tuple_List.append(("お気に入り",""))
		self.list1.addItem("お気に入り")

		self.List1_Data_Tuple_List.append(("ランキング",""))
		self.list1.addItem("ランキング")

		if self.CHANNEL_LIST_NAME_ARRAY == None or self.CHANNEL_ARRAY == None:
			self.CHANNEL_LIST_NAME_ARRAY,self.CHANNEL_ARRAY = self.nicoVideo.getChannel()

		chcount = 0
		for i in range(len(self.CHANNEL_LIST_NAME_ARRAY)):
			chcount += len(self.CHANNEL_ARRAY[i])
			label = "%s (%d)" %(self.CHANNEL_LIST_NAME_ARRAY[i],len(self.CHANNEL_ARRAY[i]))
			self.List1_Data_Tuple_List.append((label,self.CHANNEL_ARRAY[i]))
			self.list1.addItem(label)

		self.setFocus(self.list1)
		self.Mes_BOX("（全%dch）" % (chcount))

	def on_Channel_list1(self):
		'''チャンネル リスト１の選択処理'''

		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list2.reset()
		self.list2.selectItem(0)
		self.list3.reset()
		self.list3.selectItem(0)

		ch_list = []

		if self.List1_Index == 0:
			channelList = self.nicoVideo.getMyChannel()
			for channelData in channelList:
				self.list2.addItem(channelData[1])
				self.List2_Data_Tuple_List.append((channelData[1],channelData))
				ch_list.append(channelData[0])
		elif self.List1_Index == 1:
			self.Mes_BOX("取得中...")

			self.list2.addItem(NO_TITLE)
			self.List2_Data_Tuple_List.append((NO_TITLE,None))

			video_id_list = []
			tbn_id_list = []
			resultArray = self.nicoVideo.getChannelRanking()

			for i in range(len(resultArray)):
				result = resultArray[i]
				video_id =  result[0]
				rank = result[6]

				if rank == "new":
					rank_str = "(NEW!)"
				elif rank == "up":
					rank_str = "(↑)"
				elif rank == "down":
					rank_str = "(↓)"
				elif rank == "jumpup":
					rank_str = "(10↑)"
				elif rank == "-":
					rank_str = "(-)"
				else :
					rank_str = rank

				title = '第%s位：%s %s (再生 %s | コメ %s | マイ %s | 時間 %s)[%s]' % (i+1, rank_str, result[1], result[2], result[3], result[4], result[5],video_id)
				self.List3_Data_Tuple_List.append((title,result[0]))
				title = self.view_watched_prefix[self.isSaveComment(video_id)] + title
				self.list3.addItem(title)
				video_id_list.append(video_id)
				tbn_id_list.append(result[7])
			self.tbn_Down(video_id_list,tbn_id_list)
			self.addHistoryStock()
			self.Mes_BOX("")
		else:
			chdata_list = self.List1_Data_Tuple_List[self.List1_Index][1]
			for channelData in chdata_list:
				title = channelData[1]
				self.list2.addItem(title)
				self.List2_Data_Tuple_List.append((title,channelData))
				ch_list.append(channelData[0])

		if len(self.List2_Data_Tuple_List) == 0:# List2が空っぽなら
			self.Mes_BOX("何も取得できませんでした")
			self.list2.addItem("何も取得できませんでした")
			self.List2_Data_Tuple_List.append(('何も取得できませんでした',""))
		else:
			self.channelicon_Down(ch_list)
#			self.setFocus(self.list2)
#			data = self.List2_Data_Tuple_List[self.List1_Index][1]
#			cid = data[0]
#			if len(data) == 3:
#				title = "%s\n%s (%s)" % (data[2],data[1],cid)
#			else:
#				title = "%s (%s)" % (data[1],cid)
#			self.Mes_BOX(title)
#			self.setChannelImage(cid)


	def on_Channel_list2(self, page=1,sort='f',order='d'):
		'''チャンネル リスト２の選択処理'''
		self.List3_Data_Tuple_List = []
		self.list3.reset()
		self.list3.selectItem(0)

		selectChannel = 'video/%s?page=%s&sort=%s&order=%s' % (self.List2_Data_Tuple_List[self.List2_Index][1][0],page,sort,order)
		self.on_Ranking_list1(href_href = "%s" %selectChannel)

	def on_WatchList(self):
		'''お気に入りユーザー選択処理'''

		self.Mes_BOX("取得中...")
		self.Work_Group_ID = WATCHLIST_WORK_ID
		self.List1_Data_Tuple_List = []
		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list1.reset()
		self.list2.reset()
		self.list3.reset()
		self.list1.selectItem(0)
		self.list2.selectItem(0)
		self.list3.selectItem(0)

		WatchList_List = self.nicoVideo.getMyWatchList()

		userid_list = []
		usericon_url_list = []
		video_id_list = []

		for data in WatchList_List:
			self.list1.addItem(data[1])
			userid_list.append(data[0])
			usericon_url_list.append(data[2])
			self.List1_Data_Tuple_List.append((data[1],data))
			if data[3] != None:
				m = re.compile('"http://www.nicovideo.jp/watch/(.*?)">(.*?)</a>').search(data[3])
				if m :
					video_id = m.group(1)
					title_name = data[1] + ":" + m.group(2)
					self.List3_Data_Tuple_List.append((title_name,video_id))
					if self.view_watched:
						title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
					self.list3.addItem(title_name)
					video_id_list.append(video_id)

		if 0 < len(video_id_list):
			self.list2.addItem(NO_TITLE)
			self.List2_Data_Tuple_List.append((NO_TITLE,None))
			self.tbn_Down(video_id_list,None)

		if 0 < len(WatchList_List):
			self.setFocus(self.list1)
			self.usericon_Down(userid_list, usericon_url_list)

			data = self.List1_Data_Tuple_List[0][1]
			user_id = data[0]
			if data[3] == None:
				discript = ""
			else:
				discript = re.compile(r'<.*?>').sub('', data[3])

			self.Mes_BOX(discript)
			num = int(user_id)
			path = os.path.join(os.path.join(usericon_dir,str(num%1000)),user_id + '.jpg')
			if os.path.exists(path):
				self.nico_tbn_image.setImage(path)
		else:
			self.Mes_BOX("お気に入りユーザーに登録されているユーザーがいません")

	def on_WatchList_list1(self,user_id = None):
		'''お気に入りユーザー リスト１の選択処理'''

		self.Mes_BOX("取得中...")
		self.List2_Data_Tuple_List = []

		self.list2.reset()
		self.list2.selectItem(0)
		self.list3.reset()
		self.list3.selectItem(0)

		if user_id == None:
			user_id = self.List1_Data_Tuple_List[self.List1_Index][1][0]
		UserWatchList_List = self.nicoVideo.getUserWatchList(user_id)

		for val in UserWatchList_List:
			self.list2.addItem(val[1])
			self.List2_Data_Tuple_List.append((val[1],val[0]))

		self.Mes_BOX("ユーザーID: %s" % user_id)

		if int( self.list2.size() ) == 0:
			self.list2.addItem("何も取得できませんでした")
			self.List2_Data_Tuple_List.append(('何も取得できませんでした',""))
		else:
			self.setFocus(self.list2)

	def on_WatchList_list2(self):
		'''お気に入りユーザー リスト２の選択処理'''

		self.list3.reset()
		self.list3.selectItem(0)
		channel_id = self.List2_Data_Tuple_List[self.List2_Index][1]
		if channel_id == "":
			return None
		self.on_Ranking_list1(href_href = "%s" % channel_id)

	def on_MyList(self):
		'''マイリスト選択処理'''

		self.Work_Group_ID = MYLIST_WORK_ID
		self.List1_Data_Tuple_List = []
		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list1.reset()
		self.list2.reset()
		self.list3.reset()
		self.list1.selectItem(0)
		self.list2.selectItem(0)
		self.list3.selectItem(0)

		self.list1.addItem("★マイリスト")
		self.List1_Data_Tuple_List.append(("★マイリスト",""))

		category_ptn = re.compile(r"Category([0-9]+?):(.*)")
		favoriteStr = open(favorite_txt, 'r').read()
		for m in category_ptn.finditer(favoriteStr):
			self.list1.addItem(m.group(2))
			self.List1_Data_Tuple_List.append((m.group(2),""))

		self.setFocus(self.list1)

	def on_Mylist_list1(self):
		'''マイリスト リスト１の選択処理'''

		self.Mes_BOX("取得中...")
		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list2.reset()
		self.list2.selectItem(0)
		self.list3.reset()
		self.list3.selectItem(0)

		if self.List1_Index == 0:
			mylistArray = self.nicoVideo.getMyList()
			self.list2.addItem("とりあえずマイリスト")
			self.List2_Data_Tuple_List.append(("とりあえずマイリスト","/api/deflist/list"))
			for mylistData in mylistArray:
				self.list2.addItem(mylistData[1])
				self.List2_Data_Tuple_List.append((mylistData[1],'mylist/'+mylistData[0]))
		else:
			# お気に入り
			favorite_file = open(favorite_txt, 'r').read()
			mylist_ptn = re.compile(r'cate.*?"%s".*?"http://www.nicovideo.jp/(mylist/[0-9/]+?(?=">))">(.+?(?=<))</' % int(self.List1_Index) )
			video_ptn = re.compile(r'cate.*?"%s".*?"http://www.nicovideo.jp/watch/(.+?(?=">))">(.+?(?=<))</' % int(self.List1_Index) )

			for m in mylist_ptn.finditer(favorite_file):
				self.list2.addItem(m.group(2))
				self.List2_Data_Tuple_List.append((m.group(2),m.group(1)))

			for m in video_ptn.finditer(favorite_file):
				self.list3.addItem(m.group(2))
				self.List3_Data_Tuple_List.append((m.group(2),m.group(1)))

		if int( self.list2.size() ) == 0:# List2が空っぽなら
			self.Mes_BOX("登録無し")
			self.list2.addItem("登録無し")
			self.List2_Data_Tuple_List.append(('登録無し',""))
		else:
			self.setFocus(self.list2)
			self.Mes_BOX("")

	def on_Mylist_list2(self):
		'''マイリスト リスト２の選択処理'''
		self.list3.reset()
		self.list3.selectItem(0)
		selectMYlist = self.List2_Data_Tuple_List[self.List2_Index][1]
		if selectMYlist == "":
			return None
		self.on_Ranking_list1(href_href = "%s" % selectMYlist)

	def on_Ranking(self):
		'''ランキング選択処理'''

		self.Work_Group_ID = RANKING_WORK_ID
		self.List1_Data_Tuple_List = []
		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list1.reset()
		self.list2.reset()
		self.list3.reset()
		self.list1.selectItem(0)
		self.list2.selectItem(0)
		self.list3.selectItem(0)

		#nico_category_URLと対になっています。
		for m in RANKING_LIST1_NAME_ARRAY:
			self.list1.addItem(m)
			self.List1_Data_Tuple_List.append((m,m))

		self.setFocus(self.list1)

	def on_Ranking_list1(self, href_href = None, page = None, workgroup_id = None):
		'''ランキング リスト１の選択処理'''
		if workgroup_id == None:
			workgroup_id = self.Work_Group_ID

		# リスト3の初期化
		self.list3.reset()
		self.list3.selectItem(0)
		nico_tag = None

		if href_href == None:
			self.list2.reset()
			self.list2.selectItem(0)

		if workgroup_id == RANKING_WORK_ID and href_href == None:
			self.List2_Data_Tuple_List = []
			# 時以外のランキング
			if 4 <= self.List1_Index and self.List1_Index <= 7:
				for categoryLabel in RANKING_LIST2_NAME_ARRAY:
					self.list2.addItem(categoryLabel)
					self.List2_Data_Tuple_List.append((categoryLabel,categoryLabel))
				self.list2.selectItem(0)
				self.setFocus(self.list2)
				return None

			# 任意検索ワードを選択した場合
			if self.List1_Index == 0:
				self.list2.addItem("Google Suggest")
				self.List2_Data_Tuple_List.append(("Google Suggest","Google Suggest"))
				for keyword in self.search_keyword:
					self.list2.addItem(keyword)
					self.List2_Data_Tuple_List.append((keyword,keyword))
				self.setFocus(self.list2)
				return None

			# お気に入りタグを選択した場合
			if self.List1_Index == 1:
				tagArray = self.nicoVideo.getFavtag()
				for tag in tagArray:
					self.list2.addItem(tag)
					self.List2_Data_Tuple_List.append((tag,tag))
				self.setFocus(self.list2)
				return None

		self.Mes_BOX("取得中...")

		if href_href == None:
			if workgroup_id == RANKING_WORK_ID and self.List1_Index == 3:
				if self.ranking_type_select:
					select = xbmcgui.Dialog().select("ランキング対象の選択",RANK_TYPE_NAME_LIST)
					if 0<=select:
						self.ranking_type = select
					else:
						return None
				nico_tag = "ranking/%s/hourly/all?rss=2.0" %(RANK_TYPE_DATA_LIST[self.ranking_type])
			else:
				nico_tag = RANKING_LIST1_CATEGORY_ARRAY[self.List1_Index]
		else:
			nico_tag = href_href

		if page != None:
			nico_tag += "?page=" + str(page)

		if workgroup_id == CHANNEL_WORK_ID:
			body = self.xbmc_channel_Access(nicoURL = nico_tag)
		else:
			body = self.xbmc_nico_Access(nicoURL = nico_tag)
#		print body

		# 注目のタグを選択した場合
		if self.List1_Index == 2 and workgroup_id == RANKING_WORK_ID and href_href == None:
			# 関連タグ抽出用
			Relation_TAG = re.compile(u'rel="tag" class="level_([0-9])" href="tag/([%0-9A-Z]*?(?=["]))".*?>(.*?)</a>.*?nbsp;')
			# vvvv 3/07 注目のタグ仕様変更に伴い数値を利用しソート後、表示に変更
			taglist = []
			for m in Relation_TAG.finditer(body):
				TAGurldecode = urllib.unquote(m.group(2))
				taglist.append([int(m.group(1)),TAGurldecode])

			taglist.sort()
			for i in range(len(taglist)):
				self.list2.addItem(taglist[i][1])
				self.List2_Data_Tuple_List.append((taglist[i][1],taglist[i][1]))
			self.Mes_BOX("%s HIT !!" % len(taglist))
			return None
		else:
			tbn_id_list = None
			self.List3_Data_Tuple_List = []
			video_id_list = []
			if workgroup_id == CHANNEL_WORK_ID:
				# チャンネル
				tbn_id_list = []
				resultArray,total = self.nicoVideo.parceChannelVideoSource(body)
				for result in resultArray:
					video_id = result[0]
					title_name = '%s  (再生：%s | コメ：%s | マイ：%s | 時間：%s | %s) [%s]' % (result[1],result[2],result[3],result[4],result[5],result[7],result[0])
					title_name = getTitlePrefix(video_id) + title_name
					if result[8]:
						title_name = "[有料] " + title_name
					self.List3_Data_Tuple_List.append((title_name,video_id,result))
					if self.view_watched:
						title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
					self.list3.addItem(title_name)
					tbn_id_list.append(result[6])
					video_id_list.append(video_id)
				self.Mes_BOX("%s HIT !!" % total)

			elif workgroup_id == MYLIST_WORK_ID or workgroup_id == WATCHLIST_WORK_ID:
				resultArray = self.nicoVideo.parseMylistSource(body)
				for result in resultArray:
					video_id = result[0]
					title_name = '%s%s  (再生：%s | コメ：%s | マイ：%s | 時間：%s) [%s]' % (getTitlePrefix(result[0]),result[1],re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', result[2]),re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', result[3]),re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', result[4]),convertTime(result[5]),result[0])
					self.List3_Data_Tuple_List.append((title_name,video_id,result))
					if self.view_watched:
						title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
					self.list3.addItem(title_name)
					video_id_list.append(video_id)
				self.Mes_BOX("%s HIT !!" % len(resultArray))

			elif workgroup_id == RANKING_WORK_ID:
				# 毎時ランキング
				if self.List1_Index == 3:
					rankingDate = self.nicoVideo.parceRankingRssSource(body)
					self.list2.addItem(NO_TITLE)
					self.List2_Data_Tuple_List.append((NO_TITLE,None))
					for i in range(len(rankingDate)):
						video_id = rankingDate[i][0]
						title_name = '%s%s  (＋%s 再生：%s | コメ：%s | マイ：%s | 時間：%s | %s) [%s]' % (getTitlePrefix(rankingDate[i][0]),rankingDate[i][1],rankingDate[i][4],rankingDate[i][5],rankingDate[i][6],rankingDate[i][7],rankingDate[i][8],rankingDate[i][2],rankingDate[i][0])
						self.List3_Data_Tuple_List.append((title_name,rankingDate[i][0]))
						if self.view_watched:
							title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
						self.list3.addItem(title_name)
						video_id_list.append(video_id)
					self.Mes_BOX('カテゴリ合算 毎時 %s ランキング' % (RANK_TYPE_NAME_LIST[self.ranking_type]))
				# 新着投稿動画
				if self.List1_Index == 8:
					tbn_id_list = []
					resultArray = self.nicoVideo.parceNewarrivalSource(body)
					self.list2.addItem(NO_TITLE)
					self.List2_Data_Tuple_List.append((NO_TITLE,None))

					for i in range(len(resultArray)):
						video_id = resultArray[i][0]
						title_name = '%s%s  (再生：%s | コメ：%s | マイ：%s | 宣伝：%s | 時間：%s) [%s]' % (getTitlePrefix(resultArray[i][0]),resultArray[i][1],resultArray[i][3],resultArray[i][4],resultArray[i][5],resultArray[i][7],resultArray[i][2],resultArray[i][0])
						self.List3_Data_Tuple_List.append((title_name,resultArray[i][0]))
						if self.view_watched:
							title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
						self.list3.addItem(title_name)
						tbn_id_list.append(resultArray[i][6])
						video_id_list.append(video_id)

					self.Mes_BOX('新着投稿動画')
				else:
					tbn_id_list = []
					resultArray = self.nicoVideo.parceCategorySource(body)

					if href_href == None and 7 < self.List1_Index:
						tagList = self.nicoVideo.parceRelationTagSource(body)
						self.list2.addItem("- 人気のタグ順 -")
						self.List2_Data_Tuple_List.append(("-人気のタグ順-",""))
						if tagList != None:
							for i in range(len(tagList)):
								if i == 10:
									self.list2.addItem("- その他のタグ -")
									self.List2_Data_Tuple_List.append(("-その他-",""))

								self.list2.addItem(tagList[i][1])
								self.List2_Data_Tuple_List.append((tagList[i][1],tagList[i][1]))

#							for tag in tagList:
#								self.list2.addItem(tag[1])
#								self.List2_Data_Tuple_List.append((tag[1],tag[1]))

					for i in range(len(resultArray)):
						video_id = resultArray[i][0]
						title_name = '%s%s  (再生：%s | コメ：%s | マイ：%s | 宣伝：%s | 時間：%s) [%s]' % (getTitlePrefix(resultArray[i][0]),resultArray[i][1],resultArray[i][3],resultArray[i][4],resultArray[i][5],resultArray[i][7],resultArray[i][2],resultArray[i][0])
						self.List3_Data_Tuple_List.append((title_name,resultArray[i][0]))
						if self.view_watched:
							title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
						self.list3.addItem(title_name)
						tbn_id_list.append(resultArray[i][6])
						video_id_list.append(video_id)

					self.Mes_BOX('タグ検索 %s' % (RANKING_LIST1_NAME_ARRAY[self.List1_Index]))

			self.addHistoryStock()
			self.tbn_Down(video_id_list,tbn_id_list)

		if int( self.list2.size() ) == 0:
			self.list2.addItem("何も取得できませんでした")
			self.List2_Data_Tuple_List.append(('何も取得できませんでした',""))
		if int( self.list3.size() ) == 0:
			self.Mes_BOX("何も取得できませんでした")
			self.list3.addItem("何も取得できませんでした")
			self.List3_Data_Tuple_List.append(('何も取得できませんでした',""))


	def on_Ranking_list2(self, mylist_href = None, page = None, workgroup_id = None):
		'''ランキング リスト２の選択処理'''
		if workgroup_id == None:
			workgroup_id = self.Work_Group_ID

		if 0 == self.List1_Index and workgroup_id == RANKING_WORK_ID and mylist_href == None and not self.TAG_FLAG:
			if self.List2_Index == 0:
				self.inputKeyword()
				return None

		Tag_Name = self.List2_Data_Tuple_List[self.List2_Index][1]
		if Tag_Name == None or Tag_Name == "":
			return None
		if self.__dbg__: print "href: %s" % mylist_href
#		Tag_Name = self.list2.getListItem(self.List2_Index).getLabel()
#		if Tag_Name == NO_TITLE:
#			return None

		self.List3_Data_Tuple_List = []
		self.list3.reset()
		self.list3.selectItem(0)

		video_id_list = []
		# 毎時以外のランキング
		if 4 <= self.List1_Index and self.List1_Index <= 7 and workgroup_id == RANKING_WORK_ID and mylist_href == None and not self.TAG_FLAG :
			if self.ranking_type_select:
				select = xbmcgui.Dialog().select("ランキング対象の選択",RANK_TYPE_NAME_LIST)
				if 0<=select:
					self.ranking_type = select
				else:
					return None

			RANKING_RANGE_LIST = ["daily","weekly","monthly","total"]
			if self.List2_Index != 0:
				page = None
#				self.Mes_BOX("nico tag = "+nico_tag)
			if self.__dbg__: print "getRankingList: %s,%s,%s,%s" % (RANKING_RANGE_LIST[self.List1_Index-4],RANK_TYPE_DATA_LIST[self.ranking_type],RANKING_LIST2_CATEGORY_ARRAY[self.List2_Index],page)
			rankingDataList = self.nicoVideo.getRankingList(RANKING_RANGE_LIST[self.List1_Index-4],RANK_TYPE_DATA_LIST[self.ranking_type],RANKING_LIST2_CATEGORY_ARRAY[self.List2_Index],page)
			for i in range(len(rankingDataList)):
				video_id = rankingDataList[i][0]
				title_name = '%s%s  (＋%s 再生：%s | コメ：%s | マイ：%s | 時間：%s | %s) [%s]' % (getTitlePrefix(rankingDataList[i][0]),rankingDataList[i][1],rankingDataList[i][4],rankingDataList[i][5],rankingDataList[i][6],rankingDataList[i][7],rankingDataList[i][8],rankingDataList[i][2],rankingDataList[i][0])
				self.List3_Data_Tuple_List.append((title_name,video_id,rankingDataList[i]))
				if self.view_watched:
					title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
				self.list3.addItem(title_name)
				video_id_list.append(video_id)

			if self.List2_Index == 0:
				if page == 2:
					self.list3.addItem(" >> #1-100")
					self.list3.addItem(" >> #201-300")
					self.List3_Data_Tuple_List.append((" >> #1-100"," >> #1-100"))
					self.List3_Data_Tuple_List.append((" >> #201-300"," >> #201-300"))

				elif page == 3:
					self.list3.addItem(" >> #1-100")
					self.list3.addItem(" >> #101-200")
					self.List3_Data_Tuple_List.append((" >> #1-100"," >> #1-100"))
					self.List3_Data_Tuple_List.append((" >> #101-200"," >> #101-200"))
				else:
					self.list3.addItem(" >> #101-200")
					self.list3.addItem(" >> #201-300")
					self.List3_Data_Tuple_List.append((" >> #101-200"," >> #101-200"))
					self.List3_Data_Tuple_List.append((" >> #201-300"," >> #201-300"))

			category = ("日間","週間","月間","合計")
			self.Mes_BOX('%s %s %s ランキング' % (RANKING_LIST2_NAME_ARRAY[self.List2_Index],category[self.List1_Index-4],RANK_TYPE_NAME_LIST[self.ranking_type]))
		else:
			if (workgroup_id == MYLIST_WORK_ID or mylist_href != None) and not self.TAG_FLAG:
				body = self.xbmc_nico_Access(nicoURL = mylist_href)
				#print body
				resultArray = self.nicoVideo.parseMylistSource(body)

				if len(resultArray) == 0:
					self.Mes_BOX('マイリストに登録された動画はありませんでした' % Tag_Name)
					self.list3.addItem("マイリストに登録された動画はありませんでした")
					self.List3_Data_Tuple_List.append(("マイリストに登録された動画はありませんでした",""))
				else:
					for result in resultArray:
						video_id = result[0]
						title_name =  '%s%s  (再生：%s | コメ：%s | マイ：%s | 時間：%s)' % (getTitlePrefix(result[0]),result[1],re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', result[2]),re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', result[3]),re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', result[4]),convertTime(result[5]))
						self.List3_Data_Tuple_List.append((title_name,result[0],result))
						if self.view_watched:
							title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
						self.list3.addItem(title_name)
						video_id_list.append(video_id)
			else:
				select = xbmcgui.Dialog().select("検索種類",["キーワード","タグ","マイリスト"])
				if select == 0:
					self.serch_TorK = "search"
				elif select == 1:
					self.serch_TorK = "tag"
				elif select == 2:
					self.serch_TorK = "mylist_search"
				else:
					return None

				sortIndex = self.Update_List.getSelectedPosition()
				sort = NICO_SEARCH_VIDEO_SORT_DATA_ARRAY[sortIndex]

				if self.serch_TorK == "mylist_search":
					total,resultArray = self.nicoVideo.getSearchMylist(Tag_Name)
					for result in resultArray:
						video_id = result[0]
						title_name = '(' + result[2] + ') ' +  result[1]
						self.List3_Data_Tuple_List.append((title_name,result[0]))
						self.list3.addItem(title_name)
						video_id_list.append(result[0])
				else:
					if self.serch_TorK == "tag":
						total,resultArray = self.nicoVideo.getSearchTag(Tag_Name,1,sort[0],sort[1])
					else:
						total,resultArray = self.nicoVideo.getSearchKeyword(Tag_Name,1,sort[0],sort[1])

					for result in resultArray:
						video_id = result[0]
						title_name = '%s%s  (再生：%s | コメ：%s | マイ：%s | 宣伝：%s | 時間：%s)' % (getTitlePrefix(result[0]),result[1],result[3],result[4],result[5],result[6],result[2])
						self.List3_Data_Tuple_List.append((title_name,video_id,result))
						if self.view_watched:
							title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
						self.list3.addItem(title_name)
						video_id_list.append(video_id)

				if len(resultArray) == 0:
					if self.serch_TorK == "mylist_search":
						self.Mes_BOX('%s を含むマイリストは見つかりませんでした' % Tag_Name)
						self.list3.addItem('%s を含むマイリストは見つかりませんでした' % Tag_Name)
						self.List3_Data_Tuple_List.append(('%s を含むマイリストは見つかりませんでした' % Tag_Name,""))
					else:
						self.Mes_BOX('%s を含む動画は見つかりませんでした' % Tag_Name)
						self.list3.addItem('%s を含む動画は見つかりませんでした' % Tag_Name)
						self.List3_Data_Tuple_List.append(('%s を含む動画は見つかりませんでした' % Tag_Name,""))
				else:
					self.Mes_BOX("%s HIT !!" % total)
				self.Page_Num_List.selectItem(0)

				if 100 < total / 30:
					total = 100 * 30

				HIT_Page_MAX = total / 30
				if not int(total) % 30 == 0:
					HIT_Page_MAX = HIT_Page_MAX + 1
				#print HIT_Num, HIT_Page_MAX
				self.Page_Num_List.reset()
				for i in range(1, HIT_Page_MAX + 1):
					self.Page_Num_List.addItem(str(i))

		if self.list3.size() == 0:
			self.Mes_BOX("何も取得できませんでした")
			self.list3.addItem("何も取得できませんでした")
			self.List3_Data_Tuple_List.append(('何も取得できませんでした',""))
		if 0 < len(video_id_list):
			self.tbn_Down(video_id_list)
#			self.list3.selectItem(0)
		self.addHistoryStock()

	def on_Ranking_list3(self):
		'''ランキング リスト３の選択処理'''
		title = self.List3_Data_Tuple_List[self.List3_Index][0]
		video_id = self.List3_Data_Tuple_List[self.List3_Index][1]
		if not video_id:
			return None
		else:
			# 生放送
			if re.compile("lv.+?").search(video_id):
				self.startVideoPlayer(video_id,title,streaming=self.isStreaming)
			# Mylist対応
			elif re.compile("mylist.+?").search(video_id):
#					print "list3 Mylist", video_id
				self.TAG_FLAG = False
				self.on_Ranking_list2(mylist_href = "%s" % video_id)
			# RANK200-300に対応
			elif re.compile("[ ]>>[ ]#[12].+?").search(video_id):
				if re.compile("[ ]>>[ ]#101.+?").search(video_id):
					self.on_Ranking_list2(page = 2)
				elif re.compile("[ ]>>[ ]#201.+?").search(video_id):
					self.on_Ranking_list2(page = 3)
				else:
					self.on_Ranking_list2()
			else:
				self.startVideoPlayer(video_id,title,streaming=self.isStreaming)
#				#TO DO
#				elif video_id[0:2] == '\\\\':
#					self.playMedia("smb:"+video_id)
#					if self.comment_view:
#						xbmc.executebuiltin("XBMC.RunScript(%s, %s)" % (nico_py,"pause"))


	def on_Live(self):
		'''ニコ生選択処理'''

		self.Work_Group_ID = LIVE_WORK_ID
		self.List1_Data_Tuple_List = []
		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list1.reset()
		self.list2.reset()
		self.list3.reset()
		self.list1.selectItem(0)
		self.list2.selectItem(0)
		self.list3.selectItem(0)

		self.list1.addItem("マイページ")
		self.List1_Data_Tuple_List.append(("マイページ",""))

		self.list1.addItem("コミュニティ")
		self.List1_Data_Tuple_List.append(("コミュニティ",""))

		self.list1.addItem("登録ワード")
		self.List1_Data_Tuple_List.append(("登録ワード",""))

		self.list1.addItem("お気に入りタグ")
		self.List1_Data_Tuple_List.append(("お気に入りタグ",""))

		self.list1.addItem("放送中ランキング")
		self.List1_Data_Tuple_List.append(("生放送中ランキング",""))

		self.list1.addItem("予約数ランキング")
		self.List1_Data_Tuple_List.append(("番組予約数ランキング",""))

		self.list1.addItem("過去番組ランキング")
		self.List1_Data_Tuple_List.append(("過去の番組ランキング",""))

		self.list1.addItem("旧ランキング")
		self.List1_Data_Tuple_List.append(("旧ランキング",""))

		self.list1.addItem("公式＆チャンネル")
		self.List1_Data_Tuple_List.append(("公式＆チャンネル",""))

		for tab in LIVE_TAB_NAME_ARRAY:
			self.list1.addItem(tab)
			self.List1_Data_Tuple_List.append((tab,""))
		self.setFocus(self.list1)


	def on_Live_list1(self):
		'''
			ニコ生 リスト１の選択処理
		'''

		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list2.reset()
		self.list3.reset()
		self.list2.selectItem(0)
		self.list3.selectItem(0)

		if self.List1_Index == 0:
			self.Mes_BOX("取得中...")

			self.list2.addItem(NO_TITLE)
			self.List2_Data_Tuple_List.append((NO_TITLE,None))

			lv_id_list = []
			lv_tbn_list = []
			ch_list = []
			co_list = []

			#旧取得方法
#			start = math.floor(time.time())
#			timelineArray = self.nicoVideo.getTimeline(start,start + 60*30)
#			tmpArray = []
#			for r in timelineArray:
#				if r['status'] == 'onair' and r['category'] != 'co':
#					tmpArray.append(r)
#			timelineArray = tmpArray
#			liveArray,reserveArray,timeshiftArray = self.nicoVideo.getLiveMypageData()
#
#			self.list3.addItem("--------------放送中の公式/チャンネル生放送--------------")
#			self.List3_Data_Tuple_List.append(("------------放送中の公式/チャンネル生放送------------",None))
#			if len(timelineArray) == 0:
#				self.list3.addItem(NO_TITLE)
#				self.List3_Data_Tuple_List.append((NO_TITLE,None))
#			else:
#				for r in timelineArray:
#					dt = datetime.datetime.fromtimestamp(float(r['start']))
#
#					if r['category'] == "official":
#						category = "[公式]"
#						lv_id_list.append(r['live_id'])
#						lv_tbn_list.append(r['thumb'])
#						community_id = r['live_id']
#					elif r['category'] == "ch":
#						category = "[CH]"
#						ch_list.append(r['community_id'])
#						community_id = r['community_id']
#
#					title_name = '%s %s[%s][%s]' % (category,r['title'],dt.strftime('%m/%d %H:%M'),r['live_id'])
#					self.List3_Data_Tuple_List.append((title_name,community_id,r['live_id'],r))
#					self.list3.addItem(title_name)

			sectionArray = self.nicoVideo.getSpLiveData()
			officialArray = sectionArray[0]
			liveArray = sectionArray[2]
			popularArray = sectionArray[3]

			liveArray2,reserveArray,timeshiftArray = self.nicoVideo.getLiveMypageData()

			self.list3.addItem("----------------生放送中の公式番組----------------")
			self.List3_Data_Tuple_List.append(("----------------生放送中の公式番組----------------",None))
			if len(officialArray) == 0:
				self.list3.addItem(NO_TITLE)
				self.List3_Data_Tuple_List.append((NO_TITLE,None))
			else:
				for data in officialArray:
					lv_id_list.append(data['live_id'])
					lv_tbn_list.append(data['thumb'])

					title_name = '%s  (視聴者：%s | コメ：%s | %s)[%s]' % (data['title'],data['view'],data['comment'],data['start_time'],data['live_id'])
					self.List3_Data_Tuple_List.append((title_name,data['live_id'],data['live_id'],data))
					self.list3.addItem(title_name)

			self.list3.addItem("--------生放送中のお気に入りch/コミュニティ--------")
			self.List3_Data_Tuple_List.append(("--------生放送中のお気に入りch/コミュニティ--------",None))

			if len(liveArray) == 0:
				self.list3.addItem(NO_TITLE)
				self.List3_Data_Tuple_List.append((NO_TITLE,None))
			else:
				for data in liveArray:
					title_name = '%s  (視聴者：%s | コメ：%s | %s)[%s]' % (data['title'],data['view'],data['comment'],data['start_time'],data['live_id'])
					self.List3_Data_Tuple_List.append((title_name, data['community_id'], data['live_id'], data))
					self.list3.addItem(title_name)
					if data['community_id'][0:2] == 'co':
						co_list.append(data['community_id'])
					elif data['community_id'][0:2] == 'ch':
						ch_list.append(data['community_id'])

			self.list3.addItem("----------------人気の生放送----------------")
			self.List3_Data_Tuple_List.append(("----------------人気の生放送----------------",None))

			if len(popularArray) == 0:
				self.list3.addItem(NO_TITLE)
				self.List3_Data_Tuple_List.append((NO_TITLE,None))
			else:
				for data in popularArray:
					title_name = '%s  (視聴者：%s | コメ：%s | %s)[%s]' % (data['title'],data['view'],data['comment'],data['start_time'],data['live_id'])
					self.List3_Data_Tuple_List.append((title_name, data['community_id'], data['live_id'], data))
					self.list3.addItem(title_name)
					if data['community_id'][0:2] == 'co':
						co_list.append(data['community_id'])
					elif data['community_id'][0:2] == 'ch':
						ch_list.append(data['community_id'])
					else:
						lv_id_list.append(data['live_id'])
						lv_tbn_list.append(data['thumb'])


			self.list3.addItem("--------お気に入りch/コミュニティの放送予約--------")
			self.List3_Data_Tuple_List.append(("------お気に入りch/コミュニティの放送予約------",None))
			if len(reserveArray) == 0:
				self.list3.addItem(NO_TITLE)
				self.List3_Data_Tuple_List.append((NO_TITLE,None))
			else:
				for data in reserveArray:
					title_name = '[%s] %s [%s]' % (data['start_time'],data['title'],data['guid'])
					self.List3_Data_Tuple_List.append((title_name, data['community_id'], data['guid'], data))
					self.list3.addItem(title_name)
					if data['community_id'][0:2] == 'ch':
						ch_list.append(data['community_id'])
					if data['community_id'][0:2] == 'co':
						co_list.append(data['community_id'])

			self.channelicon_Down(ch_list)
			self.communityicon_Down(co_list)
			self.tbn_lv_Down(lv_id_list, lv_tbn_list)

			self.list3.addItem("---------タイムシフト予約リスト---------")
			self.List3_Data_Tuple_List.append(("---------タイムシフト予約リスト---------",None))
			if len(timeshiftArray) == 0:
				self.list3.addItem("タイムシフト予約はありません")
				self.List3_Data_Tuple_List.append(("タイムシフト予約はありません",""))
			else:
				for data in timeshiftArray:
					title_name = '%s %s [%s]' % (data['time'],data['title'],data['id'])
					self.List3_Data_Tuple_List.append((title_name, data['id'], data['id'], data['token'], data))
					self.list3.addItem(title_name)
			self.addHistoryStock()
			self.Mes_BOX("")

		elif self.List1_Index == 1:
			self.Mes_BOX("取得中...")
			self.list2.addItem(NO_TITLE)
			self.List2_Data_Tuple_List.append((NO_TITLE,None))

			result = self.nicoVideo.getMyCommunity()
			co_list = []
			for data in result:
				title_name = '%s [%s](レベル：%s | メンバー：%s | 投稿動画：%s | %s)' % (data[5],data[4],data[0],data[1],data[2],data[3])
				self.List3_Data_Tuple_List.append((title_name, data[4], data[4], data))
				co_list.append(data[4])
				self.list3.addItem(title_name)
			self.communityicon_Down(co_list)
			self.addHistoryStock()
			self.Mes_BOX("")

		elif self.List1_Index == 2:
			self.list2.addItem("Google Suggest")
			self.List2_Data_Tuple_List.append(("Google Suggest","Google Suggest"))
			for keyword in self.search_keyword:
				self.list2.addItem(keyword)
				self.List2_Data_Tuple_List.append((keyword,keyword))
			self.setFocus(self.list2)

		elif self.List1_Index == 3:
			tagArray = self.nicoVideo.getFavtag()
			for tag in tagArray:
				self.list2.addItem(tag)
				self.List2_Data_Tuple_List.append((tag,tag))
			self.setFocus(self.list2)

		elif self.List1_Index == 4:
			self.liveRankingSearchQ('onair')
		elif self.List1_Index == 5:
			self.liveRankingSearchQ('comingsoon')
		elif self.List1_Index == 6:
			self.liveRankingSearchQ('closed')
		elif self.List1_Index == 7:
			for i in range(len(LIVE_RANKING_NAME_ARRAY)):
				self.list2.addItem(LIVE_RANKING_NAME_ARRAY[i])
				self.List2_Data_Tuple_List.append((LIVE_RANKING_NAME_ARRAY[i],LIVE_RANKING_TYPE_ARRAY[i]))
			self.setFocus(self.list2)

		#公式
		elif self.List1_Index == 8:
			self.list2.addItem(NO_TITLE)
			self.List2_Data_Tuple_List.append((NO_TITLE,None))
			self.List2_Index = 0
			self.timelineLiveSearch(math.floor(time.time()))

#		#全ライブ ver1.7.1停止
#		elif self.List1_Index == 9:
#			self.list2.addItem(NO_TITLE)
#			self.List2_Data_Tuple_List.append((NO_TITLE,None))
#			self.List2_Index = 0
#			if self.live_sort_type < len(LIVE_SORT_ARRAY):
#				self.categoryLiveSearch(None, self.live_sort_type, 1)
#			else:
#				self.activeLiveSearch('', self.live_sort_type, 1)

		else:
			tagArray = self.nicoVideo.getLiveTagRelated(LIVE_TAB_ARRAY[self.List1_Index-9])
			self.list2.addItem("タグ無し")
			self.List2_Data_Tuple_List.append(("タグ無し",''))
			for tagdata in tagArray:
				label = "%s (%s)" % (tagdata[0],tagdata[1])
				self.list2.addItem(label)
				self.List2_Data_Tuple_List.append((label,tagdata[0]))
			self.setFocus(self.list2)

	def inputKeyword(self):
		keyboard = xbmc.Keyboard("", "予測変換するキーワードの入力")
		keyboard.setHiddenInput(False)
		keyboard.doModal()
		if keyboard.isConfirmed():
			keyword = keyboard.getText()
			if keyword != "" :
				self.list2.reset()
				self.List2_Data_Tuple_List = []

				self.List3_Data_Tuple_List = []
				self.list3.reset()
				self.list3.selectItem(0)

				gs = GoogleSuggest()
				resultList = gs.getList(keyword)
				self.list2.addItem("Google Suggest")
				self.List2_Data_Tuple_List.append(("Google Suggest","Google Suggest"))
				for result in resultList:
					suggestion = result['suggestion']
					self.list2.addItem(suggestion)
					self.List2_Data_Tuple_List.append((suggestion,suggestion))

					wordList = suggestion.split(" ")
					if 1 < len(wordList):
						for word in wordList:
							self.list2.addItem(word)
							self.List2_Data_Tuple_List.append((word,word))
				self.addHistoryStock()

	def timelineLiveSearch(self,start):

		self.List3_Data_Tuple_List = []
		self.list3.reset()
		self.list3.selectItem(0)

		self.Mes_BOX("取得中...")
		ch_list = []
		co_list = []
		lv_id_list = []
		lv_tbn_list = []

		for i in range(2):
			end = start + 60*30 # 30分
			resultArray = self.nicoVideo.getTimeline(start,end)
			for result in resultArray:
				dt = datetime.datetime.fromtimestamp(float(result['start']))

				if result['status'] == 'onair':
					status = "[放送中]"
				elif result['status'] == 'closed':
					status = "[終了]"
				elif result['status'] == 'comingsoon':
					status = "[放送前]"
				else:
					status = "[" + result['status'] + "]"

				if result['category'] == "official":
					category = "[公式]"
					community_id = result['live_id']
				elif result['category'] == "ch":
					category = "[CH]"
					community_id = result['community_id']
				elif result['category'] == "co":
					category = "[CO]"
					community_id = result['community_id']
				else:
					category = "[" + result['category'] + "]"
					community_id = result['live_id']

				title_name = '%s%s %s[%s][%s]' % (status,category,result['title'],dt.strftime('%m/%d %H:%M'),result['live_id'])
				self.List3_Data_Tuple_List.append((title_name,community_id,result['live_id'],result))
				self.list3.addItem(title_name)
				if result['community_id'].startswith('ch'):
					ch_list.append(result['community_id'])
				elif result['community_id'].startswith('co'):
					co_list.append(result['community_id'])
				else:
					if result['thumb']:
						lv_id_list.append(result['live_id'])
						lv_tbn_list.append(result['thumb'])
				start = end

		self.Mes_BOX("")

#		self.List3_Data_Tuple_List.append((" >> 次のタイムラインを取得",'',end,''))
#		self.list3.addItem(" >> 次のタイムラインを取得")
#		self.List3_Data_Tuple_List.append((" << 前のタイムラインを取得",'',start - 60*30 * 2,''))
#		self.list3.addItem(" << 前のタイムラインを取得")

		self.channelicon_Down(ch_list)
		self.communityicon_Down(co_list)
		self.tbn_lv_Down(lv_id_list, lv_tbn_list)
		self.addHistoryStock()

	def keywordLiveSearch(self, tags_keyword, live_sort_type_index, page, time_shift):
		# 1.7.0b12 一時停止
#		select_dialog = xbmcgui.Dialog().select("検索種類",["キーワード","タグ"])
#		if select_dialog == 0:
#			self.live_search_kind = "content"
#		elif select_dialog == 1:
#			self.live_search_kind = "tag"
#		else:
#			return None

		self.List3_Data_Tuple_List = []
		self.list3.reset()
		self.list3.selectItem(0)

		if time_shift:
			search_mode='closed'
		else:
			search_mode='onair'

		sort = LIVE_SORT_ARRAY[live_sort_type_index]
		keyword = tags_keyword
		tags = tags_keyword

		self.Mes_BOX("取得中...")
		if self.__dbg__: print "getLiveSearch: %s,%s,%s,%s,%s,%s" % (keyword,sort,search_mode,self.live_search_kind,tags,page)
		hit,resultArray = self.nicoVideo.getLiveSearch(keyword,sort,search_mode,self.live_search_kind,tags,page)

		ch_list = []
		co_list = []
		if len(resultArray) == 0:
			self.List3_Data_Tuple_List.append(("何も取得できませんでした",""))
			self.list3.addItem("何も取得できませんでした")
		else:
			for result in resultArray:
				title = '%s (来場者数：%s | コメ：%s | 予約数:%s | %s)[%s]' % (result['title'],result['view'],result['num_res'],result['num_timeShift'],result['date'],result['live_id'])
#				if time_shift:
#					title = '%s (来場者数：%s | コメ：%s | %s)[%s]' % (result['title'],result['view'],result['num_res'],result['date'],result['live_id'])
#				else:
#					title = '%s (来場者数：%s | コメ：%s | %s %s)[%s]' % (result['title'],result['view'],result['num_res'],result['date'],result['over_time'],result['live_id'])

				community_id = result['community_id']
				self.List3_Data_Tuple_List.append((title,community_id,result['live_id'],result))
				self.list3.addItem(title)

				if community_id.startswith('ch'):
					ch_list.append(community_id)
				elif community_id.startswith('co'):
					co_list.append(community_id)
			self.channelicon_Down(ch_list)
			self.communityicon_Down(co_list)

			if len(resultArray) < hit:
				self.List3_Data_Tuple_List.append((' >> 次のページへ','',int(page+1),''))
				self.list3.addItem(' >> 次のページへ')
				if 1 < page:
					self.List3_Data_Tuple_List.append((' << 前のページへ','',int(page-1),''))
					self.list3.addItem(' << 前のページへ')

		if time_shift:
			self.Mes_BOX('過去の放送　%s　%s HIT!! %sページ' % (tags_keyword,hit,page))
		else:
			self.Mes_BOX('放送中の番組　%s　 %s HIT!! %sページ ' % (tags_keyword,hit,page))
		self.addHistoryStock()

	def activeLiveSearch(self, search, live_sort_type_index, page):
		if self.__dbg__: print "activeLiveSearch: %s,%s,%s" % (search, live_sort_type_index, page)
		self.Mes_BOX("取得中...")

		self.List3_Data_Tuple_List = []
		self.list3.reset()
		self.list3.selectItem(0)

		ch_list = []
		co_list = []
		category = ''
#		category_index = self.List1_Index - 5
#		if 5 < category_index and not search:
#			category = LIVE_TAB_ARRAY[category_index]
#		else:
#			category = ''
		chikuran = Chikuwachan.ChikuwachanRanking()

#		if self.List1_Index == 2:
#			tag = ''
#			search = tag_search
#		else:
#			tag = tag_search
#			search = ''
		tag = ''
		try:
			if live_sort_type_index < 15:
				sort_index = live_sort_type_index - 10
				resultArray = chikuran.getAllRanking(page, tag, category, search, Chikuwachan.CHIKURAN_SORT_ARRAY[sort_index])
			else:
				sort_index = live_sort_type_index - 15
				resultArray = chikuran.getRookieRanking(page, tag, category, search, Chikuwachan.CHIKURAN_SORT_ARRAY[sort_index])
		except:
			self.Mes_BOX("ちくわちゃんランキングの取得中に失敗しました")
			return None

#		if resultArray == None:
#			self.Mes_BOX("ちくわちゃんランキングの取得に失敗しました")
#			return None

		for result in resultArray:
			title = '第%s位：%s (%s：%s | %s：%s | %s：%s | %s)[%s]' % (result['rate'],result['title'],Chikuwachan.VALUE1_TYPE_NAME_ARRAY[sort_index],result['value1'],Chikuwachan.VALUE2_TYPE_NAME_ARRAY[sort_index],result['value2'],Chikuwachan.VALUE3_TYPE_NAME_ARRAY[sort_index],result['value3'],result['date'],result['community'])

			community_id = result['community']
			self.List3_Data_Tuple_List.append((title,community_id,result['live_id'],result))
			self.list3.addItem(title)

			if community_id.startswith('ch'):
				ch_list.append(community_id)
			elif community_id.startswith('co'):
				co_list.append(community_id)

		if 100 <= len(resultArray):
			self.List3_Data_Tuple_List.append((' >> 次のページへ','',(page+1),''))
			self.list3.addItem(' >> 次のページへ')

		if 1 < page:
			self.List3_Data_Tuple_List.append((' << 前のページへ','',(page-1),''))
			self.list3.addItem(' << 前のページへ')

		self.channelicon_Down(ch_list)
		self.communityicon_Down(co_list)

		if live_sort_type_index < 15:
			self.Mes_BOX('%s ランキング %s %s page' % (Chikuwachan.CHIKURAN_SORT_NAME_ARRAY[sort_index],search,page))
		else:
			self.Mes_BOX('%s ランキング(ルーキー) %s %s page' % (Chikuwachan.CHIKURAN_SORT_NAME_ARRAY[sort_index],search,page))

		self.addHistoryStock()
	def categoryLiveSearch(self, tags_keyword, live_sort_type_index, page):
		if self.__dbg__: print "categoryLiveSearch: %s,%s,%s" % (tags_keyword, live_sort_type_index, page)
		self.Mes_BOX("取得中...")

		self.List3_Data_Tuple_List = []
		self.list3.reset()
		self.list3.selectItem(0)

		lv_id_list = []
		lv_tbn_list = []
		ch_list = []
		co_list = []
		tab = LIVE_TAB_ARRAY[self.List1_Index-9]
		sort = LIVE_SORT_ARRAY_RSS[live_sort_type_index]
		order = LIVE_ORDER_ARRAY_RSS[live_sort_type_index]
		if self.List2_Index == 0 and not tags_keyword:
			#タブを指定した条件検索
			resultArray = self.nicoVideo.getLiveRecent(tab,sort,order,page)
			for result in resultArray:
				live_id = result['guid']
				community_id = result['community_id']
				if result['member_only'] == 'true':
					title_name = '[メンバー限定] %s (視聴者：%s | コメ：%s | カテ：%s)[%s][%s]' % (result['title'],result['view'],result['num_res'],result['category'],result['guid'],result['community_id'])
				else:
					title_name = '%s (視聴者：%s | コメ：%s | カテ：%s)[%s][%s]' % (result['title'],result['view'],result['num_res'],result['category'],result['guid'],result['community_id'])

				self.List3_Data_Tuple_List.append((title_name,community_id,live_id,result))
				self.list3.addItem(title_name)

				if community_id.startswith('ch'):
					ch_list.append(community_id)
				elif community_id.startswith('co'):
					co_list.append(community_id)

			self.List3_Data_Tuple_List.append((' >> 次のページへ','',int(page+1),''))
			self.list3.addItem(' >> 次のページへ')
			if 1 < page:
				self.List3_Data_Tuple_List.append((' << 前のページへ','',int(page-1),''))
				self.list3.addItem(' << 前のページへ')
		else:
			#生放送全体とタグを指定した条件検索
			if self.__dbg__: print "getRealTimeRecentOnairStreams: %s,%s,%s,%s,%s" % (tab,sort,order,page,tags_keyword)
			resultArray = self.nicoVideo.getRealTimeRecentOnairStreams(tab,sort,order,page,tags_keyword)
			for result in resultArray:
				live_id = result['live_id']
				community_id = result['community_id']

				title = '%s (%s | 視聴者：%s | コメ：%s)[%s][%s]' % (result['title'],result['time'],result['view'],result['comment'],result['live_id'],result['community_id'])

				self.List3_Data_Tuple_List.append((title,community_id,live_id,result))
				self.list3.addItem(title)

				if community_id.startswith('ch'):
					ch_list.append(community_id)
				elif community_id.startswith('co'):
					co_list.append(community_id)
				else:
					lv_id_list.append(live_id)
					lv_tbn_list.append(result['thumbnail'])

#			sort = LIVE_TAGS_SORT_ARRAY[int(math.floor(live_sort_type_index/2))]
#
#			resultArray = self.nicoVideo.getLiveRecent2onairstreams(tab,sort,page,tags_keyword)
#			for result in resultArray:
#				community_id = result['community_id']
#				title = '%s (%s | 視聴者：%s | コメ：%s)[%s]' % (result['title'],result['over_time'],result['view'],result['num_res'],community_id)
#
#				self.List3_Data_Tuple_List.append((title,community_id,community_id,result))
#				self.list3.addItem(title)
#
#				if community_id.startswith('ch'):
#					ch_list.append(community_id)
#				elif community_id.startswith('co'):
#					co_list.append(community_id)

			self.List3_Data_Tuple_List.append((' >> 次のページへ','',(page+1),''))
			self.list3.addItem(' >> 次のページへ')
			if 1 < page:
				self.List3_Data_Tuple_List.append((' << 前のページへ','',(page-1),''))
				self.list3.addItem(' << 前のページへ')


		self.tbn_lv_Down(lv_id_list, lv_tbn_list)
		self.channelicon_Down(ch_list)
		self.communityicon_Down(co_list)

		if tags_keyword == "":
			tags_keyword = "タグ無し"
		self.Mes_BOX('現在放送中　%s, %s, %sページ' % ( LIVE_TAB_NAME_ARRAY[self.List1_Index-9],tags_keyword,page))
		self.addHistoryStock()

	def liveRankingSearchQ(self, type):
		'''ニコニコ生放送:Q のランキング'''

		self.Mes_BOX("取得中...")

#		self.List2_Data_Tuple_List = []
#		self.list2.reset()
#		self.list2.selectItem(0)
#
#		self.List3_Data_Tuple_List = []
#		self.list3.reset()
#		self.list3.selectItem(0)

		self.list2.addItem(NO_TITLE)
		self.List2_Data_Tuple_List.append((NO_TITLE,None))

		ch_list = []
		co_list = []
		lv_id_list = []
		lv_tbn_list = []

		resultArray,resultArray_official,resultArray_ch = self.nicoVideo.apiGetActiveRanking(type)

		if resultArray_official:
			if len(resultArray_official) == 0:
				self.list3.addItem("公式番組がありません")
				self.List3_Data_Tuple_List.append(("公式番組がありません",""))
			else:
				for result in resultArray_official:
					title = '[公式] 第%s位%s %s (%s | 視聴者：%s | コメ：%s)[%s]' % (result['rank'],result['rank_state'],result['title'],result['time'],result['view'],result['comment'],result['live_id'])
					self.List3_Data_Tuple_List.append((title,result['live_id'],result['live_id'],result))
					self.list3.addItem(title)
					lv_id_list.append(result['live_id'])
					lv_tbn_list.append(result['thumbnail'])

			self.list3.addItem(NO_TITLE)
			self.List3_Data_Tuple_List.append((NO_TITLE,None))

		if resultArray_ch:
			if len(resultArray_ch) == 0:
				self.list3.addItem("CH番組がありません")
				self.List3_Data_Tuple_List.append(("CH番組がありません",""))
			else:
				for result in resultArray_ch:
					title = '[CH] 第%s位%s %s (%s | 視聴者：%s | コメ：%s)[%s]' % (result['rank'],result['rank_state'],result['title'],result['time'],result['view'],result['comment'],result['live_id'])
					self.List3_Data_Tuple_List.append((title,result['live_id'],result['live_id'],result))
					self.list3.addItem(title)
					lv_id_list.append(result['live_id'])
					lv_tbn_list.append(result['thumbnail'])

			self.list3.addItem(NO_TITLE)
			self.List3_Data_Tuple_List.append((NO_TITLE,None))

		for i,result in enumerate(resultArray):
			community_id = result['community_id']

			if community_id.startswith('ch'):
				ch_list.append(community_id)
			elif community_id.startswith('co'):
				co_list.append(community_id)
			else:
				lv_id_list.append(community_id)
				lv_tbn_list.append(result['thumbnail'])

			if type == "onair":
				title = '第%s位%s %s (%s | %s | 視聴者：%s | コメ：%s | タグ：%s)[%s][%s]' % (result['rank'],result['rank_state'],result['title'],result['score'],result['time'],result['view'],result['comment'],result['tips'],"lv" + result['video_id'],result['community_id'])
			elif type == "comingsoon":
				title = '第%s位 %s (%s | 予約数：%s | タグ：%s)[%s][%s]' % (result['rank'],result['title'],result['time'],result['score'],result['tips'],"lv" + result['video_id'],result['community_id'])
			elif type == "closed":
				title = '第%s位%s %s (%s | %s | 視聴者：%s | コメ：%s | タグ：%s)[%s][%s]' % (result['rank'],result['rank_state'],result['title'],result['score'],result['time'],result['view'],result['comment'],result['tips'],"lv" + result['video_id'],result['community_id'])

			self.List3_Data_Tuple_List.append((title,community_id, 'lv' + result['video_id'],result))
			self.list3.addItem(title)

		self.channelicon_Down(ch_list)
		self.communityicon_Down(co_list)
		self.tbn_lv_Down(lv_id_list, lv_tbn_list)
		self.addHistoryStock()
		self.Mes_BOX("")

	def liveRankingSearch(self, type):
		'''ニコニコ生放送 旧ランキング'''

		self.Mes_BOX("取得中...")
		self.List3_Data_Tuple_List = []
		self.list3.reset()
		self.list3.selectItem(0)

		ch_list = []
		co_list = []
		lv_id_list = []
		lv_tbn_list = []

		resultArray = self.nicoVideo.getLiveRanking(type)
		for i,result in enumerate(resultArray):
			provider_type = result['provider_type']
			if provider_type == "official":
				provider_name = "公式"
			elif provider_type == "community":
				provider_name = "CO"
			elif provider_type == "channel":
				provider_name = "CH"
			else:
				provider_name = "不明"

			default_community = result['default_community']
			if default_community and provider_type != "official":
				if default_community.startswith('ch'):
					ch_list.append(default_community)
				elif default_community.startswith('co'):
					co_list.append(default_community)
			else:
				default_community = 'lv' + result['id']
				lv_id_list.append(default_community)
				lv_tbn_list.append(result['thumbnail_url'])

			title_name = '第%s位：[%s] %s (%s pt)[%s]' % (i+1, provider_name, result['title'], result['ranking_pt'], default_community)
			self.List3_Data_Tuple_List.append((title_name,default_community,'lv' + result['id'],result))
			self.list3.addItem(title_name)

		if type == "onair":
			self.Mes_BOX('放送中番組ランキング -現在生放送中の番組ランキング-')
		elif type == "comingsoon":
			self.Mes_BOX('放送予定番組ランキング -注目の番組ランキング-')
		elif type == "closed":
			self.Mes_BOX('過去番組ランキング -過去に人気のあった番組ランキング-')

		self.channelicon_Down(ch_list)
		self.communityicon_Down(co_list)
		self.tbn_lv_Down(lv_id_list, lv_tbn_list)
		self.addHistoryStock()

	def on_Live_list2(self, keyword, live_sort_type_index, page, time_shift):
		'''ニコ生 リスト2の選択処理'''

		if self.List1_Index == 2 or self.List1_Index == 3 or time_shift:
			if self.live_sort_type_select:
				if live_sort_type_index == None:
					select = xbmcgui.Dialog().select("ソートタイプの選択",LIVE_SORT_NAME_ARRAY)
					if 0<=select:
						live_sort_type_index = select
						self.live_sort_type = select
						self.Update_List.selectItem(select)
					else:
						return None
				else:
					self.live_sort_type = live_sort_type_index
					self.Update_List.selectItem(live_sort_type_index)
			if self.live_sort_type < len(LIVE_SORT_ARRAY):
				if keyword == None:
					keyword = self.List2_Data_Tuple_List[self.List2_Index][1]
				self.keywordLiveSearch(keyword, live_sort_type_index, page, time_shift)
			else:
				if keyword == None:
					if self.List2_Index == 0:
						keyword = ""
					else:
						keyword = self.List2_Data_Tuple_List[self.List2_Index][0]
						m = re.compile('(.*) \(.*\)').search(keyword)
						if m: keyword = m.group(1)
				self.activeLiveSearch(keyword, live_sort_type_index, page)
		else:
			if 8 < self.List1_Index:
				if keyword == None:
					if self.live_sort_type_select:
						select = xbmcgui.Dialog().select("ソートタイプの選択",LIVE_SORT_NAME_ARRAY_RSS)
						if 0<=select:
							live_sort_type_index = select
							self.live_sort_type = select
							self.Update_List.selectItem(select)
						else:
							return None

				else:
					if self.live_sort_type_select:
						select = xbmcgui.Dialog().select("ソートタイプの選択",LIVE_SORT_NAME_ARRAY)
						if 0<=select:
							live_sort_type_index = select
							self.live_sort_type = select
							self.Update_List.selectItem(select)
						else:
							return None

			if self.live_sort_type < len(LIVE_SORT_ARRAY):
				if keyword == None:
					keyword = self.List2_Data_Tuple_List[self.List2_Index][1]
				self.categoryLiveSearch(keyword, live_sort_type_index, page)
			else:
				if keyword == None:
					if self.List2_Index == 0:
						keyword = ""
					else:
						keyword = self.List2_Data_Tuple_List[self.List2_Index][0]
						m = re.compile('(.*) \(.*\)').search(keyword)
						if m: keyword = m.group(1)
				self.activeLiveSearch(keyword, live_sort_type_index, page)

	def on_Live_list3(self):
		'''ニコ生 リスト3の選択処理'''
		if len(self.List3_Data_Tuple_List[self.List3_Index]) < 2:
			return None

		community_id = self.List3_Data_Tuple_List[self.List3_Index][1]
		if not community_id and 2 < len(self.List3_Data_Tuple_List[self.List3_Index]):
			title = self.List3_Data_Tuple_List[self.List3_Index][0]
			if self.List1_Index == 7:
				if title == " >> 次のタイムラインを取得" or title == " << 前のタイムラインを取得":
					self.timelineLiveSearch(self.List3_Data_Tuple_List[self.List3_Index][2])
					return None
			else:
				if title == " >> 次のページへ" or title == " << 前のページへ":
					page = self.List3_Data_Tuple_List[self.List3_Index][2]
					# ver1.7.1停止
#					if self.List1_Index == 9:
#						if self.live_sort_type < len(LIVE_SORT_ARRAY):
#							self.categoryLiveSearch(None, self.live_sort_type, page)
#						else:
#							self.activeLiveSearch('', self.live_sort_type, page)
#					else:
					if self.List1_Index == 2 or self.List1_Index == 3 or self.time_shift:
						keyword = self.List2_Data_Tuple_List[self.List1_Index][0]
						self.keywordLiveSearch(keyword, self.live_sort_type, page, self.time_shift)
					else:
						if self.live_sort_type < len(LIVE_SORT_ARRAY):
							keyword = self.List2_Data_Tuple_List[self.List2_Index][1]
							self.categoryLiveSearch(keyword, self.live_sort_type, page)
						else:
							if self.List2_Index == 0:
								keyword = ""
							else:
								keyword = self.List2_Data_Tuple_List[self.List2_Index][0]
								m = re.compile('(.*) \(.*\)').search(keyword)
								if m: keyword = m.group(1)
							self.activeLiveSearch(keyword, self.live_sort_type, page)
					return None

		title = self.List3_Data_Tuple_List[self.List3_Index][0]
		video_id = self.List3_Data_Tuple_List[self.List3_Index][2]
		self.startVideoPlayer(video_id,title,streaming=self.isStreaming)

	def on_Other(self):
		'''その他選択処理'''

		self.Work_Group_ID = OTHER_WORK_ID
		self.List1_Data_Tuple_List = []
		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list1.reset()
		self.list2.reset()
		self.list3.reset()
		self.list1.selectItem(0)
		self.list2.selectItem(0)
		self.list3.selectItem(0)

		for m in OTHER_LIST_NAME_ARRAY:
			self.list1.addItem(m)
			self.List1_Data_Tuple_List.append((m,""))

		self.setFocus(self.list1)

	def on_History_list1(self):
		'''視聴履歴 リスト１の選択処理'''

		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		historyFileList = []
		self.list2.reset()
		self.list3.reset()
		self.list2.selectItem(0)
		self.list3.selectItem(0)

		# 視聴履歴フォルダの履歴ファイルをList化及びList2表示用に整形
		for historyfile in os.listdir(hisDatDir):
			historyFileList.append(historyfile)

		historyFileList.sort()
		historyFileList.reverse()

		# 整形済データをList2に表示
		for historyFile in historyFileList:
			file_path = os.path.join(hisDatDir,historyFile)
			dateStr = historyFile[-12:-10] + "/" + historyFile[-9:-7] + "/" + historyFile[-6:-4]
			self.list2.addItem(dateStr)
			self.List2_Data_Tuple_List.append((dateStr,file_path))

		if len(self.List2_Data_Tuple_List) == 0:
			self.Mes_BOX("履歴が見つかりませんでした")
		else:
			self.setFocus(self.list2)


	def on_TwitterSearch_list1(self):
		'''その他 twitter検索 リスト１の選択処理'''

		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list2.reset()
		self.list3.reset()

		self.list2.addItem("新着のつぶやき")
		self.List2_Data_Tuple_List.append(("新着のつぶやき",""))

		for keyword in self.search_keyword:
			self.list2.addItem(keyword)
			self.List2_Data_Tuple_List.append((keyword,keyword))

		self.list2.selectItem(0)
		self.setFocus(self.list2)

	def on_NicoSound_list1(self):
		'''その他 にこ★さうんど リスト１の選択処理'''

		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.list2.reset()
		self.list3.reset()

		for i in range(len(NICO_SOUND_CHOOSE_ARRAY)):
			self.list2.addItem(NICO_SOUND_CHOOSE_ARRAY[i])
			self.List2_Data_Tuple_List.append((NICO_SOUND_CHOOSE_ARRAY[i],""))

		self.list2.selectItem(0)
		self.setFocus(self.list2)

	def on_MylistRanking_list1(self):
		'''その他 ニコニコファーム マイリストランキング リスト１の選択処理'''

		select_dialog = xbmcgui.Dialog().select("ニコニコファームのカテゴリ選択",NICO_MLR_CHOOSE_ARRAY)
		if select_dialog < 0:
			return None

		self.NICO_MLR_CATE = int(select_dialog)

		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		self.Mes_BOX("取得中...")
		self.list2.reset()
		self.list3.reset()

		P_Num = self.Page_Num_List.getSelectedPosition()
		nf = NiconicoFarm()
		mylist_num_list,regist_sm_num,tce_list,num_average_list,num_total_list,num_rate_list = nf.getAverageMylist(NICO_MLR_CHOOSE_CATE_ARRAY[self.NICO_MLR_CATE],P_Num)
		for i in range(len(mylist_num_list)):
			Plus_RANK = "#" + str((P_Num*50) + i + 1) + "  "
			title_name = '%s%s(%s) (カテゴリ：%s | 編集者：%s | 平均再生：%s | 平均コメ：%s | 平均マイ：%s)' % (Plus_RANK, regist_sm_num[i], tce_list[i][0], tce_list[i][1], tce_list[i][2], num_average_list[i][0], num_average_list[i][1], num_average_list[i][2])
			self.list2.addItem(title_name)
			self.List2_Data_Tuple_List.append((title_name,"mylist/"+mylist_num_list[i]))

		self.list2.selectItem(0)
		self.setFocus(self.list2)
		self.Mes_BOX(self.List2_Data_Tuple_List[0][0])
#
#	def Save_directory_list1(self):
#		'''その他 保存フォルダ の選択処理'''
#
#		self.List2_Data_Tuple_List = []
#		self.List3_Data_Tuple_List = []
#
#		dirList = []
#		self.list2.reset()
#		self.list3.reset()
#
#		self.setFocus(self.list2)
#
#		self.list2.addItem("(一時ファイル)")
#		self.List2_Data_Tuple_List.append(("(一時ファイル)",cache_dir))
#
#		if self.Cache_directory != '':
#			files = os.listdir(self.Cache_directory)
#			for f in files:
#				if os.path.isdir(f):
#					dirList.append(f)
#
#			dirList.sort()
#			dirList.reverse()
#
#			for dirName in dirList:
#				self.list2.addItem(dirName)
#				self.List2_Data_Tuple_List.append((dirName,os.path.join(self.Cache_directory,dirName)))
#			self.list2.selectItem(0)
#
#	def on_Other_list1(self):
#		'''その他 リスト１の選択処理'''
#
#		if self.List1_Index == 0:
#			self.Save_directory_list1()
#		elif self.List1_Index == 1:
#			self.on_History_list1()
#		elif self.List1_Index == 2:
#			keyboard = xbmc.Keyboard(self.input_video_id, "動画IDの入力")
#			keyboard.setHiddenInput(False)
#			keyboard.doModal()
#
#			if keyboard.isConfirmed():
#				self.input_video_id = keyboard.getText()
#				if self.input_video_id != "" :
#					select_dialog = xbmcgui.Dialog().select("選択",["この動画を再生","詳細情報の取得"])
#					if select_dialog == 0:
#						self.startVideoPlayer(self.input_video_id,"入力した動画ID:"+self.input_video_id,streaming = self.isStreaming)
#					elif select_dialog == 1:
#						self.show_Detail(self.input_video_id)
#		elif self.List1_Index == 3:
#			self.on_NicoSound_list1()
#		elif self.List1_Index == 4:
#			self.on_MylistRanking_list1()
#		elif self.List1_Index == 5:
#			self.List2_Data_Tuple_List = []
#			self.List3_Data_Tuple_List = []
#			self.Mes_BOX("取得中...")
#			self.list2.reset()
#			self.list3.reset()
#			for user_id in self.tweet_user_id_list:
#				self.list2.addItem(user_id)
#				self.List2_Data_Tuple_List.append((user_id,user_id))
#			self.twittericon_Down(self.tweet_user_id_list)
#			self.setTwitterIconImage(self.tweet_user_id_list[0])
#
#			self.list2.selectItem(0)
#			self.setFocus(self.list2)
#			self.Mes_BOX("")
#		elif self.List1_Index == 6:
#			self.on_TwitterSearch_list1()
#
#	def on_Other_list2(self):
#		'''その他 リスト２の選択処理'''
#
#		if self.List1_Index == 2:
#			return None
#
#		if self.List1_Index == 4:
#			print ""
#			selectMYlist = self.List2_Data_Tuple_List[self.List2_Index][1]
#			self.on_Ranking_list2(mylist_href = "%s" %selectMYlist)
#			return None
#
#		self.list3.reset()
#		self.list3.selectItem(0)
#		self.List3_Data_Tuple_List = []
#
#		if self.List1_Index == 0:
#			# 保存フォルダ
#			save_dir = self.List2_Data_Tuple_List[self.List2_Index][1]
#			self.Mes_BOX(u"保存フォルダ: %s" % (save_dir))
#			files = os.listdir(save_dir)
#			fileDataArray = []
#
#			for f in files:
#				m = re.compile('(.*)\[ThumbInfo\].xml').search(f)
#				m2 = re.compile('(.*)\[(.*)\]\[ThumbInfo\].xml').search(f)
##				if s[1] == 'tbn':
#				if m:
#					video_id = None
#					video_title = m.group(1)
#					cache_file_chk = None
#					low_cache_file_chk = None
#					if m2:
#						video_id = m2.group(2)
#					else:
#						video_id = video_title
#
#					baseFileName = os.path.join(save_dir,video_title)
#					if os.path.exists( baseFileName + '.flv'):
#						cache_file_chk = baseFileName + '.flv'
#					elif os.path.exists( baseFileName + '.mp4'):
#						cache_file_chk = baseFileName + '.mp4'
#					elif os.path.exists( baseFileName + '.swf'):
#						cache_file_chk = baseFileName + '.swf'
#
#					if os.path.exists(baseFileName + '[low].flv'):
#						low_cache_file_chk = baseFileName + '[low].flv'
#					elif os.path.exists(baseFileName + '[low].mp4'):
#						low_cache_file_chk = baseFileName + '[low].mp4'
#					elif os.path.exists(baseFileName + '[low].swf'):
#						low_cache_file_chk = baseFileName + '[low].swf'
##
#					if cache_file_chk == None and low_cache_file_chk == None:
#						continue
#					if cache_file_chk != None and low_cache_file_chk != None:
#						cache_file_type = "(両) "
#					elif low_cache_file_chk == None:
#						cache_file_type = ""
#					else:
#						cache_file_type = "(エ) "
#					name = None
#
#					xml = os.path.join(save_dir,f)
#					if os.path.exists(xml):
#						dataFile = open(xml, 'r')
#						try:
#							thumbinfoXml = dataFile.read()
#						finally:
#							dataFile.close()
#						title_m = re.compile('<title>(.*)</title>').search(thumbinfoXml)
#						if title_m:
#							title = title_m.group(1)
#							name = cache_file_type + title
#
#					if not name:
#						name = cache_file_type + video_title
#					tbn_file = baseFileName + '.tbn'
##					cache_file_chk = cache_file_chk.decode("shift-jis");
##					tbn_file = tbn_file.decode("shift-jis");
#					fileDataArray.append([name,video_id,cache_file_chk,tbn_file ])
#
#			fileDataArray.sort()
#			for fileData in fileDataArray:
#				self.list3.addItem( fileData[0] )
#				self.List3_Data_Tuple_List.append((fileData[0],fileData[1],fileData[2],fileData[3]))
#
#		elif self.List1_Index == 1:
#			# 視聴履歴
#			data = self.List2_Data_Tuple_List[self.List2_Index]
#			name_id_ptn = re.compile(r"'(.*?)','(.*?)'")
#			dayfile = open(data[1], 'r').read()
#			for m in name_id_ptn.finditer(dayfile):
#				video_id = m.group(1)
#				title_name = m.group(2)
#				self.list3.addItem(title_name)
#				self.List3_Data_Tuple_List.append((title_name,video_id))
#
#		elif self.List1_Index == 3:
#			# にこ☆さうんど
#			self.Mes_BOX("取得中...")
#
#			ns = NicoSound()
#			P_Num = self.Page_Num_List.getSelectedPosition()
#			page = None
#			if self.List2_Index < 5:
#				page = P_Num + 1
#			Plus_RANK = ''
#			stb_value_list,video_id_list,title_list = ns.getNicoSound(NICO_SOUND_CHOOSE_CATE_ARRAY[self.List2_Index],page)
#			for i in range(len(video_id_list)):
#				if self.List2_Index < 5 :
#					Plus_RANK = "#" + str((P_Num*20) + i + 1) + "  "
#				video_id = video_id_list[i]
#				title_name = '%s%s%s  (♪ %s | 時間：%s | %s kbps) [%s]' % (Plus_RANK,getTitlePrefix(video_id),title_list[i],stb_value_list[i][1],stb_value_list[i][0],stb_value_list[i][2],video_id_list[i])
#				self.List3_Data_Tuple_List.append((title_name,video_id))
#				if self.view_watched:
#					title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
#				self.list3.addItem(title_name)
#			self.tbn_Down(video_id_list)
#			self.Mes_BOX("にこ★さうんど＃" + NICO_SOUND_CHOOSE_ARRAY[self.List2_Index])
#
#		elif self.List1_Index == 5:
#			user_id = self.List2_Data_Tuple_List[self.List2_Index][1]
#			self.on_Twitter_list2(user_id)
#		elif self.List1_Index == 6:
#			keyword = self.List2_Data_Tuple_List[self.List2_Index][1]
#			self.on_TwitterSearch_list2(None, keyword, 1)
#			return ''
##		self.setFocus(self.list3)
#		self.addHistoryStock()


	def Save_directory_list1(self):
		'''その他 保存フォルダ の選択処理'''

		self.List2_Data_Tuple_List = []
		self.List3_Data_Tuple_List = []

		dirList = []
		self.list2.reset()
		self.list3.reset()

		self.setFocus(self.list2)

		self.list2.addItem("(一時ファイル)")
		self.List2_Data_Tuple_List.append(("(一時ファイル)",os.path.join(base_cache_path,u'cache')))

		if self.Cache_directory != '':
			files = os.listdir(os.path.join(self.Cache_directory,u''))
			for f in files:
				if os.path.isdir(os.path.join(self.Cache_directory,f)):
					dirList.append(f)

			dirList.sort()
			dirList.reverse()

			for dirName in dirList:
				self.list2.addItem(dirName)
				self.List2_Data_Tuple_List.append((dirName,os.path.join(self.Cache_directory,dirName)))
			self.list2.selectItem(0)

	def on_Other_list1(self):
		'''その他 リスト１の選択処理'''

		if self.List1_Index == 0:
			self.Save_directory_list1()
		elif self.List1_Index == 1:
			self.on_History_list1()
		elif self.List1_Index == 2:
			keyboard = xbmc.Keyboard(self.input_video_id, "動画IDの入力")
			keyboard.setHiddenInput(False)
			keyboard.doModal()

			if keyboard.isConfirmed():
				self.input_video_id = keyboard.getText()
				if self.input_video_id != "" :
					select_dialog = xbmcgui.Dialog().select("選択",["この動画を再生","詳細情報の取得"])
					if select_dialog == 0:
						self.startVideoPlayer(self.input_video_id,"入力した動画ID:"+self.input_video_id,streaming = self.isStreaming)
					elif select_dialog == 1:
						self.show_Detail(self.input_video_id)
		elif self.List1_Index == 3:
			self.on_NicoSound_list1()
		elif self.List1_Index == 4:
			self.on_MylistRanking_list1()
		elif self.List1_Index == 5:
			self.List2_Data_Tuple_List = []
			self.List3_Data_Tuple_List = []
			self.Mes_BOX("取得中...")
			self.list2.reset()
			self.list3.reset()
			for user_id in self.tweet_user_id_list:
				self.list2.addItem(user_id)
				self.List2_Data_Tuple_List.append((user_id,user_id))
			self.twittericon_Down(self.tweet_user_id_list)
			self.setTwitterIconImage(self.tweet_user_id_list[0])

			self.list2.selectItem(0)
			self.setFocus(self.list2)
			self.Mes_BOX("")
		elif self.List1_Index == 6:
			self.on_TwitterSearch_list1()

	def on_Other_list2(self):
		'''その他 リスト２の選択処理'''

		if self.List1_Index == 2:
			return None

		if self.List1_Index == 4:
			print ""
			selectMYlist = self.List2_Data_Tuple_List[self.List2_Index][1]
			self.on_Ranking_list2(mylist_href = "%s" %selectMYlist)
			return None

		self.list3.reset()
		self.list3.selectItem(0)
		self.List3_Data_Tuple_List = []

		if self.List1_Index == 0:
			# 保存フォルダ
			save_dir = self.List2_Data_Tuple_List[self.List2_Index][1]
			self.Mes_BOX(u"保存フォルダ: %s" % (save_dir))
			files = os.listdir(save_dir)
			fileDataArray = []

			for f in files:
				m = re.compile('(.*)\[ThumbInfo\].xml').search(f)
				m2 = re.compile('(.*)\[(.*)\]\[ThumbInfo\].xml').search(f)
#				if s[1] == 'tbn':
				if m:
					video_id = None
					video_title = m.group(1)
					cache_file_chk = None
					low_cache_file_chk = None
					if m2:
						video_id = m2.group(2)
					else:
						video_id = video_title

					baseFileName = os.path.join(save_dir,video_title)
					if os.path.exists( baseFileName + u'.flv'):
						cache_file_chk = baseFileName + u'.flv'
					elif os.path.exists( baseFileName + u'.mp4'):
						cache_file_chk = baseFileName + u'.mp4'
					elif os.path.exists( baseFileName + u'.swf'):
						cache_file_chk = baseFileName + u'.swf'

					if os.path.exists(baseFileName + u'[low].flv'):
						low_cache_file_chk = baseFileName + u'[low].flv'
					elif os.path.exists(baseFileName + u'[low].mp4'):
						low_cache_file_chk = baseFileName + u'[low].mp4'
					elif os.path.exists(baseFileName + u'[low].swf'):
						low_cache_file_chk = baseFileName + u'[low].swf'
#
					if cache_file_chk == None and low_cache_file_chk == None:
						continue
					if cache_file_chk != None and low_cache_file_chk != None:
						cache_file_type = "(両) "
					elif low_cache_file_chk == None:
						cache_file_type = ""
					else:
						cache_file_type = "(エ) "
					name = None

					xml = os.path.join(save_dir,f)
					if os.path.exists(xml):
						dataFile = open(xml, 'r')
						try:
							thumbinfoXml = dataFile.read()
						finally:
							dataFile.close()
						title_m = re.compile('<title>(.*)</title>').search(thumbinfoXml)
						if title_m:
							title = title_m.group(1)
							name = cache_file_type + title

					tbn_file = u""
					if os.path.exists(baseFileName + u'.tbn'):
						tbn_file = baseFileName + u'.tbn'
					elif os.path.exists(baseFileName + u'.jpg'):
						tbn_file = baseFileName + u'.jpg'
					elif os.path.exists(baseFileName + u'.jpeg'):
						tbn_file = baseFileName + u'.jpeg'
					elif os.path.exists(baseFileName + u'[ThumbImg].jpeg'):
						tbn_file = baseFileName + u'[ThumbImg].jpeg'

					if not name:
						name = cache_file_type + video_title
					fileDataArray.append([name,video_id,cache_file_chk.encode("utf-8"),tbn_file.encode("utf-8")])

			fileDataArray.sort()
			for fileData in fileDataArray:
				self.list3.addItem( fileData[0] )
				self.List3_Data_Tuple_List.append((fileData[0],fileData[1],fileData[2],fileData[3]))

		elif self.List1_Index == 1:
			# 視聴履歴
			data = self.List2_Data_Tuple_List[self.List2_Index]
			name_id_ptn = re.compile(r"'(.*?)','(.*?)'")
			dayfile = open(data[1], 'r').read()
			for m in name_id_ptn.finditer(dayfile):
				video_id = m.group(1)
				title_name = m.group(2)
				self.list3.addItem(title_name)
				self.List3_Data_Tuple_List.append((title_name,video_id))

		elif self.List1_Index == 3:
			# にこ☆さうんど
			self.Mes_BOX("取得中...")

			ns = NicoSound()
			P_Num = self.Page_Num_List.getSelectedPosition()
			page = None
			if self.List2_Index < 5:
				page = P_Num + 1
			Plus_RANK = ''
			stb_value_list,video_id_list,title_list = ns.getNicoSound(NICO_SOUND_CHOOSE_CATE_ARRAY[self.List2_Index],page)
			for i in range(len(video_id_list)):
				if self.List2_Index < 5 :
					Plus_RANK = "#" + str((P_Num*20) + i + 1) + "  "
				video_id = video_id_list[i]
				title_name = '%s%s%s  (♪ %s | 時間：%s | %s kbps) [%s]' % (Plus_RANK,getTitlePrefix(video_id),title_list[i],stb_value_list[i][1],stb_value_list[i][0],stb_value_list[i][2],video_id_list[i])
				self.List3_Data_Tuple_List.append((title_name,video_id))
				if self.view_watched:
					title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
				self.list3.addItem(title_name)
			self.tbn_Down(video_id_list)
			self.Mes_BOX("にこ★さうんど＃" + NICO_SOUND_CHOOSE_ARRAY[self.List2_Index])

		elif self.List1_Index == 5:
			user_id = self.List2_Data_Tuple_List[self.List2_Index][1]
			self.on_Twitter_list2(user_id)
		elif self.List1_Index == 6:
			keyword = self.List2_Data_Tuple_List[self.List2_Index][1]
			self.on_TwitterSearch_list2(None, keyword, 1)
			return ''
#		self.setFocus(self.list3)
		self.addHistoryStock()

	def on_Twitter_list2(self,user_id,page=1):

		self.list3.reset()
		self.list3.selectItem(0)
		self.List3_Data_Tuple_List = []

		twitter = Twitter()
		result = twitter.getTweet(user_id,page)
		if result:
			tweet = re.sub("<(\"[^\"]*\"|'[^']*'|[^'\">])*>", r'', result[0])
			self.Mes_BOX(tweet)
			video_id_list = []
			nicoms_ptn = re.compile('http://nico.ms/([a-z]*[0-9]*)')
			watch_ptn = re.compile('http://www.nicovideo.jp/watch/([a-z]*[0-9]*)')
			bitly_ptn = re.compile('(http://bit.ly/[a-zA-Z0-9]*)')
			for tweet in result :
				tweet = re.sub("<(\"[^\"]*\"|'[^']*'|[^'\">])*>", r'', tweet)
				m = nicoms_ptn.search(tweet)
				if m:
					# 動画ID
					video_id = m.group(1)
					video_id_list.append(video_id)
				else:
					m = watch_ptn.search(tweet)
					if m:
						# 動画ID
						video_id = m.group(1)
						video_id_list.append(video_id)
					else:
						# 短縮URL
						m = bitly_ptn.search(tweet)
						if m:
							url = m.group(1)
							try:
								open = urllib2.urlopen(url)
								body = open.read()
								videoid_m = re.compile('canonical.*href="/watch/(.*)"').search(body)
								video_id = videoid_m.group(1)
								video_id_list.append(video_id)
							except:
								pass
						else:
							video_id = ""
				self.List3_Data_Tuple_List.append((tweet,video_id))
				if self.view_watched:
					if video_id:
						tweet = self.view_watched_prefix[self.isSaveComment(video_id)] + tweet
				self.list3.addItem(tweet)
			self.tbn_Down(list2set(video_id_list))

	twitter_keyword = None
	def on_TwitterSearch_list2(self,userid,keyword,page):
		'''Twitterで検索します'''

		self.Mes_BOX("取得中...")

		if keyword != None:
			twitter_keyword = keyword
#		print "on_TwitterSearch_list2:",userid,keyword,page

		self.list3.reset()
		self.list3.selectItem(0)
		self.List3_Data_Tuple_List = []

		tr = TwitterSearch()
		counts,userid_list,date_list,video_id_list,title_list = tr.getTwitterSearch(userid,twitter_keyword,page)
		if len(video_id_list) == 0:
			if keyword == None:
				self.Mes_BOX("ツイートは見つかりませんでした")
				self.list3.addItem("ツイートは見つかりませんでした")
				self.List3_Data_Tuple_List.append(('ツイートは見つかりませんでした',""))
			else:
				self.Mes_BOX('%s を含むツイートは見つかりませんでした' % keyword)
				self.list3.addItem('%s を含むツイートは見つかりませんでした' % keyword)
				self.List3_Data_Tuple_List.append(('%s を含むツイートは見つかりませんでした' % keyword,""))
		else:
			self.Mes_BOX("%s HIT !!" % counts)
			for i in range(len(video_id_list)):
				video_id = video_id_list[i]
				title_name = userid_list[i] + " " + getTitlePrefix(video_id) + title_list[i]
				self.List3_Data_Tuple_List.append((title_name,video_id))
				if self.view_watched:
					title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
				self.list3.addItem(title_name)
			self.tbn_Down(list2set(video_id_list))

	def COMMENT_Cate(self):
		'''取得コメント数の設定選択'''

		choose_getcomment_List = ["自動","250","500","1000"]

		select_dialog = xbmcgui.Dialog().select("取得コメント数の設定",choose_getcomment_List)
		if select_dialog == 0:
			self.nicoVideo.maxCommentNum = 0
		else:
			self.nicoVideo.maxCommentNum = int(choose_getcomment_List[select_dialog])
		self.Mes_BOX("取得コメント数を%sに設定しました" %choose_getcomment_List[select_dialog])


	def pushX_nico_List1(self):
		'''リスト1でＸボタンを押した場合処理'''

		index = self.list1.getSelectedPosition()
		selectsData = self.List1_Data_Tuple_List[index][1]
		if  self.Work_Group_ID == RANKING_WORK_ID:
			if 3 <= self.List1_Index and self.List1_Index <= 7:
				self.Ranking_Type_Change()
				self.Ranking_Type.setSelected(self.ranking_type == int(__settings__.getSetting("ranking_type")))
		elif self.Work_Group_ID == WATCHLIST_WORK_ID:
			if xbmcgui.Dialog().yesno("確認","%sをお気に入りユーザーから削除しますか？" % selectsData[1]):
				self.nicoVideo.deleteWatchitem(selectsData[0])
				del self.List1_Data_Tuple_List[index]
				self.list1.reset()
				self.list1.selectItem(0)
				for data1 in self.List1_Data_Tuple_List:
					self.list1.addItem(data1[0])
				xbmcgui.Dialog().ok("","%sをお気に入りユーザーから削除しました" % selectsData[1])

	def pushX_nico_List2(self):
		'''リスト2でＸボタンを押した場合処理'''

		index = self.list2.getSelectedPosition()

		if self.Work_Group_ID == CHANNEL_WORK_ID:
			selectCh = self.List2_Data_Tuple_List[index][1][0]
			choose_List = []
			print "selectCh="+selectCh

			regist = False
			channelList = self.nicoVideo.getMyChannel()
			for channelData in channelList:
				if channelData[0] == selectCh:
					regist = True
					choose_List.append("チャンネルをお気に入りから解除する")
					break
			else:
				choose_List.append("チャンネルをお気に入りに登録する")

			select_dialog = xbmcgui.Dialog().select("チャンネル",choose_List)
			if select_dialog < 0:
				return None
			elif select_dialog == 0:
				if regist:
					self.nicoVideo.deleteChannel(selectCh)
					xbmcgui.Dialog().ok("","%sをお気に入りから解除しました" % self.List2_Data_Tuple_List[index][1][1])
				else:
					self.nicoVideo.addChannel(selectCh)
					xbmcgui.Dialog().ok("","%sをお気に入りに登録しました" % self.List2_Data_Tuple_List[index][1][1])
		else:
			selectsmName = self.List2_Data_Tuple_List[index][0]
			if self.Work_Group_ID == RANKING_WORK_ID and self.List1_Index == 1:
				select_dialog = xbmcgui.Dialog().select("選択",["お気に入りタグ削除","検索キーワード登録"])
				if select_dialog < 0:
					return None
				if select_dialog == 0:
					if xbmcgui.Dialog().yesno("確認","お気に入りタグから削除しますか？"):
						status,code = self.nicoVideo.deleteFavtag(selectsmName)
						if status:
							xbmcgui.Dialog().ok("","お気に入りタグから削除しました")
						else:
							xbmcgui.Dialog().ok("","お気に入りタグからの削除に失敗しました")
				else:
					self.keywordInput(selectsmName)
			else:
				select_dialog = xbmcgui.Dialog().select("選択",["お気に入りタグ登録","検索キーワード登録"])
				if select_dialog < 0:
					return None

				if select_dialog == 0:
					selectsmName = re.sub('\s+\([0-9]+\)','', selectsmName)
					keyboard = xbmc.Keyboard(selectsmName, "お気に入りタグの登録")
					keyboard.setHiddenInput(False)
					keyboard.doModal()

					if keyboard.isConfirmed():
						selectsmName = keyboard.getText()
						if selectsmName == "" :
							return None
					else:
						return None

					status,code = self.nicoVideo.addFavtag(selectsmName)
					if status:
						xbmcgui.Dialog().ok("","お気に入りタグに登録しました")
					else:
						if code == "exist_favtag":
							xbmcgui.Dialog().ok("","既にお気に入りタグに登録されています")
						else:
							xbmcgui.Dialog().ok("","お気に入りタグ登録に失敗しました")
				else:
					self.keywordInput(selectsmName)

	def keywordInput(self, selectsmName):
		selectsmName = re.sub('\s+\([0-9]+\)','', selectsmName)

		keyboard = xbmc.Keyboard(selectsmName, "検索キーワードの登録")
		keyboard.setHiddenInput(False)
		keyboard.doModal()

		if keyboard.isConfirmed():
			selectsmName = keyboard.getText()
			if selectsmName == "" :
				return None
		else:
			return None

		if len(self.search_keyword) == 0:
			keyword = selectsmName
			__settings__.setSetting(id="search_keyword", value=selectsmName)
		else:
			keyword = __settings__.getSetting("search_keyword") + "," + selectsmName
			__settings__.setSetting(id="search_keyword", value=keyword)
		self.search_keyword = keyword.split(',')
		xbmcgui.Dialog().ok("","%sを検索ワードに登録しました" % selectsmName )

	def pushX_nico_List3(self):
		'''リスト3でＸボタンを押した場合処理'''

		index = self.list3.getSelectedPosition()

		selectsmName = self.List3_Data_Tuple_List[index][0]
		selectsmNum = self.List3_Data_Tuple_List[index][1]
		if selectsmNum == "":
			return None

		#print "selectsmName=",selectsmName
		#print "selectsmNum=",selectsmNum

		Rankchk = re.compile(r"#[0-9]+[ ][ ](.*)")
		if Rankchk.search(selectsmName): # ランクが入ってる表示なら
			for DEL_RANK in Rankchk.finditer(selectsmName):
				selectsmName = DEL_RANK.group(1)
			#self.Mes_BOX("%s\n%s" %(selectsmName,selectsmNum) )
		else:
			pass
			#self.Mes_BOX("%s\n%s" %(selectsmName,selectsmNum) )

		if not selectsmNum:
			return None

		# マイリストの場合
		if re.compile(r"mylist/.*?").search(selectsmNum):
			cate_name_list = []
			category_ptn = re.compile(r"Category([0-9]+?):(.*?)\n")
			file = open(favorite_txt, 'r')
			try:
				read = file.read()
				for m in category_ptn.finditer(read):
					cate_name_list.append(m.group(2) + " に追加")
			finally:
				file.close()

			select_dialog = xbmcgui.Dialog().select("お気に入りカテゴリに追加する",cate_name_list)
			if 0 <= select_dialog:
				cate_SelectedNum = int(select_dialog) + 1
				body = self.xbmc_nico_Access(nicoURL = selectsmNum )
#				print body
				title_m = re.compile('name: "(.*)",').search(body)
				mylist_title = title_m.group(1)
				s = '<cate="%s" url="http://www.nicovideo.jp/%s">%s</tag>\n' %(cate_SelectedNum,selectsmNum,mylist_title)

				file = open(favorite_txt, 'a')
				try:
					try:
						file.write(s)
						xbmcgui.Dialog().ok("","%sに追加しました" % (mylist_title,cate_name_list[select_dialog]))
					except Exception, e:
						print str(e)
						xbmcgui.Dialog().ok("エラー","書き込みに失敗しました")
				finally:
					file.close()

		# 動画ファイルの場合
		else:
			if self.Work_Group_ID == LIVE_WORK_ID or selectsmNum.startswith('lv'):
				lv_selectsmNum = self.List3_Data_Tuple_List[index][2]
				if self.List1_Index == 0 and 4<len(self.List3_Data_Tuple_List[index]):
					choose_List = ["タイムシフト予約を削除する","タイトルの一部で検索する"]
					select_dialog = xbmcgui.Dialog().select("生放送",choose_List)
					if select_dialog == 0:
						if xbmcgui.Dialog().yesno("削除確認","本当に削除してもよろしいですか？"):
							self.nicoVideo.deleteTimeshift(selectsmNum, self.List3_Data_Tuple_List[index][3])
							xbmcgui.Dialog().ok("","タイムシフト予約を削除しました")
							self.on_Live_list1()
					if select_dialog == 1:
						title = self.List3_Data_Tuple_List[index][4]["title"]
						keyboard = xbmc.Keyboard(title, "検索キーワードの入力")
						keyboard.setHiddenInput(False)
						keyboard.doModal()

						if keyboard.isConfirmed():
							title = keyboard.getText()
							if title == "" :
								return None
						else:
							return None
						self.on_Live_list2(title,None,1,self.time_shift)
				elif  selectsmNum.startswith('ch'):
					choose_List = ["チャンネル情報を取得する"]

					regist = False
					channelList = self.nicoVideo.getMyChannel()
					for channelData in channelList:
						if channelData[0] == selectsmNum:
							regist = True
							choose_List.append("チャンネルをお気に入りから解除する")
							break
					else:
						choose_List.append("チャンネルをお気に入りに登録する")
					select_dialog = xbmcgui.Dialog().select("チャンネル",choose_List)
					if select_dialog < 0:
						return None
					elif select_dialog == 0:
						self.List3_Data_Tuple_List = []
						self.list3.reset()
						self.list3.selectItem(0)

						selectChannel = 'video/' + selectsmNum
						self.on_Ranking_list1(href_href = "%s" %selectChannel, workgroup_id = CHANNEL_WORK_ID)
					elif select_dialog == 1:
						if regist:
							self.nicoVideo.deleteChannel(selectsmNum)
							xbmcgui.Dialog().ok("","%sをお気に入りから解除しました" % selectsmNum)
						else:
							self.nicoVideo.addChannel(selectsmNum)
							xbmcgui.Dialog().ok("","%sをお気に入りに登録しました" % selectsmNum)

				elif selectsmNum.startswith('co'):
					choose_List = ["詳細を表示する","タイムシフト予約をする","タイトルの一部で検索する"]

					info = self.nicoVideo.getCommunityInfo(selectsmNum)
					if info['motion_form']:
						choose_List.append("コミュニティに参加する")
					else:
						choose_List.append("コミュニティを退会する")

					choose_List.append("コミュニティの生放送履歴を取得する")

					if info['lv_id'] != None and info['lv_id'] == lv_selectsmNum:
						choose_List.append("コミュニティの放送(同じ)を視聴する")
					elif info['lv_id'] != None:
						choose_List.append("コミュニティの放送("+info['lv_id']+")を視聴する")
					else:
						choose_List.append("コミュニティの放送はありません")

					select_dialog = xbmcgui.Dialog().select("生放送",choose_List)

					if select_dialog == 0:
						watchPlayer = self.nicoVideo.getWatchPlayer(info['lv_id'])
						if watchPlayer == None:
							xbmcgui.Dialog().ok("エラー","詳細の取得に失敗しました")
						else:
							watchPlayerDialog = WatchPlayerDialog()
							watchPlayerDialog.setTextLabel(watchPlayer["title"],watchPlayer["postedAt"],watchPlayer["description"])
							watchPlayerDialog.doModal()
							watchPlayerDialog.close()

					if select_dialog == 1:
						rs = self.nicoVideo.setWatchingReservation('watch_num',info['lv_id'][2:])
						if rs:
							xbmcgui.Dialog().ok("","タイムシフト予約を完了しました")
						elif rs == -1:
							xbmcgui.Dialog().ok("","既に予約済みです")
						else:
							xbmcgui.Dialog().ok("","不明なエラーが発生しました")

					if select_dialog == 2:
						title = self.List3_Data_Tuple_List[index][3]["title"]
						keyboard = xbmc.Keyboard(title, "検索キーワードの入力")
						keyboard.setHiddenInput(False)
						keyboard.doModal()

						if keyboard.isConfirmed():
							title = keyboard.getText()
							if title == "" :
								return None
						else:
							return None
						self.on_Live_list2(title,None,1,self.time_shift)

					elif select_dialog == 3:
						if info['motion_form']:
							self.nicoVideo.motionCommunity(selectsmNum)
							xbmcgui.Dialog().ok("","コニュニティ(%s)に参加しました" % selectsmNum)
							if self.community_id_list: self.community_id_list.append(selectsmNum)
						else:
							if xbmcgui.Dialog().yesno("確認","本当に退会してもよろしいですか？"):
								self.nicoVideo.leaveCommunity(selectsmNum)
								xbmcgui.Dialog().ok("","コニュニティ(%s)を退会しました" % selectsmNum)
								if self.community_id_list:
									for i,id in enumerate(self.community_id_list):
										if selectsmNum == id:
											self.community_id_list[i] = ""
											break

					elif select_dialog == 4:
						resultArray = self.nicoVideo.getLiveArchives(selectsmNum, 1)
						self.List3_Data_Tuple_List = []
						self.list3.reset()
						self.list3.selectItem(0)
						if len(resultArray) == 0:
							self.list3.addItem("生放送履歴がありません")
							self.List3_Data_Tuple_List.append(("生放送履歴がありません",""))
						else:
							for rs in resultArray:
								title = rs[0] + ": " + rs[3]
								lv_id = rs[2]
								self.List3_Data_Tuple_List.append((title,selectsmNum,lv_id,rs))
								self.list3.addItem(title)
							self.addHistoryStock()
						if index != 0:
							index = index -1
						self.list3.selectItem(index)

					elif select_dialog == 5:
						if info['lv_id']:
							self.startVideoPlayer(info['lv_id'],info['lv_title'],streaming = self.isStreaming)

				elif lv_selectsmNum.startswith('lv'):
					choose_List = ["詳細を表示する","タイトルの一部で検索する","タイムシフト予約をする"]
					select_dialog = xbmcgui.Dialog().select("生放送",choose_List)

					if select_dialog == 0:
						watchPlayer = self.nicoVideo.getWatchPlayer(lv_selectsmNum)
						if watchPlayer == None:
							xbmcgui.Dialog().ok("エラー","詳細の取得に失敗しました")
						else:
							watchPlayerDialog = WatchPlayerDialog()
							watchPlayerDialog.setTextLabel(watchPlayer["title"],watchPlayer["postedAt"],re.sub(r'(\r\n)+','\r\n',watchPlayer["description"]))
							watchPlayerDialog.doModal()
							watchPlayerDialog.close()

					if select_dialog == 1:
						title = self.List3_Data_Tuple_List[index][3]["title"]
						keyboard = xbmc.Keyboard(title, "検索キーワードの入力")
						keyboard.setHiddenInput(False)
						keyboard.doModal()

						if keyboard.isConfirmed():
							title = keyboard.getText()
							if title == "" :
								return None
						else:
							return None
						self.on_Live_list2(title,None,1,self.time_shift)
					if select_dialog == 2:
						rs = self.nicoVideo.setWatchingReservation('watch_num',lv_selectsmNum[2:])
						if rs:
							xbmcgui.Dialog().ok("","タイムシフト予約を完了しました")
						elif rs == -1:
							xbmcgui.Dialog().ok("","既に予約済みです")
						else:
							xbmcgui.Dialog().ok("エラー","不明なエラーが発生しました")

			elif self.Work_Group_ID == MYLIST_WORK_ID and self.List1_Index == 0:
				choose_List = ["詳細情報を取得する","他のマイリストへ移動する","他のマイリストへコピーする","マイリストから削除する","投稿者をお気に入りユーザーに登録する","この動画をTwitterで検索する","ストリーミング再生を実行する","ダウンロード再生を実行する","一時ファイルにダウンロードしてから再生する","一時ファイルにダウンロードする"]
				if self.isSaveComment(self.List3_Data_Tuple_List[index][1]):
					choose_List.append("未視聴に設定する（コメントの削除）")
				select_dialog = xbmcgui.Dialog().select("動画ファイル",choose_List)
				if select_dialog < 0:
					return None
				elif select_dialog == 0:
					self.show_Detail(selectsmNum)
				elif select_dialog == 1:
					choose_List = []
					mylistArray = self.nicoVideo.getMyList()
					for mylistData in mylistArray:
						choose_List.append(mylistData[1])
					group_id = None
					if self.List2_Index != 0:
						group_id = mylistArray[self.List2_Index-1][0]
						del choose_List[self.List2_Index-1]
						del mylistArray[self.List2_Index-1]

					if len(choose_List) == 0:
						xbmcgui.Dialog().ok("","移動できるマイリストがありませんでした")
						return None
					select_dialog = xbmcgui.Dialog().select("移動先マイリスト選択",choose_List)
					if select_dialog < 0:
						return None

					target_group_id = mylistArray[select_dialog][0]
					self.nicoVideo.moveMylist(selectsmNum, target_group_id, group_id)
					del self.List3_Data_Tuple_List[index]
					self.list3.reset()
					if len(self.List3_Data_Tuple_List) == 0:
						self.list3.addItem("マイリストに動画は登録されていません。")
						self.List3_Data_Tuple_List.append(("マイリストに動画は登録されていません。",""))
					else:
						for data in self.List3_Data_Tuple_List:
							self.list3.addItem(data[0])

					if index != 0:
						index = index -1
					self.list3.selectItem(index)
					xbmcgui.Dialog().ok("","%sに移動しました" % choose_List[select_dialog])
				elif select_dialog == 2:
					choose_List = []
					mylistArray = self.nicoVideo.getMyList()
					for mylistData in mylistArray:
						choose_List.append(mylistData[1])

					group_id = None
					if self.List2_Index != 0:
						group_id = mylistArray[self.List2_Index-1][0]
						del choose_List[self.List2_Index-1]
						del mylistArray[self.List2_Index-1]

					if len(choose_List) == 0:
						xbmcgui.Dialog().select("","コピーできるマイリストがありませんでした")
						return None
					select_dialog = xbmcgui.Dialog().select("コピー先マイリスト選択",choose_List)
					if select_dialog < 0:
						return None
					target_group_id = mylistArray[select_dialog][0]
					self.nicoVideo.copyMylist(selectsmNum, target_group_id, group_id)
					xbmcgui.Dialog().ok("","%sにコピーしました" % choose_List[select_dialog])
				elif select_dialog == 3:
					if xbmcgui.Dialog().yesno("削除確認","マイリストから削除してもよろしいですか？"):
						if self.List2_Index == 0:
							group_id = None
						else:
							group_id = re.sub("mylist/", "", self.List2_Data_Tuple_List[self.List2_Index][1])

						self.nicoVideo.deleteMylist(selectsmNum, group_id)
						del self.List3_Data_Tuple_List[index]
						self.list3.reset()
						if len(self.List3_Data_Tuple_List) == 0:
							self.list3.addItem("マイリストに動画は登録されていません。")
							self.List3_Data_Tuple_List.append(("マイリストに動画は登録されていません。",""))
						else:
							for data in self.List3_Data_Tuple_List:
								self.list3.addItem(data[0])
						if index != 0:
							index = index -1
						self.list3.selectItem(index)
						xbmcgui.Dialog().ok("","%sをマイリストから削除しました" % selectsmName)
				elif select_dialog == 4:
					status,code = self.nicoVideo.addWatchlist(selectsmNum)
					if status:
						xbmcgui.Dialog().ok("","お気に入りユーザーに登録しました")
					else:
						if code == "EXIST":
							xbmcgui.Dialog().ok("","既にお気に入りユーザーに登録されています")
						else:
							xbmcgui.Dialog().ok("エラー","お気に入りユーザー登録に失敗しました")

				elif select_dialog == 5:
					self.on_TwitterSearch_list2(None, selectsmNum, 1)
				elif select_dialog == 6:
					self.startVideoPlayer(selectsmNum,selectsmName,streaming = True)
				elif select_dialog == 7:
					self.startVideoPlayer(selectsmNum,selectsmName)
				elif select_dialog == 8:
					self.startVideoPlayer(selectsmNum,selectsmName,isTemp = True)
				elif select_dialog == 9:
					self.startVideoPlayer(selectsmNum,selectsmName,isTemp = True, isPlay = False)
				elif select_dialog == 10:
					m = self.file_num_re.match(selectsmNum)
					num = int(m.group(1))
					historyCommentFilePath = os.path.join(os.path.join(comment_dir,str(num%1000)),selectsmNum + '.xml')
					if os.path.exists(historyCommentFilePath):
						os.remove(historyCommentFilePath)
						if self.view_watched:
							list3Index = int(self.list3.getSelectedPosition())

							self.list3.reset()
							for data in self.List3_Data_Tuple_List:
								if  data[1]:
									self.list3.addItem(self.view_watched_prefix[self.isSaveComment(data[1])] + data[0])
								else:
									self.list3.addItem(data[0])
							self.list3.selectItem(list3Index)
							time.sleep(0.1)
						xbmcgui.Dialog().ok("","コメントを削除しました")

			else:
				choose_List = ["詳細情報を取得する","とりあえず一発登録する","マイリスト登録する","投稿者をお気に入りユーザーに登録する","お気に入りカテゴリに登録する","この動画をTwitterで検索する"]

				if self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 0:
					choose_List.append("この動画を一時ファイルから削除する")
					choose_List.append("一時ファイルを全て削除する")
				else:
					choose_List.append("ストリーミング再生を実行する")
					choose_List.append("ダウンロード再生を実行する")
					choose_List.append("一時ファイルにダウンロードしてから再生する")
					choose_List.append("一時ファイルにダウンロードする")

					if self.isSaveComment(self.List3_Data_Tuple_List[index][1]):
						choose_List.append("未視聴に設定（コメントの削除）")
				select_dialog = xbmcgui.Dialog().select("動画ファイル",choose_List)
				if select_dialog < 0:
					return None
				elif select_dialog == 0:
					self.show_Detail(selectsmNum)
				elif select_dialog == 1:
					self.nicoVideo.addMylist(selectsmNum)
					xbmcgui.Dialog().ok("","とりあえずマイリストに登録しました")
				elif select_dialog == 2:
					choose_List = []
					mylistArray = self.nicoVideo.getMyList()

					if len(mylistArray) == 0:
						xbmcgui.Dialog().ok("","登録できるマイリストがありません")
						return None
					for mylistData in mylistArray:
						choose_List.append(mylistData[1])

					select_dialog = xbmcgui.Dialog().select("登録先マイリストの選択",choose_List)
					if select_dialog < 0:
						return None
					group_id = mylistArray[select_dialog][0]
					self.nicoVideo.addMylist(selectsmNum, group_id)
					xbmcgui.Dialog().ok("","%sに登録しました" % choose_List[select_dialog])
				elif select_dialog == 3:
					status,code = self.nicoVideo.addWatchlist(selectsmNum)
					if status:
						xbmcgui.Dialog().ok("","お気に入りユーザーに登録しました")
					else:
						if code == "EXIST":
							xbmcgui.Dialog().ok("","既にお気に入りユーザーに登録されています")
						else:
							xbmcgui.Dialog().ok("エラー","お気に入りユーザー登録に失敗しました")
				elif select_dialog == 4:
					cate_name_list = []
					Cate_name = re.compile(r"Category([0-9]+?):(.*?)\n")
					Favo_read = open(favorite_txt, 'r').read()
					for m in Cate_name.finditer(Favo_read):
						cate_name_list.append(m.group(2))
					select_dialog = xbmcgui.Dialog().select("カテゴリの選択",cate_name_list)
					if 0 <= select_dialog:
						body = self.nicoVideo.apiGetThumbInfo(selectsmNum)
						title_m = re.compile('<title>(.*)</title>').search(body)
						Save_smfile = '<cate="%s" url="http://www.nicovideo.jp/watch/%s">%s</tag>\n' %(select_dialog,selectsmNum,title_m.group(1) )
						Favo_write = open(favorite_txt, 'a')
						Favo_write.write(Save_smfile)
						Favo_write.close()
						xbmcgui.Dialog().ok("","%sに追加しました" % cate_name_list[select_dialog])
				elif select_dialog == 5:
					self.on_TwitterSearch_list2(None, selectsmNum, 1)
				elif select_dialog == 6:
					if self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 0:
						if not xbmcgui.Dialog().yesno("確認","この動画を一時ファイルから削除してもよろしいですか？"):
							return False
						cacheFiles = [selectsmNum+".mp4", selectsmNum+".xml", selectsmNum+"[ThumbInfo].xml",selectsmNum+".tbn"]
						for cache in cacheFiles:
							f = os.path.join(cache_dir,cache)
							try:
								if os.path.exists(f):
									os.remove(f)
							except Exception, e:
								print "remove Error: %s" % e
						self.on_Other_list2()
					else:
						self.startVideoPlayer(selectsmNum,selectsmName,streaming = True)
				elif select_dialog == 7:
					if self.Work_Group_ID == OTHER_WORK_ID and self.List1_Index == 0:
						if not xbmcgui.Dialog().yesno("確認","一時ファイルを全て削除してもよろしいですか？"):
							return False
						if not xbmcgui.Dialog().yesno("再確認","本当に一時ファイルを全て削除してもよろしいですか？"):
							return False
						for cache in os.listdir(cache_dir):
							try:
								os.remove(os.path.join(cache_dir,cache))
							except Exception, e:
								print "remove Error: %s" % e
						self.on_Other_list2()
					else:
						self.startVideoPlayer(selectsmNum,selectsmName)
				elif select_dialog == 8:
					self.startVideoPlayer(selectsmNum,selectsmName,isTemp = True)
				elif select_dialog == 9:
					self.startVideoPlayer(selectsmNum,selectsmName,isTemp = True, isPlay = False)
				elif select_dialog == 10:
					m = self.file_num_re.match(selectsmNum)
					num = int(m.group(1))
					historyCommentFilePath = os.path.join(os.path.join(comment_dir,str(num%1000)),selectsmNum + '.xml')
					if os.path.exists(historyCommentFilePath):
						os.remove(historyCommentFilePath)

						if self.view_watched:
							list3Index = int(self.list3.getSelectedPosition())
							self.list3.reset()
							for data in self.List3_Data_Tuple_List:
								if  data[1]:
									self.list3.addItem(self.view_watched_prefix[self.isSaveComment(data[1])] + data[0])
								else:
									self.list3.addItem(data[0])
							self.list3.selectItem(list3Index)
							time.sleep(0.1)

						xbmcgui.Dialog().ok("","コメントを削除しました")

	def show_Detail(self ,video_id):
		'''詳細情報の表示'''

		self.Mes_BOX("詳細情報を取得中...")


		if video_id.startswith('lv'):
			watchPlayer = self.nicoVideo.getWatchPlayer(video_id)
			if watchPlayer == None:
				self.Mes_BOX("指定された動画は見つかりませんでした")
			else:
				self.List2_Data_Tuple_List = []
				self.List3_Data_Tuple_List = []
				self.list2.reset()
				self.list3.reset()

				self.list2.addItem(NO_TITLE)
				self.List2_Data_Tuple_List.append((NO_TITLE, ""))

				title = watchPlayer["title"] + "[" + watchPlayer["postedAt"] + "][" + video_id + "]"
				self.list3.addItem(title)
				self.List3_Data_Tuple_List.append((title, video_id, video_id))

				self.list3.selectItem(0)
				self.addHistoryStock()
				self.tbn_lv_Down([video_id], [watchPlayer["thumbnail"]])

				watchPlayerDialog = WatchPlayerDialog()
				watchPlayerDialog.setTextLabel(watchPlayer["title"],watchPlayer["postedAt"],re.sub(r'(\r\n)+','\r\n',watchPlayer["description"]))
				watchPlayerDialog.doModal()
				watchPlayerDialog.close()
		else:
			self.nicoVideo.video_id = video_id
			apiGetThumbInfo = self.nicoVideo.apiGetThumbInfo(video_id)
			if self.__dbg__: print "apiGetThumbInfo = %s" % (apiGetThumbInfo)
			if re.compile('<code>NOT_FOUND</code>').search(apiGetThumbInfo):
				self.Mes_BOX("指定された動画は見つかりませんでした")
				return None

			self.Work_Group_ID = WATCHLIST_WORK_ID
			self.List1_Data_Tuple_List = []
			self.List2_Data_Tuple_List = []
			self.List3_Data_Tuple_List = []

			video_id_list = []

			self.TAG_FLAG = True
			origin_video_id = video_id

			thumbinfoData = self.nicoVideo.getThumbInfo(apiGetThumbInfo)

			if self.detail_mylist_comment:
				self.Mes_BOX("マイリストコメントを取得中...")
				mylistCommentArray = self.nicoVideo.getMyListComment()# マイリストコメント

			if self.detail_recommend_video:
				self.Mes_BOX("おすすめ動画を取得中...")
				relationArray = self.nicoVideo.apiGetrelation(video_id)# おすすめ動画

			if self.detail_public_mylist:
				self.Mes_BOX("公開マイリストを取得中...")
				openlistArray = self.nicoVideo.getOpenlist(video_id)# 公開マイリスト

			if self.detail_nicosound:
				self.Mes_BOX("にこ☆さうんど＃を取得中...")
				ns = NicoSound()
				ns_video_list, ns_title_list, ns_videoInfo_list = ns.getNicoSoundRelatedVideo(origin_video_id)

			if self.detail_twitter_comment:
				self.Mes_BOX("Twitterコメントを取得中...")
				tr = TwitterSearch()
				counts, tuserid_list, date_list, twitter_video_id_list, title_list = tr.getTwitterSearch(None,video_id, 1)

			self.Mes_BOX(thumbinfoData.description)

			self.list1.reset()
			self.list2.reset()
			self.list3.reset()


			title = thumbinfoData.title
			viewCount = thumbinfoData.view_counter
			mylistCount = thumbinfoData.mylist_counter
			commentCount = thumbinfoData.comment_num
			size_high_num = int(thumbinfoData.size_high)
			size_high_num_m = size_high_num / 1024

			tag_list = []
			#lockedTags_array = lockedTags.split(',')
			for tag in thumbinfoData.tagLockArray:
				tag_list.append(tag)
			for tag in thumbinfoData.tagArray:
				tag_list.append(tag)

			viewCount = re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', viewCount)
			commentCount = re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', commentCount)
			mylistCount = re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', mylistCount)

			# 詳細情報を更新表示、Watchページを見に行く
			detailMessage = ("%s(%s) (再生 %s | コメ %s | マイ %s | 時間 %s | サイズ %s | %s)" % (title, video_id, viewCount, commentCount, mylistCount, thumbinfoData.length, str(size_high_num_m), thumbinfoData.first_retrieve))
			if self.Cache_directory:
				exist,folderNo = self.getVideoExistsFolderPath(video_id)
				if exist:
					detailMessage = "(New File) " + detailMessage

			# リスト２にタグを追加
			for tag in tag_list:
				self.list2.addItem(tag)
				self.List2_Data_Tuple_List.append((tag, tag))
			self.List3_Data_Tuple_List.append((detailMessage, video_id))
			if self.view_watched:
				detailMessage = self.view_watched_prefix[self.isSaveComment(video_id)] + detailMessage
			self.list3.addItem(detailMessage)
			video_id_list.append(video_id)

			#コメント中の動画とマイリストを抽出
			video_id_ptn = re.compile(r'href="http://www.nicovideo.jp/watch/(.+?)"')
			video_body = self.xbmc_nico_Access(nicoURL = 'watch/' + video_id)
			if video_id_ptn.search(video_body):
				self.list3.addItem("-------------- コメント中の動画 --------------")
				self.List3_Data_Tuple_List.append(("-------------- コメント中の動画 --------------", ""))
				for m in video_id_ptn.finditer(video_body):
					comment_video_id = (m.group(1))
					body = self.xbmc_nico_Access(nicoURL = 'watch/' + comment_video_id)
					title_m = re.compile(r'<title>(.*)</title>').search(body)
					if title_m:
						title = title_m.group(1) + '['+comment_video_id+']'
						self.List3_Data_Tuple_List.append((title, comment_video_id))
						if self.view_watched:
							title = self.view_watched_prefix[self.isSaveComment(comment_video_id)] + title
						self.list3.addItem(title)
						video_id_list.append(comment_video_id)
					else:
						print "Not Found Video " + comment_video_id

			mylist_ptn = re.compile(r'mylist\/([0-9]+)')
			if mylist_ptn.search(thumbinfoData.description):
				self.list3.addItem("-------------- マイリスト --------------")
				self.List3_Data_Tuple_List.append(("-------------- マイリスト --------------", ""))
				for m in mylist_ptn.finditer(thumbinfoData.description):
					mylist_id = (m.group(1))
					body = self.xbmc_nico_Access(nicoURL = "mylist/"+mylist_id)
					title_m = re.compile(r'name: "(.*)",').search(body)
					if title_m:
						title = title_m.group(1)
						self.list3.addItem(title)
						self.List3_Data_Tuple_List.append((title,"mylist/"+mylist_id))
					else:
						print "Not Found Mylist " + mylist_id

			userid_list = []
			usericon_url_list = []

			# 投稿者(チャンネルの場合あり)
			if thumbinfoData.user_id != "":
				self.list1.addItem("この動画の投稿者")
				self.List1_Data_Tuple_List.append(("この動画の投稿者", [thumbinfoData.user_id, "この動画の投稿者", "", thumbinfoData.description]))

			# ここから取得選択
			if self.detail_recommend_video:
				self.list3.addItem("-------------- おすすめ動画 (%s) --------------" % len(relationArray))
				self.List3_Data_Tuple_List.append(("-------------- おすすめ動画 (%s) --------------" % len(relationArray), ""))
				if 0 == len(relationArray):
					self.list3.addItem("おすすめ動画はありません")
					self.List3_Data_Tuple_List.append(("おすすめ動画はありません", ""))
				else:
					for relation in relationArray:
						video_id = relation[0]
						view = re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', relation[3])
						comment = re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', relation[4])
						mylist = re.sub(r'(\d)(?=(\d{3})+(?!\d))', '\\1,', relation[5])
						timeStr = convertTime(int(relation[6]))
						dt = datetime.datetime.fromtimestamp(float(relation[7]))

						title_name = '%s (再生 %s | コメ %s | マイ %s | 時間 %s | %s ) [%s]' % (relation[2], view, comment, mylist, timeStr, dt, relation[0])
						self.List3_Data_Tuple_List.append((title_name, video_id))
						if self.view_watched:
							title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
						self.list3.addItem(title_name)
						video_id_list.append(video_id)

			if self.detail_nicosound:
				self.list3.addItem("-------------- 関連さうんど (%s) --------------" % len(ns_video_list))
				self.List3_Data_Tuple_List.append(("-------------- 関連さうんど (%s) --------------" % len(ns_video_list), ""))
				if 0 == len(ns_video_list):
					self.list3.addItem("関連さうんどはありません")
					self.List3_Data_Tuple_List.append(("関連さうんどはありません", ""))
				else:
					for i in range(len(ns_video_list)):
						video_id = ns_video_list[i]
						title_name = '%s  (♪ %s | 時間 %s | %s kbps)[%s]' % (ns_title_list[i], ns_videoInfo_list[i][0], ns_videoInfo_list[i][1], ns_videoInfo_list[i][2],video_id)
						if self.view_watched:
							title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
						self.list3.addItem(title_name)
						self.List3_Data_Tuple_List.append((ns_title_list[i], video_id))
						video_id_list.append(video_id)

			if self.detail_public_mylist:
				self.list3.addItem("-------- この動画の公開マイリスト (%s) --------" % len(openlistArray))
				self.List3_Data_Tuple_List.append(("--- この動画の公開マイリスト (%s) ---" % len(openlistArray), ""))
				if 0 == len(openlistArray):
					self.list3.addItem("公開マイリストはありません")
					self.List3_Data_Tuple_List.append(("公開マイリストはありません", ""))
				else:
					for openlist in openlistArray:
						title_name = '(' + openlist[2] + ') ' + openlist[1]
						self.list3.addItem(title_name)
						self.List3_Data_Tuple_List.append((title_name, openlist[0]))

			# マイリストコメント
			if self.detail_mylist_comment:
				self.list1.addItem("- コメント(%s) -" % len(mylistCommentArray))
				self.List1_Data_Tuple_List.append(("- コメント(%s) -" % len(mylistCommentArray), ""))
				if 0 == len(mylistCommentArray):
					self.list1.addItem("コメントはありません")
					self.List1_Data_Tuple_List.append(("コメントはありません",""))
				else:
					for mylistCommentData in mylistCommentArray:
						userid_list.append(mylistCommentData[0])
						usericon_url_list.append(mylistCommentData[2])
						title_name = mylistCommentData[1]
						self.list1.addItem(title_name)
						self.List1_Data_Tuple_List.append((title_name, mylistCommentData))

			if self.detail_twitter_comment:
				self.list3.addItem("-------- この動画のTwitterコメント(%s) --------" % counts)
				self.List3_Data_Tuple_List.append(("-------- この動画のTwitterコメント(%s) --------" % counts, ""))
				if len(twitter_video_id_list) == 0:
					self.list3.addItem("コメントはありません。")
					self.List3_Data_Tuple_List.append(('コメントはありません。', ""))
				else:
					for i in range(len(twitter_video_id_list)):
						video_id = twitter_video_id_list[i]
						title_name = tuserid_list[i] + " " + getTitlePrefix(video_id) + title_list[i]
						self.List3_Data_Tuple_List.append((title_name, video_id))
						if self.view_watched:
							title_name = self.view_watched_prefix[self.isSaveComment(video_id)] + title_name
						self.list3.addItem(title_name)

			self.list3.selectItem(0)
			self.addHistoryStock()
			self.usericon_Down(userid_list, usericon_url_list)
			self.tbn_Down(list2set(video_id_list))


	def xbmc_nico_Access(self, nicoURL = ""):
		if self.__dbg__: print "xbmc_nico_Access: %s" % (nicoURL)
		self.nicoVideo.loadCookie()
		if not self.nicoVideo.isLogin():
			self.nicoVideo.loginNicoVideo()
		self.nicoVideo.establishConnection()
		rs = self.nicoVideo.retryingAccess(self.nicoVideo.nico_conn, ('GET', '/%s' % nicoURL, '', self.nicoVideo.headers))
		self.nicoVideo.refreshCookie(rs)

		body = rs.read()
		rs.close()
		return body

	def xbmc_channel_Access(self, nicoURL = ""):
		if self.__dbg__: print "xbmc_channel_Access: %s" % (nicoURL)

		self.nicoVideo.loadCookie()
		if not self.nicoVideo.isLogin():
			self.nicoVideo.loginNicoVideo()
		self.nicoVideo.establishConnectionChannel()
		rs = self.nicoVideo.retryingAccess(self.nicoVideo.channel_conn, ('GET', '/%s' % nicoURL, '', self.nicoVideo.headers))
		self.nicoVideo.refreshCookie(rs)

		if rs.status == 301:
			url2 = re.sub(r'http://ch.nicovideo.jp','',rs.getheader('Location'))
			rs2 = self.nicoVideo.retryingAccess(self.nicoVideo.channel_conn, ('GET', url2, '', self.nicoVideo.headers))
			if rs2.status == 301:
				url3 = re.sub(r'http://ch.nicovideo.jp','',rs2.getheader('Location'))
				rs3 = self.nicoVideo.retryingAccess(self.nicoVideo.channel_conn, ('GET', url3, '', self.nicoVideo.headers))
				body = rs3.read()
				rs3.close()
			else:
				body = rs2.read()
			rs2.close()
		else:
			body = rs.read()
		rs.close()
		return body

	def isSaveComment(self, video_id):
		m = self.file_num_re.match(video_id)
		if m == None or m.group(1) == "":
			return False
		num = int(m.group(1))
		num_dir = os.path.join(comment_dir,str(num%1000))
		downloadCommentFilePath = os.path.join(num_dir,video_id + ".xml")
		return os.path.exists(downloadCommentFilePath)


	def imageFileDownloadThread(self,downloadFileList,downloadUrlList):

		for i in range(len(downloadFileList)):
			if not self.running: break
			if not os.path.exists(downloadFileList[i]):
				retry = self.MAX_TBN_RETRY_COUNT
				while retry:
					try:
						loc = urllib.URLopener()
						loc.retrieve(downloadUrlList[i], downloadFileList[i])
						self.tbn_down_count += 1
						break
					except Exception, e:
						print "error: %s" % e
						time.sleep(1)
						retry -= 1
				else:
					self.tbn_down_error_count += 1
					print downloadUrlList[i] + " download error."
				self.Textbox_tbn.setText("(サムネイル取得中... "+str(self.tbn_down_count + self.tbn_down_error_count)+"/"+str(self.tbn_down_allcount)+")")
		lock.acquire()
		self.tbn_down_thread_count -= 1
		if self.tbn_down_thread_count == 0:
			urllib.urlcleanup()
			print 'tbn download: success=%s, error=%s' % (self.tbn_down_count, self.tbn_down_error_count)
			self.tbn_down_count = 0
			self.tbn_down_allcount = 0
			self.tbn_down_error_count=0
			time.sleep(1.0)
			self.Textbox_tbn.setText("")
		lock.release()

	def imageFileDownload(self,fileList,urlList):

		self.tbn_down_allcount += len(fileList)
		max_down = None
		down_len = len(fileList)
		if xbmc.getFreeMem()<10:
			max_down = down_len
		else:
			if down_len / self.TBN_DOWN_THREAD_MAX < 5:
				max_down = 5
			else:
				max_down = int(round(down_len / self.TBN_DOWN_THREAD_MAX))

		index = 0
		while self.running and index < down_len:
			if index + max_down < down_len:
				end_index = index + max_down
			else:
				end_index = down_len
			lock.acquire()
			self.tbn_down_thread_count += 1
			lock.release()

			tbn_Thread = threading.Thread(target=self.imageFileDownloadThread,args=(fileList[index:end_index], urlList[index:end_index]))
			tbn_Thread.setDaemon(True)
			tbn_Thread.start()
			index = end_index

	def tbn_Down(self,video_id_list,tbn_id_list = None):
		'''サムネイルのダウンロード'''

		fileList = []
		urlList = []
		for i in range(len(video_id_list)):
			video_id = video_id_list[i]
			m = self.file_num_re.match(video_id)
			if m == None or m.group(1) == "":
				continue
			num = int(m.group(1))
			tbn_num_dir = os.path.join(tbn_dir,str(num%1000))
			downTbnFilePath = os.path.join(tbn_num_dir,video_id + ".jpg")
			if not os.path.exists(downTbnFilePath):
				fileList.append(downTbnFilePath)
				if tbn_id_list:
					if tbn_id_list[i].startswith("http:"):
						urlList.append(tbn_id_list[i])
					else:
						urlList.append('http://tn-skr.smilevideo.jp/smile?i=%s' % tbn_id_list[i])
				else:
					urlList.append('http://tn-skr.smilevideo.jp/smile?i=%s' % num)

		if len(fileList) == 0:
			return None
		self.imageFileDownload(fileList,urlList)


	def tbn_lv_Down(self,video_id_list,tbn_list):
		'''番組サムネイルのダウンロード'''

		fileList = []
		urlList = []
		for i in range(len(video_id_list)):
			video_id = video_id_list[i]
#			m = self.file_num_re.match(video_id)
#			if m == None or m.group(1) == "":
#				continue
#			num = int(m.group(1))
#			tbn_num_dir = os.path.join(lvtbn_dir,str(num%1000))
			downTbnFilePath = os.path.join(lvtbn_dir,video_id + ".jpg")
			if not os.path.exists(downTbnFilePath):
				fileList.append(downTbnFilePath)
				if tbn_list[i].startswith("http:"):
					urlList.append(tbn_list[i])
				elif tbn_list[i].startswith("thumb/"):
					urlList.append('http://live.nicovideo.jp/%s' % tbn_list[i])
				else:
					urlList.append('http://live.nicovideo.jp/thumb/%s' % tbn_list[i])

		if len(fileList) == 0:
			return None
		self.imageFileDownload(fileList,urlList)

	def usericon_Down(self,userid_list,usericon_url_list):
		'''ユーザーサムネイルのダウンロード'''

		fileList = []
		urlList = []
		for i in range(len(userid_list)):
			num = int(userid_list[i])
			downTbnFilePath = os.path.join(os.path.join(usericon_dir,str(num%1000)),userid_list[i] + ".jpg")
			if not os.path.exists(downTbnFilePath):
				fileList.append(downTbnFilePath)
				urlList.append(usericon_url_list[i])

		if len(fileList) == 0:
			return None
		self.imageFileDownload(fileList,urlList)

	def channelicon_Down(self,ch_list):
		'''チャンネルアイコンのダウンロード'''

		fileList = []
		urlList = []
		for ch in ch_list:
			downTbnFilePath = os.path.join(chicon_dir,ch + ".jpg")
			if not os.path.exists(downTbnFilePath):
				fileList.append(downTbnFilePath)
				urlList.append("http://icon.nimg.jp/channel/%s.jpg" % ch)
		if len(fileList) == 0:
			return None
		self.imageFileDownload(fileList,urlList)

	def communityicon_Down(self,co_list):
		'''コミュニティアイコンのダウンロード'''

		fileList = []
		urlList = []
		for co in co_list:
			m = self.file_num_re.match(co)
			if m == None or m.group(1) == "":
				continue
#			num = int(m.group(1))
#			downTbnFilePath = os.path.join(os.path.join(coicon_dir,str(num%1000)),co + ".jpg")
			downTbnFilePath = os.path.join(coicon_dir,co + ".jpg")
			if not os.path.exists(downTbnFilePath):
				fileList.append(downTbnFilePath)
				urlList.append("http://icon.nimg.jp/community/%s.jpg" % co)
		if len(fileList) == 0:
			return None
		self.imageFileDownload(fileList,urlList)


	def twittericon_Down(self,user_id_list):
		'''Twitterアイコンのダウンロード'''

		fileList = []
		urlList = []
		twitter = Twitter()
		for user_id in user_id_list:
			downFilePath = os.path.join(twittericon_dir,user_id+".png")
			if not os.path.exists(downFilePath):
				fileList.append(downFilePath)
				urlList.append(twitter.getIcon(user_id))
		if len(urlList) == 0:
			return None
		self.imageFileDownload(fileList,urlList)

	message = ''
	def Mes_BOX(self,text):
		'''メッセージボックスに表示します'''
		self.message = text
		self.Textbox_Right_TOP.setText(self.message)

	def getMessage(self):
		return self.message


	def Ranking_Type_Change(self):
		'''ランキング対象の選択 '''

		select = xbmcgui.Dialog().select("ランキング対象の選択",RANK_TYPE_NAME_LIST)
		if 0<=select:
			self.Mes_BOX("ランキング対象を"+self.RANK_TYPE_NAME_LIST[select]+"\nに変更しました。")
			self.ranking_type = select

			self.Ranking_Type.setSelected(self.ranking_type == select)

	def fontChange(self):
		xbmcgui.Dialog().ok("使用しているスキンには対応していません","skinフォルダに入っているFont.xmlの","<!-- XBMC nico -->～<!-- XBMC nico end -->を","使用しているスキンのフォントに追加してください")
		update_skin =  os.path.join(os.path.join(os.path.join('','skin.confluence'),'720p'),'Font.xml')
		if not update_skin == self.font_path[-len(update_skin):]:
			xbmcgui.Dialog().ok("使用しているスキンには対応していません","skinフォルダに入っているFont.xmlの","<!-- XBMC nico -->～<!-- XBMC nico end -->を","使用しているスキンのフォントに追加してください")
			return None

		if os.path.exists(self.backup_font_path):
			if xbmcgui.Dialog().yesno("確認","フォントファイルをバックアップに戻しますか？"):
				try:
					shutil.copy(self.backup_font_path,self.font_path)
					os.remove(self.backup_font_path)
					xbmcgui.Dialog().ok("","フォントファイルをバックアップに戻しました")
					if xbmcgui.Dialog().yesno("確認","フォント設定を反映するために\nXBOXを再起動しますか？"):
						xbmc.restart()
				except Exception, e:
					xbmcgui.Dialog().ok("","フォントファイルをバックアップに戻すことに失敗しました")
					print str(e)

#				xbmc.executebuiltin( "XBMC.ReloadSkin()" )
		else:
			if xbmcgui.Dialog().yesno("確認","フォント設定を更新しますか？"):
				try:
					update_font_path = os.path.join(os.path.join(os.path.join(os.path.join(root_dir,'skin'),'skin.confluence'),'720p'),'Font.xml')
					print "update_font_path="+update_font_path
					shutil.copy(self.font_path,self.backup_font_path)
					shutil.copy(update_font_path,self.font_path)

					xbmcgui.Dialog().ok("","フォント設定を更新しました")

					if xbmcgui.Dialog().yesno("確認","フォント設定を反映するために\nXBOXを再起動しますか？"):
						xbmc.restart()
				except Exception, e:
					xbmcgui.Dialog().ok("フォント設定の追加に失敗しました","skinフォルダに入っているFont.xmlの","<!-- XBMC nico -->～<!-- XBMC nico end -->を","使用しているスキンのフォントに追加してください")
					print str(e)
#				xbmc.executebuiltin( "XBMC.ReloadSkin()" )

			#elementtree
#			if xbmcgui.Dialog().yesno("確認","コメント用フォント設定を追加しますか？"):
#				try:
#					shutil.copy(self.font_path,self.backup_font_path)
#
#					import MyFont as myfont
#					myfont.addFont( "nico_font_18" , "Arial.ttf" , "18", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_24" , "Arial.ttf" , "24", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_30" , "Arial.ttf" , "30", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_40" , "Arial.ttf" , "40", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_50" , "Arial.ttf" , "50", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_60" , "Arial.ttf" , "60", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_70" , "Arial.ttf" , "70", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_80" , "Arial.ttf" , "80", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_90" , "Arial.ttf" , "90", style="bold" , shadow="FF666666" )
#					myfont.addFont( "nico_font_100" , "Arial.ttf" , "100", style="bold" , shadow="FF666666" )
#					xbmcgui.Dialog().ok("","コメント用フォント設定を追加しました")
#
#					if xbmcgui.Dialog().yesno("確認","フォント設定を反映するために\nXBOXを再起動しますか？"):
#						xbmc.restart()
#				except Exception, e:
#					xbmcgui.Dialog().ok("","コメント用フォント設定の追加に失敗しました")
#					print str(e)
##				xbmc.executebuiltin( "XBMC.ReloadSkin()" )
		self.font_CMark.setSelected(os.path.exists(self.backup_font_path))


	def nicoliveAntennaGet(self):
		if self.__dbg__: print "start nicoliveAntennaGet"
		nicoVideo = self.nicoVideo
#		nicoVideo = NicoVideo.NicoVideo()
#		nicoVideo.mailAddress = self.MailAddress
#		nicoVideo.passWord = self.PassWord
#		nicoVideo.force_overwrite = True
#		nicoVideo.save_message_xml = True
#		nicoVideo.process_list = False
#		nicoVideo.list_url = ''
#
#		nicoVideo.maxCommentNum = self.MAX_COMMENT_NUM
#		nicoVideo.root_dir = base_cache_path
#		nicoVideo.loginNicoVideo()
#		nicoVideo.establishConnection()
#
#		nicoVideo.loginNicoliveAntenna()

		p = re.compile('<chat thread="[0-9]+" no="[0-9]+" date="[0-9]+" user_id="[0-9]+" premium="[0-9]+">([0-9]+),(.*?),.*</chat>')
		if self.niconama_alert_time_of_start:
			p2 = re.compile('<title>(.*)</title><description>(.*)</description>.*<profile_image_url>(.*)</profile_image_url>')
			if self.niconama_alert_official:
				start = math.floor(time.time())
				timelineArray = self.nicoVideo.getTimeline(start,start + 60*30)
				for r in timelineArray:
					if r['status'] == 'onair' and r['category'] == 'official':
						m2 = None
						try:
							ps = nicoVideo.apiGetPlayerStatus(r['live_id'])
							m2 = p2.search(ps)
						except Exception, e:
							print "nicoliveAntennaGet apiGetPlayerStatus ERROR:" + str(e)
						if m2:
							title = m2.group(1)
							description = m2.group(2)
						else:
							title = r['title']
							description = r['description']
							print "unknown apiGetPlayerStatus: " + ps

						self.alertLiveList.append([r['live_id'],None,"[公式] " + title,description + ' の放送が開始されています。',"http://live.nicovideo.jp/thumb/%s" % (r['thumb'])])
						if self.__dbg__: print "nicoliveAntennaGet %s (official) is at the start time." % r['live_id']
			liveArray = self.nicoVideo.getMyParticipateLive()
			for r in liveArray:
				m2 = None
				try:
					ps = nicoVideo.apiGetPlayerStatus(r['guid'])
					m2 = p2.search(ps)
				except Exception, e:
					print "nicoliveAntennaGet apiGetPlayerStatus ERROR:" + str(e)
				if m2:
					title = m2.group(1)
					description = m2.group(2)
				else:
					title = r['community_title']
					description = r['title']
					print "unknown apiGetPlayerStatus: %s " % ps

				if r['community_id'].startswith("co"):
					thumb = "http://icon.nimg.jp/community/%s.jpg" % r['community_id']
				elif r['community_id'].startswith("ch"):
					thumb = "http://icon.nimg.jp/channel/%s.jpg" % r['community_id']

				self.alertLiveList.append([r['guid'],r['community_id'],title,description + ' の放送が開始されています。',thumb])
				if self.__dbg__: print "nicoliveAntennaGet %s is at the start time." % r['guid']

		nicoVideo.loginNicoliveAntenna()
		nicoVideo.apiGetAlertStatus()
		self.community_id_list = nicoVideo.community_id_list
		if self.__dbg__: print "community_id_list=%s" % self.community_id_list
		p3 = re.compile('<title>(.*)</title><description>(.*)</description>.*<thumbnail>(.*)</thumbnail>')
		p4 = re.compile('<error><code>(.*)</code><description>(.*)</description></error>')
		try:
			sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			sock.connect((nicoVideo.alert_ms_addr, nicoVideo.alert_ms_port))
			xml = '<thread thread="%s" version="20061206" res_from="-1"/>\0' % nicoVideo.alert_ms_thread
			sock.send(xml)
			while self.running:
				chat = sock.recv(2048)[:-1]
				if self.niconama_alert:
					for m in p.finditer(chat):
						community = m.group(2)
						if community in self.community_id_list or community == 'official':
							live_id = 'lv' + m.group(1)
							streaminfo = nicoVideo.apiGetStreaminfo(live_id)
							m3 = p3.search(streaminfo)
							if m3:
								title = m3.group(1)
								description = m3.group(2)
								thumbnail = m3.group(3)
#								if self.__dbg__: print "nicoliveAntennaGet add chat: " + chat
								if self.niconama_alert_official and community == 'official':
									self.alertLiveList.append([live_id,None,"[公式] " + title,description,thumbnail])
								else:
									self.alertLiveList.append([live_id,community,title,description + ' の放送が開始されました。',thumbnail])
							else:
								m4 = p4.search(streaminfo)
								if m4:
									code = m4.group(1)
									description = m4.group(2)
									if self.__dbg__: print 'nicoliveAntennaGet apiGetStreaminfo ERROR: %s,%s,%s,' % (live_id,code,description)
								else:
									print "nicoliveAntennaGet unknown apiGetStreaminfo: %s,%s" % (live_id,streaminfo)
		finally:
			sock.close()
		self.nicoliveAntennaGetThread = None
		if self.__dbg__: print "end nicoliveAntennaGet"

	def nicoliveAntennaAlert(self):
		scaleX = ( float(screen_width)  / float(640) )
		scaleY = ( float(screen_height) / float(480) )
		if self.__dbg__: print "start nicoliveAntennaAlert"
		self.alertImage = xbmcgui.ControlImage(0,int(screen_height-1*scaleY)+100,int(screen_width),int(35*scaleY), os.path.join(image_dir,'alert-bg.png'))
		self.alertLabel1 = xbmcgui.ControlTextBox(int(35*scaleX),int(screen_height-32*scaleY),int(screen_width-65*scaleX),int(50*scaleY),'font12_title',"0xFFFFFFFF")
		self.alertLabel2 = xbmcgui.ControlTextBox(int(35*scaleX),int(screen_height-18*scaleY),int(screen_width-65*scaleX),int(50*scaleY),'font12_title',"0xFFFFFFFF")
		self.alertButton = xbmcgui.ControlButton(int(614 * scaleX),int(455*scaleY),int(22*scaleX),int(22*scaleY), r""
													,focusTexture=os.path.join(image_dir,'back-noforcus.png'),noFocusTexture =os.path.join(image_dir,'back-forcus.png')
													)
		self.addControl(self.alertImage)
		self.addControl(self.alertLabel1)
		self.alertLabel1.setVisible(False)
		self.addControl(self.alertLabel2)
		self.alertLabel2.setVisible(False)
		self.addControl(self.alertButton)
		self.alertButton.controlDown(self.ranking_button)
		self.alertButton.setVisible(False)

		alertIndex = 0
		while self.running:
			# 再生準備中の処理待ち
			while self.isStartVideoPlayer:
				time.sleep(0.5)
			# 再生開始後の処理待ち
			if self.isStartVideoPlayerSuccess:
				time.sleep(10.0)
				self.isStartVideoPlayerSuccess = False
			if alertIndex < len(self.alertLiveList):
				if self.niconama_alert:
					r = self.alertLiveList[alertIndex]
					if r[1] == None:
						imageFile = os.path.join(lvtbn_dir,r[0] + ".jpg")
					elif r[1].startswith("co"):
						imageFile = os.path.join(coicon_dir,r[1] + ".jpg")
					elif r[1].startswith("ch"):
						imageFile = os.path.join(chicon_dir,r[1] + ".jpg")
					else:
						imageFile = os.path.join(lvtbn_dir,r[0] + ".jpg")

					if imageFile != None and not os.path.exists(imageFile):
						if self.__dbg__: print "alert download image:%s" % r[4]
						retry = 3
						while retry:
							try:
								urllib.URLopener().retrieve(r[4],imageFile)
								break
							except Exception, e:
								retry -= 1
								print "nicoliveAntennaAlert thumbnail download error: %s (%s)" % (str(e),retry)

					if xbmc.Player().isPlaying():
						if self.__dbg__: print "nicoliveAntennaAlert (Player): %s,%s,%s,%s,%s" % (r[0],r[1],r[2],r[3],r[4])
						self.alertDialog = NicoAlert.NicoAlert()
						self.alertDialog.setLiveAlert(r[0],r[2],r[3],imageFile,self.niconama_alert_view_time,self.comment_view,self.nicoVideo)
						self.alertDialog.doModal()
						self.alertDialog.close()
					else:
						if self.__dbg__: print "nicoliveAntennaAlert (Main): %s,%s,%s,%s,%s" % (r[0],r[1],r[2],r[3],r[4])
						self.alertImage.setVisible(True)

						if imageFile == None or not os.path.exists(imageFile):
							imageFile = os.path.join(image_dir,'noimage.jpg')
						self.alertThumb = xbmcgui.ControlImage(int(2*scaleX),int(screen_height-27*scaleY),int(26*scaleX),int(26*scaleY), imageFile)
						for i in range(16):
							self.alertImage.setPosition(0, int(screen_height-(i+1)*2*scaleY))
							time.sleep(0.1)
						self.addControl(self.alertThumb)
						self.alertLabel1.setText(r[2])
						self.alertLiveID = r[0]
						self.alertLiveTitle = r[2]
						self.alertLabel2.setText(r[3])
						self.alertThumb.setVisible(True)
						self.alertLabel1.setVisible(True)
						self.alertLabel2.setVisible(True)
						self.alertButton.setVisible(True)
						count = 0.0
						while self.running and self.alertLiveID != None and count < self.niconama_alert_view_time:
							time.sleep(0.05)
							count += 0.1
							try:
								if self.getFocus() == self.alertButton: count = self.niconama_alert_view_time / 2
							except Exception, e:
								print e
						self.alertThumb.setVisible(False)
						self.alertThumb = None
						self.alertLabel1.setText("")
						self.alertLabel2.setText("")
						self.alertLabel1.setVisible(False)
						self.alertLabel2.setVisible(False)
						self.alertButton.setVisible(False)
						if self.alertLiveID == None:
							time.sleep(3.0)
							self.alertImage.setVisible(False)
							time.sleep(7.0)
						else:
							for i in range(16, 0, -1):
								self.alertImage.setPosition(0, int(screen_height-(i+1)*2*scaleY))
								time.sleep(0.05)
							self.alertImage.setPosition(0, screen_height+100)
							self.alertImage.setVisible(False)
							self.alertLiveID = None
							self.alertLiveTitle = None
							time.sleep(0.5)
				alertIndex += 1
			else:
				time.sleep(1.0)
		self.nicoliveAntennaAlertThread = None
		if self.__dbg__: print "end nicoliveAntennaAlert"


	def removeCache(self):
		file_list = []
		cache_list = os.listdir(cache_dir)
		for f in cache_list:
			path = os.path.join(cache_dir,f)
			file_list.append((path, int(os.path.getmtime(path))))
		file_list.sort(sortArrayTop)
		count = len(file_list)
		save_num = (self.max_temporary_file_num - 1) * 4
		for cache in file_list:
			if save_num < count:
				try:
					print "remove cache: " + cache[0]
					os.remove(os.path.join(cache_dir,cache[0]))
					count = count - 1
				except Exception, e:
					print "remove cache Error: %s" % e
			else:
				break


class WatchPlayerDialog(xbmcgui.WindowDialog):

	def __init__(self):
		if Emulating: xbmcgui.WindowDialog.__init__(self)
		self.addControl(xbmcgui.ControlImage(0,0,screen_width,screen_height, os.path.join(image_dir,'enquete.png')))

	def setTextLabel(self, title, postedAt, description):
		smallFont = 'nico_font_24'
		smallFontSize = 24
		scaleX = ( float(screen_width)  / float(640) )
		scaleY = ( float(screen_height) / float(480) )
		self.label1 = xbmcgui.ControlTextBox(int(8*scaleX),int(10*scaleY),int((screen_width-20)),int(smallFontSize*2*scaleY),smallFont,"0xFFFFFFFF")
		self.label2 = xbmcgui.ControlTextBox(int(8*scaleX),int((10+(smallFontSize+10)*1)*scaleY),int((screen_width-20)),int(smallFontSize*20*scaleY),smallFont,"0xFFFFFFFF")
		self.addControl(self.label1)
		self.addControl(self.label2)

		self.label1.setText("%s  (投稿:%s)" % (title,postedAt))
		self.label2.setText(description)

	def onAction(self, action):
		if action == ACTION_PREVIOUS_MENU or action == ACTION_PARENT_DIR or action == ACTION_MOVE_DOWN:
			self.state = -1 #success
			self.close() #exit
		elif action == ACTION_MOVE_UP :
			pass

	def onControl(self, control):
		self.setFocus(control)

mydisplay = MyClass()
mydisplay.doModal()
del mydisplay
