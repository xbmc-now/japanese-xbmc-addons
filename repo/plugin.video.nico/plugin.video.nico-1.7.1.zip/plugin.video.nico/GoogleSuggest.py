#!/usr/bin/env python
# -*- coding: utf-8 -*-

import urllib
import urllib2
import re

class GoogleSuggest:
	'''Googleの予測変換'''

	def __init__(self):
		self.xml_ptn = re.compile('<CompleteSuggestion><suggestion data="(.*?)"/><num_queries int="(.*?)"/></CompleteSuggestion>')

	def getList(self, keyword):
		try:
			open = urllib2.urlopen('http://www.google.co.jp/complete/search?output=toolbar&q=' + urllib.quote_plus(keyword))
		except:
			return None
		buf = open.read()
		resultList = list()
		for m in self.xml_ptn.finditer(buf):
			result = dict([['suggestion', m.group(1)],['num_queries', int(m.group(2))]])
			resultList.append(result)
		return resultList

if '__main__' == __name__:
	googleSuggest = GoogleSuggest()
	resultList = googleSuggest.getList('(ﾟдﾟ)')
	if list:
		for result in resultList:
			print '%s: %d' % (result['suggestion'], result['num_queries'])