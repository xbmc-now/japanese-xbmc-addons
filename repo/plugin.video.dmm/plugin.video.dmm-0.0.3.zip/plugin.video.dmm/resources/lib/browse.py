#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  ブラウズ関数
##└──────────────────────────────────────
##
## [ 更新履歴 ]
##
##==============================================================================
## 設定値をここに記載する。
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import httplib, urllib, urllib2, cookielib
from urlparse import urlparse
from HTMLParser import HTMLParser, HTMLParseError
from BeautifulSoup import BeautifulSoup
import login
#-------------------------------------------------------------------------------
__mypage_url__ = "http://www.dmm.com/digital/-/mylibrary/=/page="

#-------------------------------------------------------------------------------
def openMyPage(br, cj, IPUT, p='1'):

	#---------------------------------------------------------------------------
	# マイページにアクセス
	req = urllib2.Request(__mypage_url__ + p)
	br.open(req)
	#cj.save(IPUT['cookie_path']) #Cookieを保存

	r = br.response()
	u = urlparse(r.geturl())
	domain = u.scheme + "://" + u.netloc
	res = r.read()
	#xbmc.log(res)

	soup = BeautifulSoup(res)

	#---------------------------------------------------------------------------
	# リスト出力

	xbmcplugin.setContent(IPUT['handle'], 'movies')
	lis = soup.find("ul", {"id":"js-list"}).findAll("li")
	count = 1
	for li in lis:
		label = str(li.find("p").renderContents().replace("<!-- /h2 -->", "")) # タイトル
		link  = str(domain + li.find("a")["href"]) # リンク
		image = str(li.find("img")["src"]) # 画像
		xli = xbmcgui.ListItem(label, iconImage=image, thumbnailImage=image)
		xli.setInfo(type = 'Video', infoLabels = {'title': label})
		xli.setProperty('fanart_image', image)
		url = 'plugin://' + IPUT['addon_id'] + '?ope=play&link=' + urllib.quote_plus(link)
		xbmcplugin.addDirectoryItem(IPUT['handle'], url, listitem = xli, isFolder = True, totalItems = count)
		count += 1

	page = soup.find("form", {"id":"jump"}).find("input", {"name":"page"})
	#xbmc.log("現在のページ:" + str(page["value"]) + " ページ数:" + str(page["max"]))
	if int(page["max"]) - int(page["value"]):
		url = 'plugin://' + IPUT['addon_id'] + '?ope=my&page=%d' % int(page["value"]) + 1
		xli = xbmcgui.ListItem('Next Page', "", "DefaultFolder.png", "DefaultFolder.png", url)
		xli.setInfo(type="Video", infoLabels={"Title":'Next Page'})
		xbmcplugin.addDirectoryItem(IPUT[ 'handle' ], url, xli, isFolder=True)

	xbmcplugin.endOfDirectory(handle = IPUT['handle'], succeeded = True)

	return True
