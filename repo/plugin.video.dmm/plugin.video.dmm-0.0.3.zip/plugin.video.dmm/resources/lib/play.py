#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  ログイン関数
##└──────────────────────────────────────
##
## [ 更新履歴 ]
##
##==============================================================================
## 設定値をここに記載する。
import sys, os, re, struct
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import threading, time
try:    import json
except: import simplejson as json
from HTMLParser import HTMLParser, HTMLParseError
from BeautifulSoup import BeautifulSoup
import httplib, urllib, urllib2, cookielib
from urlparse import urlparse
from urlparse import urljoin
import m3u8
from hashlib import md5
import threading
from Crypto.Cipher import AES
#-------------------------------------------------------------------------------
class MyPlayer(xbmc.Player):
	br = {}
	cj = {}
	IPUT = {}
	stop_event = threading.Event() # 停止させるかのフラグ生成
	#---------------------------------------------------------------------------
	def __init__(self, *args, **kwargs): # このクラスが呼び出される時に実行
		xbmc.Player.__init__(self)

	#---------------------------------------------------------------------------
	def getStream(self, *args, **kwargs):
		obj  = args[0]

		iv = b'\0' * 16
		cipher = AES.new(self.IPUT['key_buf'], AES.MODE_CBC, iv)

		duration = 0
		for segment in obj.segments: duration += segment.duration

		i = 0
		uptime   = 0
		overtime = 0
		timestamp = time.time()
		#xbmc.log('LoopStart:' + str(timestamp))

		xbmc.executebuiltin('Dialog.Close(busydialog)') # busyダイヤログを非表示にする

		#-----------------------------------------------------------------------
		# ストリーミング開始
		ts_play = False
		for segment in obj.segments:
			#xbmc.log(segment.uri)

			url = urljoin(self.IPUT['m3u8_url'], segment.uri)
			#xbmc.log(url)

			ts_file = open(self.IPUT['ts_path'], 'ab') # 追記バイナリ
			req = urllib2.Request(url)
			self.br.open(req)
			#xbmc.log('tsDonloaded')
			if self.stop_event.is_set(): break

			res = self.br.response().read()
			d = cipher.decrypt(res) # 復号化
			#xbmc.log('tsDecrypted')
			if self.stop_event.is_set(): 
				ts_file.close()
				break

			ts_file.write(d)
			ts_file.close()
			#xbmc.log('tsWrited')
			if self.stop_event.is_set(): break

			# ダウンロード中に再生を停止したら
			if ts_play and not self.isPlayingVideo(): 
				if xbmcvfs.exists(self.IPUT['ts_path']): xbmcvfs.delete(self.IPUT['ts_path'])
				self.stop_event.set()
				break

			# キャッシュが貯まったら再生開始
			uptime   += segment.duration
			overtime  = time.time() - timestamp
			#xbmc.log('Uptime:' + str(uptime) + ' Overtime:' + str(overtime))
			if not ts_play and not self.isPlayingVideo() and (uptime + ((duration - uptime)/(uptime / overtime))) < duration:
				self.play(self.IPUT['ts_path'])
				ts_play = True

		#-----------------------------------------------------------------------
		# ダウンロード終了後

		# 再生中であれば待機
		while self.isPlayingVideo(): time.sleep(.1)

		# 再生が終了したらダウンロードファイルを削除
		if xbmcvfs.exists(self.IPUT['ts_path']): xbmcvfs.delete(self.IPUT['ts_path'])

	#---------------------------------------------------------------------------
	def getPlaylist(self, *args, **kwargs): # 初期化で引数を渡せない為にこれを実行する
		self.br   = args[0]
		self.cj   = args[1]
		self.IPUT = args[2]

		xbmc.log("link::" + self.IPUT["link"])

		req = urllib2.Request(self.IPUT["link"])
		self.br.open(req)
		#self.cj.save(self.IPUT['cookie_path']) #Cookieを保存

		r = self.br.response()
		res = r.read()
		#xbmc.log(res)

		u = urlparse(r.geturl())
		url = u.scheme + "://" + u.netloc

		playlist_url = ""
		soup = BeautifulSoup(res)
		secs = soup.findAll("section", {"class":"item-view"})
		for sec in secs:
			if sec.find("h1").renderContents() == "ストリーミング":
				playlist_url = sec.find("a")["href"]
				break

		if not playlist_url: 
			addon = xbmcaddon.Addon()
			xbmcgui.Dialog().ok(addon.getLocalizedString(30100), addon.getLocalizedString(30105))

		else: 

			#-------------------------------------------------------------------
			# 動画プレイリスト取得
			url += playlist_url
			req = urllib2.Request(url)
			self.br.open(req)
			#self.cj.save(self.IPUT['cookie_path']) #Cookieを保存

			r = self.br.response()
			res = r.read()
			#xbmc.log(r.geturl()) #ページのURL
			#xbmc.log(r.info())   #headers

			#xbmc.log(res)
			obj = m3u8.loads(res)

			#-------------------------------------------------------------------
			# 動画ストリームリスト取得

			# 帯域
			self.IPUT['quality'] = self.IPUT['quality_list'][int(self.IPUT['settings'].getSetting('quality'))]
			for p in obj.playlists:
				if int(p.stream_info.bandwidth) > self.IPUT['quality']:  break
				url = urljoin(r.geturl(), p.uri)
				if self.IPUT['quality'] <= int(p.stream_info.bandwidth): break

			# ストリームファイル取得
			req = urllib2.Request(url)
			self.br.open(req)

			r = self.br.response()
			self.IPUT['m3u8_url'] = r.geturl()
			res = r.read()

			#xbmc.log(r.geturl())
			#xbmc.log(res)
			obj = m3u8.loads(res)

			#-------------------------------------------------------------------
			# キーファイル取得
			r = urllib.urlopen(url)

			for line in r:
				key_match = re.match('#EXT-X-KEY:METHOD=AES-128,URI="(http://.+?)"', line)
				if key_match:
					# キーファイルの記載があるなら
					key_url = key_match.group(1)

					m = re.match('(https?):\/\/((.+):(.+)@)?(.+)', key_url)
					url = m.group(1) + '://' + m.group(5) # ユーザーＩＤとパスワード抜きのURL

					if m.group(2):
						query = urllib.urlencode({"name":m.group(3), "password":m.group(4)})
						req = urllib2.Request(url, query)
					else:
						req = urllib2.Request(url)

					# キーファイルダウンロード
					self.br.open(req)
					key_r = self.br.response()
					self.IPUT['key_buf'] = key_r.read()


		#-----------------------------------------------------------------------
		thread = threading.Thread(target=self.getStream, args=(obj,))
		thread.daemon = False
		thread.start()
		thread.join()


