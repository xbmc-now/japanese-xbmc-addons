#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  共通関数
##└──────────────────────────────────────
##
## [ 更新履歴 ]
##
##==============================================================================
## 設定値をここに記載する。
import sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib
import shelve
import mechanize
#-------------------------------------------------------------------------------
def getParams(ParamDict):
	try:
		#print "getParams() argv=", sys.argv
		if sys.argv[2] : ParamPairs = sys.argv[2][1:].split( "&" )
		for ParamsPair in ParamPairs : 
			ParamSplits = ParamsPair.split('=')
			if (len(ParamSplits)) == 2 : ParamDict[ParamSplits[0]] = urllib.unquote_plus(ParamSplits[1])
	except : pass
	return True

#-------------------------------------------------------------------------------
# 共有オブジェクト取得
def getSharedObject(IPUT):
	DIC = shelve.open(IPUT['shared_object_path'])
	# TypeError: String or Integer object expected for key, unicode found
	if DIC.has_key(IPUT['shared_object_key'].encode("utf-16le")): 
		SO = DIC[IPUT['shared_object_key'].encode("utf-16le")]
	else: SO = {}
	DIC.close()
	SO = {}
	return SO

#-------------------------------------------------------------------------------
# 共有オブジェクト保存
def setSharedObject(IPUT, SO):
	DIC = shelve.open(IPUT['shared_object_path'])
	DIC[IPUT['shared_object_key'].encode("utf-16le")] = SO
	DIC.close()
	return True

#-------------------------------------------------------------------------------
def createBrowser(IPUT):
	# ブラウザ作成
	br = mechanize.Browser()
	br.set_handle_robots(False)

	# ユーザーエージェントをiPhoneにする
	br.addheaders = [('User-agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4')]

	#br.set_proxies({"http": "id:pw@host:8080"}) # プロキシ設定
	#br.set_handle_referer(False) #リファラをリフレッシュするかどうか。

	# クッキーオブジェクト
	cj = mechanize.LWPCookieJar()
	br.set_cookiejar(cj)
	#cj.load(IPUT['cookie_path'])

	return br, cj

#-------------------------------------------------------------------------------
def showBusyDialog():
	xbmc.executebuiltin('ActivateWindow(busydialog)')

def hideBusyDialog():
	xbmc.executebuiltin('Dialog.Close(busydialog)')
	while xbmc.getCondVisibility('Window.IsActive(busydialog)'):
		xbmc.sleep(.1)
