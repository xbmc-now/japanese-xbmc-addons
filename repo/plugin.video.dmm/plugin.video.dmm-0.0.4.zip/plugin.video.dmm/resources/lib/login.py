#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  ログイン関数
##└──────────────────────────────────────
##
## [ 更新履歴 ]
##
##==============================================================================
## 設定値をここに記載する。
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
from HTMLParser import HTMLParser, HTMLParseError
import httplib, urllib, urllib2, cookielib

#-------------------------------------------------------------------------------
__login_url__ = "https://www.dmm.com/my/-/login/"
__auth_url__  = "https://www.dmm.com/my/-/login/auth/"

#-------------------------------------------------------------------------------
class HTMLParserObj(HTMLParser):
	def __init__(self):
		HTMLParser.__init__(self)
		self.token = ''
	#-- スタートタグ -----------------------------------------------------------
	def handle_starttag(self, tag, attrs):
		attrs = dict(attrs) # タプルだと扱いにくいので辞書にする

		if tag == 'input' and attrs['name'] == 'token':self.token = attrs['value']

#-------------------------------------------------------------------------------
def checkMailPassword(IPUT):
	if IPUT['mail'] or IPUT['password']: 
		if not IPUT['mail']: 
			addon = xbmcaddon.Addon()
			xbmcgui.Dialog().ok(addon.getLocalizedString(30100), addon.getLocalizedString(30102))
			xbmcaddon.Addon().openSettings() # 設定ダイヤログを開く
			return False

		if not IPUT['password']: 
			addon = xbmcaddon.Addon()
			xbmcgui.Dialog().ok(addon.getLocalizedString(30100), addon.getLocalizedString(30103))
			xbmcaddon.Addon().openSettings() # 設定ダイヤログを開く
			return False

		return True
	else:
		addon = xbmcaddon.Addon()
		xbmcgui.Dialog().ok(addon.getLocalizedString(30100), addon.getLocalizedString(30101))
		xbmcaddon.Addon().openSettings() # 設定ダイヤログを開く
		return False

#-------------------------------------------------------------------------------
def openLogin(br, cj, IPUT):

	#---------------------------------------------------------------------------
	# ログインページにアクセスして、DMM_TOKEN、url、tokenを取得
	req = urllib2.Request(__login_url__)
	br.open(req)
	res = br.response().read()
	p = HTMLParserObj()
	p.feed(res)
	p.close()



	#---------------------------------------------------------------------------
	# 認証実行
	# POSTデータ生成
	query = urllib.urlencode({
		"token": p.token, 
		"login_id": IPUT['mail'], 
		"password": IPUT['password'], 
		"use_auto_login": "1"
	})
	req = urllib2.Request(__auth_url__, query)
	br.open(req)
	#cj.save(IPUT['cookie_path']) #Cookieを保存
	#res = br.response().read()

	# ログインチェック
	for c in cj: 
		if c.name == "check_done_login" and c.value == "1": 
			return True

	addon = xbmcaddon.Addon()
	xbmcgui.Dialog().ok(addon.getLocalizedString(30100), addon.getLocalizedString(30104))
	return False

#-------------------------------------------------------------------------------
