#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  XBMC.DMM v0.0.4 (2016/06/17)
##│  Copyright (c) Inpane
##│  plugin.video.dmm
##│  http://xbmc.inpane.com/
##│  info@inpane.com
##└──────────────────────────────────────
##==============================================================================
## 設定値をここに記載する。

import os, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
#-------------------------------------------------------------------------------
IPUT = {} # 入力パラメーター
SO   = {} # 共有オブジェクト

#-------------------------------------------------------------------------------
# resources/libのパスを追加

try:
	IPUT['script_path'] = os.path.abspath(os.path.dirname(__file__))
except:
	IPUT['script_path'] = os.getcwd()

IPUT['resources_path'] = os.path.join(IPUT['script_path'   ], 'resources')
IPUT['library_path'  ] = os.path.join(IPUT['resources_path'], 'lib')
sys.path.append(IPUT['library_path']) 

# コンフィグ読込
import config
config.load(IPUT)

#-------------------------------------------------------------------------------
import utils
import login
import browse
import play
#-------------------------------------------------------------------------------
def main():
	global IPUT
	utils.getParams(IPUT) # パラメーター取得

	# ブラウザ作成
	[br, cj] = utils.createBrowser(IPUT)

	if not login.checkMailPassword(IPUT): return # メールアドレス・パスワードチェック

	if not login.openLogin(br, cj, IPUT): return # ログイン

	#---------------------------------------------------------------------------
	if not IPUT.has_key('ope'): # 初期メニュー(moviesディレクトリ取得)

		if not browse.openMyPage(br, cj, IPUT): return

	elif IPUT['ope'] == 'my':
		if not browse.openMyPage(br, cj, IPUT, IPUT['page']): return

	elif IPUT['ope'] == 'play':
		player = play.MyPlayer()
		player.getPlaylist(br, cj, IPUT)

#-------------------------------------------------------------------------------

if __name__  == '__main__': 
	main()
