ガラポンTVを操作するためのKodiアドオンです。 
Windows、Mac OS Xで動作します。Linuxやその他のOSでの動作は未検証です。
