ガラポンTVを操作するためのKodiアドオンです。
Windows、Mac OS Xで動作します。Linuxやその他のOSでの動作は未検証です。
詳しくは http://kodiful.com をご覧ください。
