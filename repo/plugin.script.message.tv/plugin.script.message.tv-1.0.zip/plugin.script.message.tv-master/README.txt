TVでメール/メッセージをやりとりします。
Windows、MacOS Xで動作します。Linuxやその他のOSでの動作は未検証です。
